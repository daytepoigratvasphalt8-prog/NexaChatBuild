# Changelog

## 2.1.0

- Restored the original NexaChat 1.6 launcher and in-app brand icon.
- Fixed false offline detection on dual-SIM, VPN and OEM network stacks.
- Reworked the interface with an iOS-inspired neutral palette, grouped settings and segmented controls.
- Refined the login, registration and profile-completion screens.
- Expanded settings with message time, typing status, notification preview/vibration, background sync, reduced motion and delete confirmation.
- Connected the new settings to chat, notification and synchronization behavior.
- Moved the project to stable Android SDK 36 for reproducible GitHub Actions builds.

## 2.0.0

- Rewritten in Kotlin and Jetpack Compose.
- Added offline-first cache, drafts and optimistic message retry.
- Added realtime streaming with reconnect and automatic token refresh.
- Added direct/group chats, reactions, replies, edit/delete and read receipts.
- Added public profile index that excludes email.
- Added encrypted session storage through Android Keystore.
- Added themes, accessibility options, profile/settings screens and deep links.
- Added background sync, notifications, hardened Firebase rules and migration tooling.
- Added automated tests, lint, debug CI and signed APK/AAB release workflow.
