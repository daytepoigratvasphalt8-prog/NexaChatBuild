package com.nexachat.app.core.repository

import com.nexachat.app.core.database.NexaCacheDb
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.model.DeliveryState
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.model.MessageType
import com.nexachat.app.core.model.TypingState
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.network.DatabaseEvent
import com.nexachat.app.core.network.FirebaseMapper
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.network.NetworkException
import com.nexachat.app.core.settings.SettingsRepository
import com.nexachat.app.core.util.Validation
import com.nexachat.app.core.util.keysList
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class ChatRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
    private val users: UserRepository,
    private val cache: NexaCacheDb,
    private val settings: SettingsRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val syncMutex = Mutex()
    private val _chats = MutableStateFlow(cache.chats())
    val chats: StateFlow<List<ChatSummary>> = _chats.asStateFlow()

    private val messageFlows = ConcurrentHashMap<String, MutableStateFlow<List<Message>>>()
    private val typingFlows = ConcurrentHashMap<String, MutableStateFlow<List<TypingState>>>()
    private val chatStreams = ConcurrentHashMap<String, Job>()
    private val typingStreams = ConcurrentHashMap<String, Job>()
    private var chatsStream: Job? = null

    fun messages(chatId: String): StateFlow<List<Message>> = messageFlows
        .getOrPut(chatId) { MutableStateFlow(cache.messages(chatId)) }
        .asStateFlow()

    fun typing(chatId: String): StateFlow<List<TypingState>> = typingFlows
        .getOrPut(chatId) { MutableStateFlow(emptyList()) }
        .asStateFlow()

    suspend fun start() {
        syncChats()
        if (chatsStream?.isActive == true) return
        chatsStream = scope.launch {
            database.stream("userChats/${sessions.current().uid}") { sessions.token() }
                .collectLatest { event ->
                    if (event.error == null) debounceRefreshChats()
                }
        }
    }

    fun stop() {
        chatsStream?.cancel()
        chatsStream = null
        chatStreams.values.forEach { it.cancel() }
        chatStreams.clear()
        typingStreams.values.forEach { it.cancel() }
        typingStreams.clear()
        typingFlows.values.forEach { it.value = emptyList() }
    }

    suspend fun syncChats() = syncMutex.withLock {
        val session = sessions.current()
        val root = withAuthRetry { token -> database.getObject("userChats/${session.uid}", token) }
        val parsed = root.keysList().mapNotNull { chatId ->
            val index = (root.opt(chatId) as? JSONObject)?.let { FirebaseMapper.chat(chatId, it) }
            val canonical = when {
                index == null -> fetchChat(chatId)
                index.type == ChatType.GROUP -> fetchChat(chatId) ?: index
                else -> index
            }
            canonical?.let { base ->
                base.copy(
                    unreadCount = index?.unreadCount ?: base.unreadCount,
                    muted = index?.muted ?: base.muted,
                    archived = index?.archived ?: base.archived,
                    pinned = index?.pinned ?: base.pinned,
                )
            }
        }.sortedWith(compareByDescending<ChatSummary> { it.pinned }.thenByDescending { it.updatedAt })
        cache.replaceChats(parsed)
        _chats.value = parsed
    }

    suspend fun syncMessages(chatId: String, limit: Int = 300) {
        requireMembership(chatId)
        val effectiveLimit = if (settings.settings.first().dataSaver) limit.coerceAtMost(100) else limit
        val root = withAuthRetry { token ->
            database.getObject(
                "messages/$chatId",
                token,
                mapOf("limitToLast" to effectiveLimit.coerceIn(20, 500).toString()),
            )
        }
        val remote = root.keysList().mapNotNull { id ->
            root.optJSONObject(id)?.let { FirebaseMapper.message(id, chatId, it) }
        }.sortedBy(Message::createdAt)
        cache.upsertMessages(remote)
        val localPending = cache.messages(chatId, limit).filter { it.state != DeliveryState.SENT }
        messageFlows.getOrPut(chatId) { MutableStateFlow(emptyList()) }.value =
            (remote + localPending).distinctBy(Message::clientId).sortedBy(Message::createdAt)
    }

    suspend fun observeMessages(chatId: String) {
        syncMessages(chatId)
        val typingEnabled = settings.settings.first().typingIndicators
        if (typingEnabled) syncTyping(chatId)
        else typingFlows.getOrPut(chatId) { MutableStateFlow(emptyList()) }.value = emptyList()

        if (chatStreams[chatId]?.isActive != true) {
            chatStreams[chatId] = scope.launch {
                database.stream("messages/$chatId") { sessions.token() }.collectLatest { event ->
                    if (event.error == null) {
                        delay(120)
                        runCatching { syncMessages(chatId) }
                    }
                }
            }
        }

        if (typingEnabled && typingStreams[chatId]?.isActive != true) {
            typingStreams[chatId] = scope.launch {
                database.stream("typing/$chatId") { sessions.token() }.collectLatest { event ->
                    if (event.error == null) {
                        runCatching { syncTyping(chatId) }
                        delay(8_500)
                        runCatching { syncTyping(chatId) }
                    }
                }
            }
        } else if (!typingEnabled) {
            typingStreams.remove(chatId)?.cancel()
        }
    }

    fun stopObservingMessages(chatId: String) {
        chatStreams.remove(chatId)?.cancel()
        typingStreams.remove(chatId)?.cancel()
        typingFlows[chatId]?.value = emptyList()
    }

    suspend fun sendMessage(
        chatId: String,
        text: String,
        replyTo: Message? = null,
        type: MessageType = MessageType.TEXT,
        attachmentUrl: String = "",
        attachmentName: String = "",
        attachmentMime: String = "",
        attachmentSize: Long = 0,
    ): Message {
        if (type == MessageType.TEXT) Validation.message(text)?.let { throw IllegalArgumentException(it) }
        val session = sessions.session.value ?: throw IllegalStateException("Требуется вход")
        val chat = requireMembership(chatId)
        val profile = runCatching { users.get(session.uid) }.getOrNull()
            ?: UserProfile(
                uid = session.uid,
                email = session.email,
                firstName = chat.memberNames[session.uid].orEmpty(),
            )
        val now = System.currentTimeMillis()
        val clientId = UUID.randomUUID().toString()
        // A client-generated deterministic ID turns retries into an idempotent operation. If the
        // server accepted a PUT but the response was lost, the outbox can verify this exact path.
        val messageId = "m_${clientId.replace("-", "")}"
        val optimistic = Message(
            id = messageId,
            chatId = chatId,
            clientId = clientId,
            senderId = session.uid,
            senderUsername = profile.username,
            senderName = profile.displayName,
            type = type,
            text = text.trim(),
            attachmentUrl = attachmentUrl,
            attachmentName = attachmentName,
            attachmentMime = attachmentMime,
            attachmentSize = attachmentSize,
            replyToId = replyTo?.id.orEmpty(),
            replyPreview = replyTo?.text?.take(140).orEmpty(),
            createdAt = now,
            readBy = setOf(session.uid),
            state = DeliveryState.SENDING,
        )
        cache.upsertMessage(optimistic)
        emitCachedMessages(chatId)
        return deliverMessage(optimistic, chat, verifyExisting = false)
    }

    suspend fun retry(message: Message): Message {
        val chat = requireMembership(message.chatId)
        val sending = message.copy(state = DeliveryState.SENDING)
        cache.upsertMessage(sending)
        emitCachedMessages(message.chatId)
        return deliverMessage(sending, chat, verifyExisting = true)
    }

    /** Safely drains queued messages after connectivity returns. */
    suspend fun retryPendingMessages(limit: Int = 50) {
        cache.pendingMessages(limit)
            .filter { it.state == DeliveryState.QUEUED || it.state == DeliveryState.SENDING }
            .forEach { pending -> runCatching { retry(pending) } }
    }

    private suspend fun deliverMessage(
        pending: Message,
        chat: ChatSummary,
        verifyExisting: Boolean,
    ): Message {
        val currentUid = sessions.session.value?.uid ?: throw IllegalStateException("Требуется вход")
        require(pending.senderId == currentUid) { "Нельзя отправить чужое сообщение" }
        val path = "messages/${pending.chatId}/${pending.id}"
        try {
            val accepted = if (verifyExisting) {
                val existing = withAuthRetry { token -> database.getObject(path, token) }
                if (existing.length() > 0) {
                    val remote = FirebaseMapper.message(pending.id, pending.chatId, existing)
                    require(remote.clientId == pending.clientId && remote.senderId == pending.senderId) {
                        "Конфликт идентификатора сообщения"
                    }
                    true
                } else false
            } else false

            if (!accepted) {
                withAuthRetry { token ->
                    database.put(
                        path,
                        token,
                        FirebaseMapper.messageJson(pending.copy(state = DeliveryState.SENT)),
                    )
                }
            }
        } catch (error: Throwable) {
            if (error.isRetryableDeliveryFailure()) {
                val queued = pending.copy(state = DeliveryState.QUEUED)
                cache.upsertMessage(queued)
                emitCachedMessages(pending.chatId)
                return queued
            }
            val failed = pending.copy(state = DeliveryState.FAILED)
            cache.upsertMessage(failed)
            emitCachedMessages(pending.chatId)
            throw error
        }

        val sent = pending.copy(state = DeliveryState.SENT)
        cache.upsertMessage(sent)
        emitCachedMessages(pending.chatId)
        updateSummaryBestEffort(chat, sent)
        return sent
    }

    private suspend fun updateSummaryBestEffort(chat: ChatSummary, message: Message) {
        val preview = when (message.type) {
            MessageType.IMAGE -> "📷 Фото"
            MessageType.FILE -> "📎 ${message.attachmentName.ifBlank { "Файл" }}"
            MessageType.VOICE -> "🎙 Голосовое сообщение"
            MessageType.SYSTEM -> message.text
            MessageType.TEXT -> message.text.replace('\n', ' ').take(180)
        }
        val updatedChat = chat.copy(
            lastMessage = preview,
            lastMessageType = message.type,
            lastSenderId = message.senderId,
            updatedAt = message.createdAt,
        )
        updateChatInMemory(updatedChat)

        // Summary metadata is repairable from messages and therefore best-effort. A later chat
        // stream/sync heals it without ever asking the user to resend an accepted message.
        runCatching {
            withAuthRetry { token ->
                val rootPatch = JSONObject()
                    .put("chats/${chat.id}/lastMessage", preview)
                    .put("chats/${chat.id}/lastMessageType", message.type.name.lowercase())
                    .put("chats/${chat.id}/lastSenderId", message.senderId)
                    .put("chats/${chat.id}/updatedAt", message.createdAt)
                chat.memberIds.forEach { uid ->
                    rootPatch.put("userChats/$uid/${chat.id}/lastMessage", preview)
                    rootPatch.put("userChats/$uid/${chat.id}/lastMessageType", message.type.name.lowercase())
                    rootPatch.put("userChats/$uid/${chat.id}/lastSenderId", message.senderId)
                    rootPatch.put("userChats/$uid/${chat.id}/updatedAt", message.createdAt)
                    rootPatch.put(
                        "userChats/$uid/${chat.id}/unreadCount",
                        if (uid == message.senderId) 0 else JSONObject().put(".sv", JSONObject().put("increment", 1)),
                    )
                }
                database.patch("", token, rootPatch)
            }
        }
    }

    private fun Throwable.isRetryableDeliveryFailure(): Boolean {
        val network = this as? NetworkException ?: return false
        return network.statusCode == -1 || network.statusCode == 408 || network.statusCode == 429 || network.statusCode >= 500
    }

    suspend fun editMessage(message: Message, newText: String) {
        Validation.message(newText)?.let { throw IllegalArgumentException(it) }
        val session = sessions.current()
        require(message.senderId == session.uid) { "Можно редактировать только свои сообщения" }
        require(!message.isDeleted) { "Сообщение удалено" }
        val now = System.currentTimeMillis()
        withAuthRetry { token ->
            database.patch(
                "messages/${message.chatId}/${message.id}",
                token,
                JSONObject().put("text", newText.trim()).put("message", newText.trim()).put("editedAt", now),
            )
        }
        cache.upsertMessage(message.copy(text = newText.trim(), editedAt = now))
        emitCachedMessages(message.chatId)
    }

    suspend fun deleteMessage(message: Message, forEveryone: Boolean) {
        if (forEveryone) {
            val session = sessions.current()
            require(message.senderId == session.uid || requireMembership(message.chatId).ownerId == session.uid) {
                "Нет права удалить это сообщение у всех"
            }
            val now = System.currentTimeMillis()
            withAuthRetry { token ->
                database.patch(
                    "messages/${message.chatId}/${message.id}",
                    token,
                    JSONObject()
                        .put("text", "")
                        .put("message", "")
                        .put("attachmentUrl", "")
                        .put("deletedAt", now),
                )
            }
            cache.upsertMessage(message.copy(text = "", attachmentUrl = "", deletedAt = now))
        } else {
            cache.hideMessage(message.chatId, message.id)
        }
        emitCachedMessages(message.chatId)
    }

    suspend fun toggleReaction(message: Message, emoji: String) {
        val uid = sessions.current().uid
        val path = "messages/${message.chatId}/${message.id}/reactions/${safeKey(emoji)}/$uid"
        withAuthRetry { token ->
            val already = message.reactions[emoji]?.contains(uid) == true
            if (already) database.delete(path, token) else database.put(path, token, true)
        }
        syncMessages(message.chatId)
    }

    suspend fun markRead(chatId: String, messages: List<Message>) {
        val uid = sessions.current().uid
        val unread = messages.filter { it.senderId != uid && uid !in it.readBy }.takeLast(100)
        if (unread.isEmpty()) return
        withAuthRetry { token ->
            val patch = JSONObject()
            unread.forEach { patch.put("messages/$chatId/${it.id}/readBy/$uid", true) }
            patch.put("userChats/$uid/$chatId/unreadCount", 0)
            database.patch("", token, patch)
        }
    }

    private suspend fun syncTyping(chatId: String) {
        if (!settings.settings.first().typingIndicators) {
            typingFlows.getOrPut(chatId) { MutableStateFlow(emptyList()) }.value = emptyList()
            return
        }
        requireMembership(chatId)
        val uid = sessions.current().uid
        val cutoff = System.currentTimeMillis() - 8_000
        val root = withAuthRetry { token -> database.getObject("typing/$chatId", token) }
        val active = root.keysList().mapNotNull { memberUid ->
            if (memberUid == uid) return@mapNotNull null
            val item = root.optJSONObject(memberUid) ?: return@mapNotNull null
            val updatedAt = item.optLong("updatedAt", 0)
            if (item.optBoolean("typing", false) && updatedAt >= cutoff) {
                TypingState(memberUid, item.optString("username"), updatedAt)
            } else null
        }.sortedByDescending(TypingState::updatedAt)
        typingFlows.getOrPut(chatId) { MutableStateFlow(emptyList()) }.value = active
    }

    suspend fun setTyping(chatId: String, typing: Boolean) {
        if (typing && !settings.settings.first().typingIndicators) return
        val session = sessions.current()
        withAuthRetry { token ->
            if (typing) {
                database.put(
                    "typing/$chatId/${session.uid}",
                    token,
                    JSONObject().put("typing", true).put("updatedAt", System.currentTimeMillis()),
                )
            } else database.delete("typing/$chatId/${session.uid}", token)
        }
    }

    fun clearTypingAsync(chatId: String) {
        scope.launch { runCatching { setTyping(chatId, false) } }
    }

    suspend fun createDirect(other: UserProfile): ChatSummary {
        val session = sessions.current()
        require(other.uid != session.uid) { "Нельзя создать чат с самим собой" }
        val me = users.get(session.uid) ?: UserProfile(uid = session.uid, email = session.email)
        val pair = listOf(session.uid, other.uid).sorted()
        val chatId = "direct_${sha256(pair.joinToString(":" )).take(28)}"
        val existing = fetchChat(chatId)
        if (existing != null) return existing
        val now = System.currentTimeMillis()
        val chat = ChatSummary(
            id = chatId,
            type = ChatType.DIRECT,
            memberIds = pair.toSet(),
            memberNames = mapOf(session.uid to me.displayName, other.uid to other.displayName),
            ownerId = session.uid,
            updatedAt = now,
        )
        val created = try {
            writeNewChat(chat, now)
            chat
        } catch (error: NetworkException) {
            // Two users can open the same deterministic direct chat concurrently. The loser of
            // the create race simply adopts the canonical chat instead of surfacing an error.
            if (error.statusCode == 403 || error.statusCode == 412) fetchChat(chatId) ?: throw error
            else throw error
        }
        updateChatInMemory(created)
        return created
    }

    suspend fun createGroup(title: String, members: List<UserProfile>): ChatSummary {
        Validation.groupTitle(title)?.let { throw IllegalArgumentException(it) }
        require(members.isNotEmpty()) { "Добавьте хотя бы одного участника" }
        require(members.size <= 49) { "В группе может быть не больше 50 участников" }
        val session = sessions.current()
        val me = users.get(session.uid) ?: UserProfile(uid = session.uid, email = session.email)
        val all = (members + me).distinctBy(UserProfile::uid)
        val chatId = "group_${UUID.randomUUID()}"
        val now = System.currentTimeMillis()
        val chat = ChatSummary(
            id = chatId,
            type = ChatType.GROUP,
            title = title.trim(),
            memberIds = all.mapTo(linkedSetOf(), UserProfile::uid),
            memberNames = all.associate { it.uid to it.displayName },
            ownerId = session.uid,
            updatedAt = now,
        )
        writeNewChat(chat, now)
        val system = Message(
            id = "",
            chatId = chatId,
            clientId = UUID.randomUUID().toString(),
            senderId = session.uid,
            senderName = me.displayName,
            senderUsername = me.username,
            type = MessageType.SYSTEM,
            text = "${me.displayName} создал(а) группу",
            createdAt = now,
            readBy = setOf(session.uid),
        )
        withAuthRetry { token -> database.post("messages/$chatId", token, FirebaseMapper.messageJson(system)) }
        updateChatInMemory(chat)
        return chat
    }

    suspend fun addMember(chatId: String, profile: UserProfile) {
        val chat = requireMembership(chatId)
        val uid = sessions.current().uid
        require(chat.type == ChatType.GROUP) { "Это не группа" }
        require(chat.ownerId == uid) { "Только владелец может добавлять участников" }
        require(chat.memberIds.size < 50) { "В группе уже 50 участников" }
        if (profile.uid in chat.memberIds) return
        val updated = chat.copy(
            memberIds = chat.memberIds + profile.uid,
            memberNames = chat.memberNames + (profile.uid to profile.displayName),
            updatedAt = System.currentTimeMillis(),
        )
        withAuthRetry { token ->
            // Persist membership first so userChats security rules can verify the new member.
            database.put("chats/$chatId", token, chatJson(updated))
            database.put("userChats/${profile.uid}/$chatId", token, chatJson(updated))
        }
        updateChatInMemory(updated)
    }

    suspend fun updateChatPreference(chatId: String, muted: Boolean? = null, archived: Boolean? = null, pinned: Boolean? = null) {
        val uid = sessions.current().uid
        val patch = JSONObject()
        muted?.let { patch.put("muted", it) }
        archived?.let { patch.put("archived", it) }
        pinned?.let { patch.put("pinned", it) }
        withAuthRetry { token -> database.patch("userChats/$uid/$chatId", token, patch) }
        _chats.value = _chats.value.map { chat ->
            if (chat.id != chatId) chat else chat.copy(
                muted = muted ?: chat.muted,
                archived = archived ?: chat.archived,
                pinned = pinned ?: chat.pinned,
            )
        }.sortedWith(compareByDescending<ChatSummary> { it.pinned }.thenByDescending { it.updatedAt })
    }

    suspend fun leaveChat(chatId: String) {
        val session = sessions.current()
        val chat = requireMembership(chatId)
        require(chat.type == ChatType.GROUP) { "Личный чат можно только архивировать" }
        withAuthRetry { token ->
            val patch = JSONObject()
                .put("chats/$chatId/memberIds/${session.uid}", null)
                .put("chats/$chatId/members/${session.uid}", null)
                .put("chats/$chatId/memberNames/${session.uid}", null)
                .put("userChats/${session.uid}/$chatId", null)
            if (chat.ownerId == session.uid) {
                val nextOwner = chat.memberIds.firstOrNull { it != session.uid }
                patch.put("chats/$chatId/ownerId", nextOwner)
            }
            database.patch("", token, patch)
        }
        _chats.value = _chats.value.filterNot { it.id == chatId }
    }

    fun draft(chatId: String): String = cache.draft(chatId)
    fun saveDraft(chatId: String, text: String) = cache.saveDraft(chatId, text)

    fun clearLocalData(restart: Boolean = true) {
        stop()
        cache.clear()
        _chats.value = emptyList()
        messageFlows.clear()
        typingFlows.clear()
        if (restart && sessions.session.value != null) {
            scope.launch { runCatching { start() } }
        }
    }

    private suspend fun writeNewChat(chat: ChatSummary, now: Long) {
        withAuthRetry { token ->
            // Two-phase creation keeps hardened database rules simple and auditable.
            database.put("chats/${chat.id}", token, chatJson(chat))
            chat.memberIds.forEach { uid ->
                database.put("userChats/$uid/${chat.id}", token, chatJson(chat))
            }
        }
        cache.upsertChat(chat.copy(updatedAt = now))
    }

    private fun chatJson(chat: ChatSummary): JSONObject = JSONObject()
        .put("id", chat.id)
        .put("type", chat.type.name.lowercase())
        .put("chatType", chat.type.name.lowercase())
        .put("title", chat.title)
        .put("avatarUrl", chat.avatarUrl)
        .put("memberIds", JSONObject().also { values -> chat.memberIds.forEach { values.put(it, true) } })
        .put("members", JSONObject().also { values -> chat.memberIds.forEach { values.put(it, true) } })
        .put("memberNames", JSONObject(chat.memberNames))
        .put("memberCount", chat.memberIds.size)
        .put("ownerId", chat.ownerId)
        .put("lastMessage", chat.lastMessage)
        .put("lastMessageType", chat.lastMessageType.name.lowercase())
        .put("lastSenderId", chat.lastSenderId)
        .put("updatedAt", chat.updatedAt)
        .put("unreadCount", chat.unreadCount)
        .put("muted", chat.muted)
        .put("archived", chat.archived)
        .put("pinned", chat.pinned)

    private suspend fun fetchChat(chatId: String): ChatSummary? = withAuthRetry { token ->
        database.getObject("chats/$chatId", token).takeIf { it.length() > 0 }?.let { FirebaseMapper.chat(chatId, it) }
    }

    private suspend fun requireMembership(chatId: String): ChatSummary {
        val uid = sessions.session.value?.uid ?: throw IllegalStateException("Требуется вход")
        val chat = _chats.value.firstOrNull { it.id == chatId } ?: fetchChat(chatId)
            ?: throw IllegalStateException("Чат не найден")
        require(uid in chat.memberIds) { "Нет доступа к этому чату" }
        return chat
    }

    private fun emitCachedMessages(chatId: String) {
        messageFlows.getOrPut(chatId) { MutableStateFlow(emptyList()) }.value = cache.messages(chatId)
    }

    private fun updateChatInMemory(chat: ChatSummary) {
        val mutable = _chats.value.filterNot { it.id == chat.id }.toMutableList().apply { add(chat) }
        _chats.value = mutable.sortedWith(compareByDescending<ChatSummary> { it.pinned }.thenByDescending { it.updatedAt })
        cache.upsertChat(chat)
    }

    private suspend fun debounceRefreshChats() {
        delay(180)
        runCatching { syncChats() }
    }

    private suspend fun <T> withAuthRetry(block: suspend (String) -> T): T = try {
        block(sessions.token())
    } catch (error: NetworkException) {
        if (error.statusCode == 401) block(sessions.token(forceRefresh = true)) else throw error
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }

    private fun safeKey(value: String): String = value
        .replace(".", "_")
        .replace("#", "_")
        .replace("$", "_")
        .replace("[", "_")
        .replace("]", "_")
        .replace("/", "_")
}
