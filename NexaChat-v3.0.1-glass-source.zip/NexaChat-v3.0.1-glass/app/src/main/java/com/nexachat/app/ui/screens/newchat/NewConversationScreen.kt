package com.nexachat.app.ui.screens.newchat

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.SearchResult
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.GlassPill
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.NewChatViewModel

@Composable
fun NewConversationScreen(
    viewModel: NewChatViewModel,
    onBack: () -> Unit,
    onCreated: (String) -> Unit,
) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    LaunchedEffect(ui.created?.id) {
        ui.created?.let { chat -> onCreated(chat.id); viewModel.clearCreated() }
    }

    LiquidBackground {
        Column(Modifier.fillMaxSize()) {
            NexaTopBar("Новый диалог", onBack = onBack)
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                GlassPill(!ui.groupMode, { viewModel.setGroupMode(false) }, Modifier.weight(1f)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.PersonAdd, null); Spacer(Modifier.size(7.dp)); Text("Личный чат", fontWeight = FontWeight.Bold)
                    }
                }
                GlassPill(ui.groupMode, { viewModel.setGroupMode(true) }, Modifier.weight(1f)) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.GroupAdd, null); Spacer(Modifier.size(7.dp)); Text("Группа", fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (ui.groupMode) {
                GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 16.dp), radius = 22.dp) {
                    Column(Modifier.padding(vertical = 10.dp)) {
                        OutlinedTextField(
                            value = ui.groupTitle,
                            onValueChange = viewModel::setGroupTitle,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                            label = { Text("Название группы") },
                            supportingText = { Text("${ui.groupTitle.length}/64") },
                            singleLine = true,
                            shape = RoundedCornerShape(17.dp),
                        )
                        if (ui.selected.isNotEmpty()) {
                            LazyRow(Modifier.fillMaxWidth().padding(vertical = 7.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                items(ui.selected, key = { it.uid }) { profile ->
                                    AssistChip(onClick = { viewModel.toggle(profile) }, label = { Text(profile.displayName, maxLines = 1) }, leadingIcon = { Icon(Icons.Rounded.CheckCircle, null, Modifier.size(16.dp)) })
                                }
                            }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = ui.query,
                onValueChange = viewModel::setQuery,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                placeholder = { Text("Username или имя") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = { if (ui.searching) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
            )
            ErrorBanner(ui.error, viewModel::clearError)
            if (!ui.notice.isNullOrBlank()) {
                GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 16.dp), radius = 18.dp) {
                    Text(ui.notice.orEmpty(), Modifier.padding(12.dp), color = MaterialTheme.colorScheme.primary)
                }
            }

            when {
                ui.query.trim().length < 2 -> EmptyState(
                    title = "Найдите собеседника",
                    message = "Введите минимум два символа username или имени. Можно вводить с @ или без него.",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.PersonSearch,
                )
                !ui.searching && ui.results.isEmpty() -> EmptyState(
                    title = "Пользователь не найден",
                    message = "Проверьте написание. Поиск поддерживает старую и новую структуру базы Firebase.",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Search,
                )
                else -> LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(ui.results, key = { it.profile.uid }) { result ->
                        UserResultRow(
                            result = result,
                            selected = ui.selected.any { it.uid == result.profile.uid },
                            onClick = { viewModel.toggle(result.profile) },
                            onAddContact = { viewModel.addContact(result.profile) },
                        )
                    }
                }
            }

            if (ui.groupMode) {
                NexaPrimaryButton(
                    text = "Создать группу (${ui.selected.size + 1})",
                    onClick = viewModel::createGroup,
                    modifier = Modifier.padding(16.dp),
                    enabled = ui.groupTitle.isNotBlank() && ui.selected.isNotEmpty(),
                    loading = ui.creating,
                    icon = Icons.Rounded.GroupAdd,
                )
            } else if (ui.creating) {
                Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.Center) { CircularProgressIndicator() }
            }
        }
    }
}

@Composable
private fun UserResultRow(result: SearchResult, selected: Boolean, onClick: () -> Unit, onAddContact: () -> Unit) {
    val profile = result.profile
    GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp, onClick = onClick) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            NexaAvatar(profile.displayName, size = 50.dp, online = profile.online)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(profile.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("@${profile.username}", color = MaterialTheme.colorScheme.primary)
                if (profile.statusText.isNotBlank()) Text(profile.statusText, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
            IconButton(onClick = onAddContact) { Icon(Icons.Rounded.PersonAdd, "Добавить контакт", tint = MaterialTheme.colorScheme.primary) }
            if (selected) Icon(Icons.Rounded.CheckCircle, "Выбран", tint = MaterialTheme.colorScheme.primary)
        }
    }
}
