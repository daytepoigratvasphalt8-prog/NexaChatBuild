package com.nexachat.app.ui.theme

import androidx.compose.ui.graphics.Color

val IosBlue = Color(0xFF0A84FF)
val IosBlueDark = Color(0xFF64D2FF)
val NexaCyan = Color(0xFF30D5C8)
val NexaPink = Color(0xFFFF5BBE)
val NexaPurple = Color(0xFF9B7BFF)
val NexaMint = Color(0xFF38D996)
val NexaOrange = Color(0xFFFF9F43)
val NexaRed = Color(0xFFFF453A)

val DarkBackground = Color(0xFF05060A)
val DarkSurface = Color(0xFF11131A)
val DarkSurfaceHigh = Color(0xFF1A1D27)
val DarkText = Color(0xFFF5F7FF)
val DarkMuted = Color(0xFFA8ADBA)
val DarkOutline = Color(0xFF363B49)

val LightBackground = Color(0xFFF2F5FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFE8EDF5)
val LightText = Color(0xFF11131A)
val LightMuted = Color(0xFF656B78)
val LightOutline = Color(0xFFC9D0DC)
