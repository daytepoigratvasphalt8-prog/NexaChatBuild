package com.nexachat.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nexachat.app.core.model.WallpaperStyle
import com.nexachat.app.ui.theme.LocalNexaSettings
import kotlin.math.sin

@Composable
fun LiquidBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val settings = LocalNexaSettings.current
    val transition = rememberInfiniteTransition(label = "nexa-liquid")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (settings.reduceMotion) 120_000 else 18_000),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "phase",
    )
    val background = MaterialTheme.colorScheme.background
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary

    Box(modifier.fillMaxSize().background(background)) {
        Canvas(Modifier.fillMaxSize()) {
            drawLiquidWallpaper(settings.wallpaperStyle, phase, accent, secondary, tertiary)
        }
        content()
    }
}

private fun DrawScope.drawLiquidWallpaper(
    style: WallpaperStyle,
    phase: Float,
    accent: Color,
    secondary: Color,
    tertiary: Color,
) {
    if (style == WallpaperStyle.CLEAN) return
    val w = size.width
    val h = size.height
    val movement = sin(phase * Math.PI).toFloat()
    when (style) {
        WallpaperStyle.AURORA -> {
            drawCircle(
                brush = Brush.radialGradient(listOf(accent.copy(alpha = 0.30f), Color.Transparent)),
                radius = w * 0.72f,
                center = Offset(w * (0.12f + movement * 0.22f), h * 0.08f),
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(tertiary.copy(alpha = 0.22f), Color.Transparent)),
                radius = w * 0.62f,
                center = Offset(w * (0.88f - movement * 0.18f), h * 0.48f),
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(secondary.copy(alpha = 0.18f), Color.Transparent)),
                radius = w * 0.68f,
                center = Offset(w * 0.4f, h * (0.94f - movement * 0.14f)),
            )
        }
        WallpaperStyle.BLOBS -> {
            repeat(5) { index ->
                val ratio = index / 4f
                val color = listOf(accent, secondary, tertiary)[index % 3]
                drawCircle(
                    brush = Brush.radialGradient(listOf(color.copy(alpha = 0.16f), Color.Transparent)),
                    radius = w * (0.36f + ratio * 0.12f),
                    center = Offset(
                        x = w * ((0.15f + index * 0.21f + movement * (if (index % 2 == 0) 0.08f else -0.08f)) % 1f),
                        y = h * (0.12f + ratio * 0.78f),
                    ),
                )
            }
        }
        WallpaperStyle.MIDNIGHT -> {
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.12f), Color.Transparent)))
            drawCircle(
                brush = Brush.radialGradient(listOf(tertiary.copy(alpha = 0.16f), Color.Transparent)),
                radius = w * 0.65f,
                center = Offset(w * (0.75f - movement * 0.25f), h * 0.18f),
            )
        }
        WallpaperStyle.CLEAN -> Unit
    }
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    elevation: Dp = 14.dp,
    padding: PaddingValues = PaddingValues(0.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val settings = LocalNexaSettings.current
    val shape = RoundedCornerShape(radius)
    val surface = MaterialTheme.colorScheme.surface
    val outline = MaterialTheme.colorScheme.onSurface
    val alpha = if (settings.glassEnabled) settings.glassIntensity.coerceIn(0.34f, 0.94f) else 1f
    val panelBrush = if (settings.glassEnabled) {
        Brush.linearGradient(
            listOf(
                surface.copy(alpha = (alpha + 0.10f).coerceAtMost(0.98f)),
                surface.copy(alpha = alpha * 0.74f),
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = alpha * 0.55f),
            ),
        )
    } else Brush.linearGradient(listOf(surface, surface))
    val action = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Box(
        modifier = modifier
            .shadow(elevation, shape, ambientColor = Color.Black.copy(alpha = 0.18f), spotColor = Color.Black.copy(alpha = 0.22f))
            .clip(shape)
            .background(panelBrush)
            .border(0.8.dp, outline.copy(alpha = if (settings.glassEnabled) 0.16f else 0.08f), shape)
            .then(action)
            .padding(padding),
        content = content,
    )
}

@Composable
fun GlassPill(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(50)
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surface
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(primary.copy(alpha = 0.96f), primary.copy(alpha = 0.72f)))
                else Brush.linearGradient(listOf(surface.copy(alpha = 0.72f), surface.copy(alpha = 0.45f))),
            )
            .border(0.8.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = if (selected) 0.12f else 0.16f), shape)
            .clickable(onClick = onClick),
        content = content,
    )
}
