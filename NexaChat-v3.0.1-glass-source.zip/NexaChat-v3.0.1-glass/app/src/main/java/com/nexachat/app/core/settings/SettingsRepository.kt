package com.nexachat.app.core.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nexachat.app.core.model.AccentTheme
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.BubbleStyle
import com.nexachat.app.core.model.PrivacyMode
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.core.model.WallpaperStyle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "nexachat_settings_v3")

class SettingsRepository(private val context: Context) {
    val settings: Flow<AppSettings> = context.settingsDataStore.data.map(::read)

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { preferences -> write(preferences, transform(read(preferences))) }
    }

    private fun read(preferences: Preferences): AppSettings = AppSettings(
        themeMode = enum(preferences[THEME], ThemeMode.SYSTEM),
        accentTheme = enum(preferences[ACCENT_THEME], AccentTheme.OCEAN),
        wallpaperStyle = enum(preferences[WALLPAPER], WallpaperStyle.AURORA),
        bubbleStyle = enum(preferences[BUBBLE_STYLE], BubbleStyle.LIQUID_GLASS),
        dynamicColors = preferences[DYNAMIC_COLORS] ?: false,
        glassEnabled = preferences[GLASS_ENABLED] ?: true,
        glassIntensity = preferences[GLASS_INTENSITY] ?: 0.76f,
        compactChats = preferences[COMPACT_CHATS] ?: false,
        largeText = preferences[LARGE_TEXT] ?: false,
        fontScale = preferences[FONT_SCALE] ?: 1f,
        highContrast = preferences[HIGH_CONTRAST] ?: false,
        reduceMotion = preferences[REDUCE_MOTION] ?: false,
        hapticSend = preferences[HAPTIC_SEND] ?: true,
        sendOnEnter = preferences[SEND_ON_ENTER] ?: false,
        showOnline = preferences[SHOW_ONLINE] ?: true,
        readReceipts = preferences[READ_RECEIPTS] ?: true,
        typingIndicators = preferences[TYPING_INDICATORS] ?: true,
        dataSaver = preferences[DATA_SAVER] ?: false,
        autoDownloadPhotos = preferences[AUTO_PHOTOS] ?: true,
        autoDownloadVideos = preferences[AUTO_VIDEOS] ?: false,
        autoPlayVideo = preferences[AUTOPLAY_VIDEO] ?: true,
        saveToGallery = preferences[SAVE_GALLERY] ?: false,
        backgroundSync = preferences[BACKGROUND_SYNC] ?: true,
        notificationsEnabled = preferences[NOTIFICATIONS] ?: true,
        notificationPreview = preferences[NOTIFICATION_PREVIEW] ?: true,
        notificationVibration = preferences[NOTIFICATION_VIBRATION] ?: true,
        groupBadges = preferences[GROUP_BADGES] ?: true,
        showMessageTime = preferences[SHOW_MESSAGE_TIME] ?: true,
        showAvatarsInGroups = preferences[SHOW_GROUP_AVATARS] ?: true,
        linkPreviews = preferences[LINK_PREVIEWS] ?: true,
        confirmBeforeDelete = preferences[CONFIRM_BEFORE_DELETE] ?: true,
        voicePlaybackSpeed = preferences[VOICE_SPEED] ?: 1f,
        lastSeenPrivacy = enum(preferences[LAST_SEEN_PRIVACY], PrivacyMode.EVERYONE),
        avatarPrivacy = enum(preferences[AVATAR_PRIVACY], PrivacyMode.EVERYONE),
        groupsPrivacy = enum(preferences[GROUPS_PRIVACY], PrivacyMode.EVERYONE),
    )

    private fun write(preferences: androidx.datastore.preferences.core.MutablePreferences, value: AppSettings) {
        preferences[THEME] = value.themeMode.name
        preferences[ACCENT_THEME] = value.accentTheme.name
        preferences[WALLPAPER] = value.wallpaperStyle.name
        preferences[BUBBLE_STYLE] = value.bubbleStyle.name
        preferences[DYNAMIC_COLORS] = value.dynamicColors
        preferences[GLASS_ENABLED] = value.glassEnabled
        preferences[GLASS_INTENSITY] = value.glassIntensity
        preferences[COMPACT_CHATS] = value.compactChats
        preferences[LARGE_TEXT] = value.largeText
        preferences[FONT_SCALE] = value.fontScale
        preferences[HIGH_CONTRAST] = value.highContrast
        preferences[REDUCE_MOTION] = value.reduceMotion
        preferences[HAPTIC_SEND] = value.hapticSend
        preferences[SEND_ON_ENTER] = value.sendOnEnter
        preferences[SHOW_ONLINE] = value.showOnline
        preferences[READ_RECEIPTS] = value.readReceipts
        preferences[TYPING_INDICATORS] = value.typingIndicators
        preferences[DATA_SAVER] = value.dataSaver
        preferences[AUTO_PHOTOS] = value.autoDownloadPhotos
        preferences[AUTO_VIDEOS] = value.autoDownloadVideos
        preferences[AUTOPLAY_VIDEO] = value.autoPlayVideo
        preferences[SAVE_GALLERY] = value.saveToGallery
        preferences[BACKGROUND_SYNC] = value.backgroundSync
        preferences[NOTIFICATIONS] = value.notificationsEnabled
        preferences[NOTIFICATION_PREVIEW] = value.notificationPreview
        preferences[NOTIFICATION_VIBRATION] = value.notificationVibration
        preferences[GROUP_BADGES] = value.groupBadges
        preferences[SHOW_MESSAGE_TIME] = value.showMessageTime
        preferences[SHOW_GROUP_AVATARS] = value.showAvatarsInGroups
        preferences[LINK_PREVIEWS] = value.linkPreviews
        preferences[CONFIRM_BEFORE_DELETE] = value.confirmBeforeDelete
        preferences[VOICE_SPEED] = value.voicePlaybackSpeed
        preferences[LAST_SEEN_PRIVACY] = value.lastSeenPrivacy.name
        preferences[AVATAR_PRIVACY] = value.avatarPrivacy.name
        preferences[GROUPS_PRIVACY] = value.groupsPrivacy.name
    }

    private inline fun <reified T : Enum<T>> enum(raw: String?, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == raw } ?: fallback

    private companion object {
        val THEME = stringPreferencesKey("theme")
        val ACCENT_THEME = stringPreferencesKey("accent_theme")
        val WALLPAPER = stringPreferencesKey("wallpaper")
        val BUBBLE_STYLE = stringPreferencesKey("bubble_style")
        val DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        val GLASS_ENABLED = booleanPreferencesKey("glass_enabled")
        val GLASS_INTENSITY = floatPreferencesKey("glass_intensity")
        val COMPACT_CHATS = booleanPreferencesKey("compact_chats")
        val LARGE_TEXT = booleanPreferencesKey("large_text")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val HIGH_CONTRAST = booleanPreferencesKey("high_contrast")
        val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
        val HAPTIC_SEND = booleanPreferencesKey("haptic_send")
        val SEND_ON_ENTER = booleanPreferencesKey("send_on_enter")
        val SHOW_ONLINE = booleanPreferencesKey("show_online")
        val READ_RECEIPTS = booleanPreferencesKey("read_receipts")
        val TYPING_INDICATORS = booleanPreferencesKey("typing_indicators")
        val DATA_SAVER = booleanPreferencesKey("data_saver")
        val AUTO_PHOTOS = booleanPreferencesKey("auto_photos")
        val AUTO_VIDEOS = booleanPreferencesKey("auto_videos")
        val AUTOPLAY_VIDEO = booleanPreferencesKey("autoplay_video")
        val SAVE_GALLERY = booleanPreferencesKey("save_gallery")
        val BACKGROUND_SYNC = booleanPreferencesKey("background_sync")
        val NOTIFICATIONS = booleanPreferencesKey("notifications")
        val NOTIFICATION_PREVIEW = booleanPreferencesKey("notification_preview")
        val NOTIFICATION_VIBRATION = booleanPreferencesKey("notification_vibration")
        val GROUP_BADGES = booleanPreferencesKey("group_badges")
        val SHOW_MESSAGE_TIME = booleanPreferencesKey("show_message_time")
        val SHOW_GROUP_AVATARS = booleanPreferencesKey("show_group_avatars")
        val LINK_PREVIEWS = booleanPreferencesKey("link_previews")
        val CONFIRM_BEFORE_DELETE = booleanPreferencesKey("confirm_before_delete")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val LAST_SEEN_PRIVACY = stringPreferencesKey("privacy_last_seen")
        val AVATAR_PRIVACY = stringPreferencesKey("privacy_avatar")
        val GROUPS_PRIVACY = stringPreferencesKey("privacy_groups")
    }
}
