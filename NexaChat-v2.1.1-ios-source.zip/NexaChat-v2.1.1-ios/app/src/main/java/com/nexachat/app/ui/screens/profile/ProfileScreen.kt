package com.nexachat.app.ui.screens.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.LoadingScreen
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.ProfileViewModel

@Composable
fun ProfileScreen(viewModel: ProfileViewModel) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val profile = ui.profile
    Scaffold(topBar = { NexaTopBar("Профиль") }) { padding ->
        if (profile == null) {
            LoadingScreen("Загружаем профиль…")
            return@Scaffold
        }
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            NexaAvatar(profile.displayName, size = 104.dp, online = profile.online)
            Text(profile.displayName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("@${profile.username}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            if (profile.statusText.isNotBlank() && !ui.editing) {
                Text(profile.statusText, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            ErrorBanner(ui.error, viewModel::clearError)

            if (ui.editing) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = ui.firstName,
                            onValueChange = viewModel::setFirstName,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Имя") },
                            leadingIcon = { Icon(Icons.Rounded.Person, null) },
                            singleLine = true,
                            shape = RoundedCornerShape(13.dp),
                        )
                        OutlinedTextField(
                            value = ui.lastName,
                            onValueChange = viewModel::setLastName,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Фамилия") },
                            leadingIcon = { Icon(Icons.Rounded.Person, null) },
                            singleLine = true,
                            shape = RoundedCornerShape(13.dp),
                        )
                        OutlinedTextField(
                            value = ui.statusText,
                            onValueChange = viewModel::setStatus,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Статус") },
                            supportingText = { Text("${ui.statusText.length}/70") },
                            singleLine = true,
                            shape = RoundedCornerShape(13.dp),
                        )
                        OutlinedTextField(
                            value = ui.bio,
                            onValueChange = viewModel::setBio,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("О себе") },
                            minLines = 4,
                            supportingText = { Text("${ui.bio.length}/160") },
                            shape = RoundedCornerShape(13.dp),
                        )
                        NexaPrimaryButton("Сохранить", viewModel::save, loading = ui.saving, icon = Icons.Rounded.Save)
                        OutlinedButton(onClick = viewModel::cancelEdit, modifier = Modifier.fillMaxWidth()) { Text("Отмена") }
                    }
                }
            } else {
                NexaPrimaryButton(
                    text = "Редактировать профиль",
                    onClick = viewModel::startEdit,
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Rounded.Edit,
                )
                ProfileInfoCard(
                    rows = listOf(
                        Triple(Icons.Rounded.Badge, "Username", "@${profile.username}"),
                        Triple(Icons.Rounded.AlternateEmail, "Электронная почта", profile.email),
                        Triple(Icons.Rounded.Person, "О себе", profile.bio.ifBlank { "Не заполнено" }),
                    ),
                )
            }
        }
    }
}

@Composable
private fun ProfileInfoCard(rows: List<Triple<androidx.compose.ui.graphics.vector.ImageVector, String, String>>) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            rows.forEach { (icon, title, value) ->
                Row(verticalAlignment = Alignment.Top) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                        Icon(icon, null, Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(value, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        }
    }
}
