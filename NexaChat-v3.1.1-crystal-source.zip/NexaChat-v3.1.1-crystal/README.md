# NexaChat 3.1 — Crystal Glass

NexaChat is a Kotlin + Jetpack Compose Android messenger with Firebase Authentication, Realtime Database compatibility, local SQLite caching and an offline outbox. Version 3.1 adds a new Crystal Glass interface based on the supplied frosted iPhone visual reference while keeping the original NexaChat icon and existing messaging data model.

## Highlights

- Email registration, login, password reset and email verification.
- Direct chats and groups with roles, replies, reactions, edit/delete, forwarding and pinned messages.
- Images, video, documents and voice messages when Firebase Storage is available.
- Realtime updates, typing indicators, read states, drafts and automatic retry after reconnect.
- Local cache and offline message queue.
- Profile editing, avatar, username, status, bio, contacts, favorites and blocking.
- Chat pin, mute and archive preferences.
- Crystal animated wallpaper with separate light and dark rendering.
- Layered glass panels with configurable transparency, shine and colored refraction.
- Home widgets for unread messages and active conversations.
- Quick actions for personal chat, group, contacts and archive.
- Unread, personal, group and archived chat filters.
- Favorite-contact quick strip.
- Floating glass Dock with optional labels.
- Original NexaChat application icon.

The 3.1 dashboard, filters, Dock and design settings are client-side features and do not require new Firebase Rules. Existing text messaging continues to depend on the rules already deployed for the project. Media uploads still require Firebase Storage and appropriate Storage Rules.

## Requirements

- JDK 17.
- Android SDK Platform 36.
- Firebase Email/Password Authentication.
- Firebase Realtime Database.

Minimum supported Android version: Android 8.0 (`minSdk 26`).

## Build

```bash
./tools/verify-static.sh
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

The included external GitHub Actions workflow builds a debug APK from the source ZIP and uploads it as an artifact. Lint reporting runs after APK upload and cannot hide an otherwise successful APK build.

## Project map

- `app/` — Android application.
- `firebase/` — Realtime Database and Storage rules.
- `tools/migration/` — legacy public-profile migration.
- `docs/` — architecture, security, Firebase setup and Crystal Glass design notes.
- `BUILD_STATUS.md` — checks performed before delivery.

## Security note

NexaChat 3.1 does not claim end-to-end encryption. Firebase project administrators can access server-side plaintext messages. A Firebase Android API key is a public client identifier; actual access control must be enforced by Firebase Authentication and Rules.
