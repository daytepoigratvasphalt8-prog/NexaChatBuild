# Build status — NexaChat 3.1.0

Completed locally:

- Source tree validation
- XML parsing
- JSON rules validation
- JavaScript syntax validation
- Kotlin delimiter scan
- Sensitive-key scan
- Manifest deep-link lint fixes from the previous 3.0.2 report
- Archive permission validation

The included GitHub Actions workflow performs the authoritative Android build with Java 17, Android SDK 36, unit tests, `assembleDebug`, non-blocking lint reporting and APK artifact upload.
