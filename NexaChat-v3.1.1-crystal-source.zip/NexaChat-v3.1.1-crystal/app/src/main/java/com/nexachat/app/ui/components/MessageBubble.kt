package com.nexachat.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nexachat.app.core.model.BubbleStyle
import com.nexachat.app.core.model.DeliveryState
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.model.MessageType
import com.nexachat.app.core.util.TimeFormat
import com.nexachat.app.ui.theme.LocalNexaSettings

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: Message,
    mine: Boolean,
    showSender: Boolean,
    showTime: Boolean,
    autoLoadImages: Boolean = true,
    linkPreviews: Boolean = true,
    onLongClick: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
    loadMedia: (suspend (String) -> ByteArray)? = null,
    onOpenMedia: () -> Unit = {},
    onPlayVoice: () -> Unit = {},
    onOpenLink: (String) -> Unit = {},
) {
    if (message.type == MessageType.SYSTEM) {
        Box(modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            GlassPanel(radius = 15.dp, elevation = 2.dp) {
                Text(message.text, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    val settings = LocalNexaSettings.current
    var mediaRevealed by remember(message.id, autoLoadImages) { mutableStateOf(autoLoadImages) }
    val shape = RoundedCornerShape(
        topStart = 22.dp,
        topEnd = 22.dp,
        bottomStart = if (mine) 22.dp else 7.dp,
        bottomEnd = if (mine) 7.dp else 22.dp,
    )
    val bubbleColor = when (settings.bubbleStyle) {
        BubbleStyle.LIQUID_GLASS -> if (mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.82f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)
        BubbleStyle.SOFT -> if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
        BubbleStyle.MINIMAL -> if (mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.92f) else MaterialTheme.colorScheme.surface
    }
    val contentColor = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 340.dp).combinedClickable(onClick = {}, onLongClick = onLongClick),
            shape = shape,
            color = bubbleColor,
            contentColor = contentColor,
            tonalElevation = if (settings.bubbleStyle == BubbleStyle.LIQUID_GLASS) 3.dp else 0.dp,
            shadowElevation = if (settings.bubbleStyle == BubbleStyle.LIQUID_GLASS) 5.dp else 0.dp,
            border = if (settings.bubbleStyle == BubbleStyle.LIQUID_GLASS) BorderStroke(0.8.dp, Color.White.copy(alpha = if (mine) 0.22f else 0.14f)) else null,
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                if (message.forwardedFromName.isNotBlank()) {
                    Text("Переслано от ${message.forwardedFromName}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = if (mine) contentColor.copy(alpha = 0.82f) else MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                }
                if (showSender && !mine) {
                    Text(message.senderName.ifBlank { message.senderUsername }, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                }
                if (message.replyToId.isNotBlank()) {
                    Surface(color = Color.Black.copy(alpha = if (mine) 0.14f else 0.07f), shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.padding(horizontal = 9.dp, vertical = 6.dp)) {
                            Text("Ответ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(message.replyPreview.ifBlank { "Сообщение" }, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Spacer(Modifier.size(6.dp))
                }
                when {
                    message.isDeleted -> Text("Сообщение удалено", fontStyle = FontStyle.Italic, color = LocalBubbleMuted)
                    message.type == MessageType.IMAGE && loadMedia != null && message.attachmentUrl.isNotBlank() -> {
                        if (mediaRevealed) {
                            MediaImage(message.attachmentUrl, loadMedia, Modifier.widthIn(max = 300.dp).height(210.dp).clip(RoundedCornerShape(15.dp)))
                        } else {
                            Surface(onClick = { mediaRevealed = true }, shape = RoundedCornerShape(15.dp), color = Color.Black.copy(alpha = 0.12f)) {
                                Row(Modifier.width(250.dp).padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Rounded.Download, "Загрузить фото")
                                    Column { Text("Фото", fontWeight = FontWeight.SemiBold); Text("Нажмите для загрузки", style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted) }
                                }
                            }
                        }
                        if (message.text.isNotBlank()) MessageTextWithLink(message.text, linkPreviews, onOpenLink, Modifier.padding(top = 7.dp))
                    }
                    message.type == MessageType.VIDEO -> {
                        Surface(onClick = onOpenMedia, shape = RoundedCornerShape(15.dp), color = Color.Black.copy(alpha = 0.18f)) {
                            Box(Modifier.width(250.dp).height(150.dp), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Videocam, "Видео", Modifier.size(46.dp))
                                Text("Видео • ${formatBytes(message.attachmentSize)}", Modifier.align(Alignment.BottomStart).padding(12.dp), fontWeight = FontWeight.SemiBold)
                            }
                        }
                        if (message.text.isNotBlank()) MessageTextWithLink(message.text, linkPreviews, onOpenLink, Modifier.padding(top = 7.dp))
                    }
                    message.type == MessageType.FILE -> {
                        Surface(onClick = onOpenMedia, shape = RoundedCornerShape(14.dp), color = Color.Black.copy(alpha = 0.10f)) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Rounded.Description, null, Modifier.size(32.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(message.attachmentName.ifBlank { "Файл" }, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(formatBytes(message.attachmentSize), style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
                                }
                                Icon(Icons.Rounded.Download, "Скачать")
                            }
                        }
                        if (message.text.isNotBlank()) MessageTextWithLink(message.text, linkPreviews, onOpenLink, Modifier.padding(top = 7.dp))
                    }
                    message.type == MessageType.VOICE -> VoiceMessage(message, onPlayVoice)
                    else -> MessageTextWithLink(message.text, linkPreviews, onOpenLink)
                }
                if (showTime || mine || message.editedAt > 0 || message.pinned) {
                    Row(Modifier.align(Alignment.End).padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        if (message.pinned) Icon(Icons.Rounded.PushPin, "Закреплено", Modifier.size(13.dp), tint = LocalBubbleMuted)
                        if (message.editedAt > 0) Text("изм.", style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
                        if (showTime) Text(TimeFormat.message(message.createdAt), style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
                        if (mine) DeliveryIcon(message.state, onRetry)
                    }
                }
                if (message.reactions.isNotEmpty()) {
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        message.reactions.entries.take(5).forEach { (emoji, users) ->
                            Surface(shape = RoundedCornerShape(10.dp), color = Color.Black.copy(alpha = 0.13f)) {
                                Text("$emoji ${users.size}", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageTextWithLink(
    text: String,
    showPreview: Boolean,
    onOpenLink: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val link = remember(text) { Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ')', ']') }
    Column(modifier) {
        Text(text, style = MaterialTheme.typography.bodyLarge)
        if (showPreview && !link.isNullOrBlank()) {
            Spacer(Modifier.height(7.dp))
            Surface(onClick = { onOpenLink(link) }, shape = RoundedCornerShape(12.dp), color = Color.Black.copy(alpha = 0.10f)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Description, null, Modifier.size(22.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Открыть ссылку", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
                        Text(link, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceMessage(message: Message, onPlay: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Surface(onClick = onPlay, shape = androidx.compose.foundation.shape.CircleShape, color = Color.Black.copy(alpha = 0.12f)) {
            Icon(Icons.Rounded.PlayArrow, "Воспроизвести", Modifier.padding(10.dp).size(24.dp))
        }
        Column {
            val waveform = message.waveform.ifEmpty { List(22) { 28 + (it * 13 % 62) } }
            val waveformStart = MaterialTheme.colorScheme.secondary
            val waveformEnd = MaterialTheme.colorScheme.primary
            Canvas(Modifier.width(190.dp).height(32.dp)) {
                val barWidth = size.width / (waveform.size * 1.7f)
                waveform.forEachIndexed { index, value ->
                    val x = index * size.width / waveform.size
                    val height = size.height * (value.coerceIn(5, 100) / 100f)
                    drawRoundRect(
                        brush = Brush.verticalGradient(listOf(waveformStart, waveformEnd)),
                        topLeft = androidx.compose.ui.geometry.Offset(x, (size.height - height) / 2f),
                        size = androidx.compose.ui.geometry.Size(barWidth, height),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2f),
                    )
                }
            }
            Text(formatDuration(message.durationMs), style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
        }
    }
}

@Composable
private fun DeliveryIcon(state: DeliveryState, onRetry: () -> Unit) {
    when (state) {
        DeliveryState.FAILED -> Icon(Icons.Rounded.Refresh, "Повторить", Modifier.size(15.dp).combinedClickable(onClick = onRetry, onLongClick = onRetry), tint = MaterialTheme.colorScheme.error)
        DeliveryState.READ -> Icon(Icons.Rounded.DoneAll, "Прочитано", Modifier.size(15.dp), tint = MaterialTheme.colorScheme.secondary)
        DeliveryState.DELIVERED -> Icon(Icons.Rounded.DoneAll, "Доставлено", Modifier.size(15.dp), tint = LocalBubbleMuted)
        DeliveryState.QUEUED -> Icon(Icons.Rounded.Schedule, "В очереди", Modifier.size(15.dp), tint = LocalBubbleMuted)
        DeliveryState.UPLOADING, DeliveryState.SENDING -> Text("…", style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
        DeliveryState.SENT -> Icon(Icons.Rounded.Check, "Отправлено", Modifier.size(15.dp), tint = LocalBubbleMuted)
    }
}

private fun formatDuration(ms: Long): String {
    val seconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(seconds / 60, seconds % 60)
}

private fun formatBytes(bytes: Long): String = when {
    bytes <= 0 -> ""
    bytes < 1024 -> "$bytes Б"
    bytes < 1024 * 1024 -> "%.1f КБ".format(bytes / 1024f)
    else -> "%.1f МБ".format(bytes / (1024f * 1024f))
}

private val LocalBubbleMuted
    @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.76f)
