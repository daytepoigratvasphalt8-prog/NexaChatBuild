package com.nexachat.app.ui.theme

import androidx.compose.ui.graphics.Color

val IosBlue = Color(0xFF0A84FF)
val IosBlueDark = Color(0xFF64D2FF)
val NexaCyan = Color(0xFF36E2D2)
val NexaPink = Color(0xFFFF74C8)
val NexaPurple = Color(0xFF8D7CFF)
val NexaMint = Color(0xFF44E3A4)
val NexaOrange = Color(0xFFFFA652)
val NexaRed = Color(0xFFFF453A)

val DarkBackground = Color(0xFF050A17)
val DarkSurface = Color(0xFF0E1830)
val DarkSurfaceHigh = Color(0xFF172440)
val DarkText = Color(0xFFF7FAFF)
val DarkMuted = Color(0xFFB2C0D8)
val DarkOutline = Color(0xFF405779)

val LightBackground = Color(0xFFE5F7F7)
val LightSurface = Color(0xFFF9FEFF)
val LightSurfaceHigh = Color(0xFFDCEFF3)
val LightText = Color(0xFF0B1730)
val LightMuted = Color(0xFF53647A)
val LightOutline = Color(0xFFAFC8D0)
