package com.nexachat.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.nexachat.app.core.model.AccentTheme
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.ThemeMode

val LocalNexaSettings = staticCompositionLocalOf { AppSettings() }

@Composable
fun NexaChatTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val accent = accentFor(settings.accentTheme, dark)
    val context = LocalContext.current
    val dynamic = settings.dynamicColors && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val base = when {
        dynamic -> if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> darkColorScheme(
            primary = accent,
            onPrimary = if (settings.accentTheme == AccentTheme.MINT) Color.Black else Color.White,
            secondary = NexaCyan,
            tertiary = NexaPink,
            background = DarkBackground,
            onBackground = DarkText,
            surface = DarkSurface,
            onSurface = DarkText,
            surfaceVariant = DarkSurfaceHigh,
            onSurfaceVariant = DarkMuted,
            outline = DarkOutline,
            outlineVariant = DarkOutline,
            error = NexaRed,
            errorContainer = Color(0xFF3A1515),
            onErrorContainer = Color(0xFFFFDAD6),
        )
        else -> lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            secondary = Color(0xFF008E91),
            tertiary = Color(0xFFAF2D7A),
            background = LightBackground,
            onBackground = LightText,
            surface = LightSurface,
            onSurface = LightText,
            surfaceVariant = LightSurfaceHigh,
            onSurfaceVariant = LightMuted,
            outline = LightOutline,
            outlineVariant = LightOutline,
            error = NexaRed,
            errorContainer = Color(0xFFFFE5E5),
            onErrorContainer = Color(0xFF7A1010),
        )
    }
    val colors = if (settings.highContrast) {
        base.copy(
            outline = base.onSurface.copy(alpha = 0.88f),
            outlineVariant = base.onSurface.copy(alpha = 0.62f),
            onSurfaceVariant = base.onSurface.copy(alpha = 0.94f),
        )
    } else base

    val scale = settings.fontScale.coerceIn(0.85f, 1.35f) * if (settings.largeText) 1.12f else 1f
    fun type(size: Float, weight: FontWeight, lineHeight: Float = size * 1.25f) = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = weight,
        fontSize = (size * scale).sp,
        lineHeight = (lineHeight * scale).sp,
        letterSpacing = (-0.15f).sp,
    )
    val typography = Typography(
        displaySmall = type(34f, FontWeight.Bold, 38f),
        headlineLarge = type(30f, FontWeight.Bold, 34f),
        headlineMedium = type(24f, FontWeight.Bold, 29f),
        titleLarge = type(20f, FontWeight.SemiBold, 25f),
        titleMedium = type(17f, FontWeight.SemiBold, 22f),
        bodyLarge = type(17f, FontWeight.Normal, 22f),
        bodyMedium = type(15f, FontWeight.Normal, 20f),
        labelLarge = type(15f, FontWeight.SemiBold, 19f),
        labelMedium = type(12f, FontWeight.Medium, 16f),
    )

    CompositionLocalProvider(LocalNexaSettings provides settings) {
        MaterialTheme(colorScheme = colors, typography = typography, content = content)
    }
}

private fun accentFor(theme: AccentTheme, dark: Boolean): Color = when (theme) {
    AccentTheme.OCEAN -> if (dark) IosBlueDark else IosBlue
    AccentTheme.VIOLET -> if (dark) Color(0xFFB69CFF) else Color(0xFF7C4DFF)
    AccentTheme.ROSE -> if (dark) Color(0xFFFF7AC8) else Color(0xFFE83E8C)
    AccentTheme.MINT -> if (dark) Color(0xFF65E8B5) else Color(0xFF0AAE76)
    AccentTheme.SUNSET -> if (dark) Color(0xFFFFB05C) else Color(0xFFF47721)
}
