package com.nexachat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.media.MediaRepository
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.model.MessageType
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.repository.SessionManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class ChatUiState(
    val input: String = "",
    val replyTo: Message? = null,
    val selected: Message? = null,
    val loading: Boolean = true,
    val sending: Boolean = false,
    val uploading: Boolean = false,
    val uploadProgress: Float = 0f,
    val uploadName: String = "",
    val searchVisible: Boolean = false,
    val searchQuery: String = "",
    val searchResults: List<Message> = emptyList(),
    val error: String? = null,
)

class ChatViewModel(
    val chatId: String,
    private val repository: ChatRepository,
    private val media: MediaRepository,
    sessions: SessionManager,
) : ViewModel() {
    val messages: StateFlow<List<Message>> = repository.messages(chatId)
    val availableChats = repository.chats
    val typing = repository.typing(chatId)
    val currentUid: String = sessions.session.value?.uid.orEmpty()
    private val _ui = MutableStateFlow(ChatUiState(input = repository.draft(chatId)))
    val ui: StateFlow<ChatUiState> = _ui.asStateFlow()
    private var typingJob: Job? = null

    init {
        viewModelScope.launch {
            runCatching { repository.observeMessages(chatId) }
                .onSuccess { _ui.update { it.copy(loading = false) } }
                .onFailure { error -> _ui.update { it.copy(loading = false, error = error.message) } }
        }
    }

    fun setInput(value: String) {
        _ui.update { it.copy(input = value.take(8_000)) }
        repository.saveDraft(chatId, value)
        typingJob?.cancel()
        typingJob = viewModelScope.launch {
            delay(300)
            if (value.isNotBlank()) {
                runCatching { repository.setTyping(chatId, true) }
                delay(2_500)
            }
            runCatching { repository.setTyping(chatId, false) }
        }
    }

    fun setReply(message: Message?) = _ui.update { it.copy(replyTo = message, selected = null) }
    fun select(message: Message?) = _ui.update { it.copy(selected = message) }
    fun clearError() = _ui.update { it.copy(error = null) }

    fun toggleSearch() = _ui.update {
        if (it.searchVisible) it.copy(searchVisible = false, searchQuery = "", searchResults = emptyList())
        else it.copy(searchVisible = true)
    }

    fun setSearchQuery(value: String) = _ui.update {
        it.copy(searchQuery = value.take(120), searchResults = repository.searchMessages(chatId, value))
    }

    fun send() {
        val text = _ui.value.input
        if (text.isBlank() || _ui.value.sending) return
        val reply = _ui.value.replyTo
        _ui.update { it.copy(input = "", replyTo = null, sending = true, error = null) }
        repository.saveDraft(chatId, "")
        viewModelScope.launch {
            runCatching { repository.sendMessage(chatId, text, reply) }
                .onFailure { error -> _ui.update { it.copy(error = error.message ?: "Не удалось отправить сообщение") } }
            _ui.update { it.copy(sending = false) }
            runCatching { repository.setTyping(chatId, false) }
        }
    }

    fun sendAttachment(uri: Uri) {
        if (_ui.value.uploading) return
        viewModelScope.launch {
            _ui.update { it.copy(uploading = true, uploadProgress = 0f, uploadName = "Медиа", error = null) }
            runCatching {
                val attachment = media.uploadUri(uri, scope = "chats/$chatId") { progress ->
                    _ui.update { state -> state.copy(uploadProgress = progress) }
                }
                val type = when {
                    attachment.mime.startsWith("image/") -> MessageType.IMAGE
                    attachment.mime.startsWith("video/") -> MessageType.VIDEO
                    attachment.mime.startsWith("audio/") -> MessageType.FILE
                    else -> MessageType.FILE
                }
                repository.sendMessage(
                    chatId = chatId,
                    text = _ui.value.input,
                    replyTo = _ui.value.replyTo,
                    type = type,
                    attachmentUrl = attachment.downloadUrl,
                    attachmentName = attachment.name,
                    attachmentMime = attachment.mime,
                    attachmentSize = attachment.size,
                    durationMs = attachment.durationMs,
                    waveform = attachment.waveform,
                )
            }.onSuccess {
                _ui.update { it.copy(input = "", replyTo = null, uploading = false, uploadProgress = 1f) }
                repository.saveDraft(chatId, "")
            }.onFailure { error ->
                _ui.update { it.copy(uploading = false, error = error.message ?: "Не удалось отправить файл") }
            }
        }
    }

    fun sendVoice(file: File, durationMs: Long, waveform: List<Int>) {
        if (_ui.value.uploading) return
        viewModelScope.launch {
            _ui.update { it.copy(uploading = true, uploadProgress = 0f, uploadName = "Голосовое сообщение", error = null) }
            runCatching {
                val attachment = media.uploadFile(
                    file = file,
                    mime = "audio/mp4",
                    scope = "chats/$chatId/voice",
                    durationMs = durationMs,
                    waveform = waveform,
                ) { progress -> _ui.update { state -> state.copy(uploadProgress = progress) } }
                repository.sendMessage(
                    chatId = chatId,
                    text = "",
                    replyTo = _ui.value.replyTo,
                    type = MessageType.VOICE,
                    attachmentUrl = attachment.downloadUrl,
                    attachmentName = attachment.name,
                    attachmentMime = attachment.mime,
                    attachmentSize = attachment.size,
                    durationMs = durationMs,
                    waveform = waveform,
                )
            }.onSuccess {
                file.delete()
                _ui.update { it.copy(replyTo = null, uploading = false, uploadProgress = 1f) }
            }.onFailure { error ->
                _ui.update { it.copy(uploading = false, error = error.message ?: "Не удалось отправить голосовое") }
            }
        }
    }

    fun newVoiceFile(): File = media.newVoiceFile()

    suspend fun mediaFile(message: Message): File = media.cachedFile(message.attachmentUrl, message.attachmentName)

    fun retry(message: Message) = action { repository.retry(message) }
    fun edit(message: Message, text: String) = action { repository.editMessage(message, text) }
    fun delete(message: Message, everyone: Boolean) = action { repository.deleteMessage(message, everyone) }
    fun react(message: Message, emoji: String) = action { repository.toggleReaction(message, emoji) }
    fun pin(message: Message) = action { repository.pinMessage(message, !message.pinned) }
    fun forward(message: Message, targetChatId: String) = action { repository.forwardMessage(message, listOf(targetChatId)) }
    fun markRead() = action { repository.markRead(chatId, messages.value) }

    private fun action(block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }.onFailure { error -> _ui.update { it.copy(error = error.message) } }
    }

    override fun onCleared() {
        repository.saveDraft(chatId, _ui.value.input)
        repository.stopObservingMessages(chatId)
        repository.clearTypingAsync(chatId)
        super.onCleared()
    }

    class Factory(
        private val chatId: String,
        private val repository: ChatRepository,
        private val media: MediaRepository,
        private val sessions: SessionManager,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ChatViewModel(chatId, repository, media, sessions) as T
    }
}
