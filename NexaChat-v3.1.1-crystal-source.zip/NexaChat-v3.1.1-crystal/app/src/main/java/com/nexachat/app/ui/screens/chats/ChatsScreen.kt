package com.nexachat.app.ui.screens.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.MarkChatUnread
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.util.TimeFormat
import com.nexachat.app.ui.components.CrystalWidget
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassActionTile
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.GlassPill
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaLogo
import com.nexachat.app.ui.viewmodel.ChatFilter
import com.nexachat.app.ui.viewmodel.ChatsViewModel

@Composable
fun ChatsScreen(
    viewModel: ChatsViewModel,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    dashboardWidgets: Boolean,
    quickActions: Boolean,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
    onNewGroup: () -> Unit,
    onOpenContacts: () -> Unit,
) {
    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val allChats by viewModel.allChats.collectAsStateWithLifecycle()
    val meta by viewModel.meta.collectAsStateWithLifecycle()
    val activeChats = allChats.count { !it.archived }
    val unread = allChats.sumOf { it.unreadCount }
    val groups = allChats.count { !it.archived && it.type == ChatType.GROUP }

    LiquidBackground {
        Box(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 132.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            NexaLogo(compact = true)
                            Text(
                                when {
                                    unread > 0 -> "$unread непрочитанных сообщений"
                                    activeChats > 0 -> "Все сообщения прочитаны"
                                    else -> "Начните новое общение"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        GlassPanel(radius = 18.dp, elevation = 7.dp, onClick = viewModel::refresh) {
                            Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Refresh, "Обновить", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }

                if (dashboardWidgets) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CrystalWidget(
                                title = "Сообщения",
                                value = unread.coerceAtMost(999).toString(),
                                subtitle = if (unread == 0) "Новых пока нет" else "Ожидают прочтения",
                                icon = Icons.Rounded.MarkChatUnread,
                                modifier = Modifier.weight(1f),
                                onClick = { viewModel.setFilter(ChatFilter.UNREAD) },
                            )
                            CrystalWidget(
                                title = "Диалоги",
                                value = activeChats.toString(),
                                subtitle = "$groups групп • ${activeChats - groups} личных",
                                icon = Icons.Rounded.ChatBubbleOutline,
                                modifier = Modifier.weight(1f),
                                onClick = { viewModel.setFilter(ChatFilter.ALL) },
                            )
                        }
                    }
                }

                if (quickActions) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GlassActionTile("Диалог", Icons.Rounded.Add, onNewChat, Modifier.weight(1f))
                            GlassActionTile("Группа", Icons.Rounded.GroupAdd, onNewGroup, Modifier.weight(1f))
                            GlassActionTile("Контакты", Icons.Rounded.People, onOpenContacts, Modifier.weight(1f))
                            GlassActionTile(
                                title = "Архив",
                                icon = Icons.Rounded.Archive,
                                onClick = { viewModel.setFilter(ChatFilter.ARCHIVED) },
                                modifier = Modifier.weight(1f),
                                badge = allChats.count { it.archived }.takeIf { it > 0 }?.toString(),
                            )
                        }
                    }
                }

                item {
                    GlassPanel(Modifier.fillMaxWidth(), radius = 27.dp, elevation = 10.dp) {
                        OutlinedTextField(
                            value = meta.query,
                            onValueChange = viewModel::setQuery,
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Поиск чатов и сообщений") },
                            leadingIcon = { Icon(Icons.Rounded.Search, null) },
                            trailingIcon = {
                                if (meta.query.isNotBlank()) {
                                    IconButton(onClick = viewModel::clearSearch) { Icon(Icons.Rounded.Close, "Очистить") }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(27.dp),
                        )
                    }
                }

                item { FilterSelector(meta.filter, viewModel::setFilter) }
                item { ErrorBanner(meta.error, viewModel::clearError) }

                if (chats.isEmpty()) {
                    item {
                        EmptyState(
                            title = if (meta.query.isBlank()) emptyTitle(meta.filter) else "Ничего не найдено",
                            message = if (meta.query.isBlank()) emptyMessage(meta.filter) else "Попробуйте изменить запрос или выбрать другой раздел.",
                            modifier = Modifier.fillMaxWidth().height(330.dp),
                            icon = if (meta.query.isBlank()) Icons.Rounded.ChatBubbleOutline else Icons.Rounded.Search,
                            actionText = if (meta.query.isBlank() && meta.filter == ChatFilter.ALL) "Начать общение" else null,
                            onAction = if (meta.query.isBlank() && meta.filter == ChatFilter.ALL) onNewChat else null,
                        )
                    }
                } else {
                    if (meta.filter == ChatFilter.ALL && chats.any { it.pinned }) {
                        item { ListCaption("ЗАКРЕПЛЁННЫЕ") }
                    }
                    items(chats, key = { it.id }) { chat ->
                        if (meta.filter == ChatFilter.ALL && !chat.pinned && chats.any { it.pinned } && chat.id == chats.firstOrNull { !it.pinned }?.id) {
                            ListCaption("НЕДАВНИЕ")
                        }
                        ChatRow(
                            chat = chat,
                            currentUid = currentUid,
                            compact = compact,
                            showGroupBadges = showGroupBadges,
                            onClick = { onOpenChat(chat.id) },
                            onPin = { viewModel.togglePin(chat) },
                            onMute = { viewModel.toggleMute(chat) },
                            onArchive = { viewModel.toggleArchive(chat) },
                        )
                    }
                }
            }

            FloatingActionButton(
                onClick = onNewChat,
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 18.dp),
                shape = RoundedCornerShape(22.dp),
                containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.94f),
                contentColor = MaterialTheme.colorScheme.onPrimary,
            ) { Icon(Icons.Rounded.Add, "Новый чат") }
        }
    }
}

@Composable
private fun FilterSelector(selected: ChatFilter, onClick: (ChatFilter) -> Unit) {
    val values = listOf(
        ChatFilter.ALL to "Все",
        ChatFilter.UNREAD to "Новые",
        ChatFilter.DIRECT to "Личные",
        ChatFilter.GROUPS to "Группы",
        ChatFilter.ARCHIVED to "Архив",
    )
    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        items(values) { (value, label) ->
            GlassPill(selected == value, { onClick(value) }) {
                Box(Modifier.padding(horizontal = 18.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected == value) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun ListCaption(text: String) {
    Text(
        text,
        Modifier.padding(start = 10.dp, top = 4.dp, bottom = 1.dp),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun ChatRow(
    chat: ChatSummary,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    onClick: () -> Unit,
    onPin: () -> Unit,
    onMute: () -> Unit,
    onArchive: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val title = chat.titleFor(currentUid)
    GlassPanel(Modifier.fillMaxWidth(), radius = 26.dp, elevation = if (chat.pinned) 14.dp else 8.dp, onClick = onClick) {
        Box {
            if (chat.pinned || chat.unreadCount > 0) {
                Box(
                    Modifier
                        .matchParentSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = if (chat.unreadCount > 0) 0.10f else 0.06f),
                                    Color.Transparent,
                                ),
                            ),
                        ),
                )
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = if (compact) 9.dp else 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box {
                    NexaAvatar(title, size = if (compact) 46.dp else 54.dp)
                    if (chat.type == ChatType.GROUP) {
                        androidx.compose.material3.Surface(
                            Modifier.align(Alignment.BottomEnd).border(2.dp, MaterialTheme.colorScheme.surface, CircleShape),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                        ) {
                            Icon(Icons.Rounded.Group, null, Modifier.padding(4.dp).size(13.dp), tint = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
                Spacer(Modifier.size(11.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (chat.pinned) {
                            Icon(Icons.Rounded.PushPin, null, Modifier.size(15.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.size(4.dp))
                        }
                        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            TimeFormat.message(chat.updatedAt),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (chat.unreadCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (chat.type == ChatType.GROUP && showGroupBadges) {
                        Text("${chat.memberIds.size} участников", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            chat.lastMessage.ifBlank { "Начало переписки" },
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (chat.muted) Icon(Icons.Rounded.NotificationsOff, null, Modifier.size(15.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (chat.unreadCount > 0) {
                            Spacer(Modifier.size(6.dp))
                            androidx.compose.material3.Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                                Text(
                                    chat.unreadCount.coerceAtMost(99).toString(),
                                    Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreHoriz, "Меню", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(if (chat.pinned) "Открепить" else "Закрепить") }, leadingIcon = { Icon(Icons.Rounded.PushPin, null) }, onClick = { menu = false; onPin() })
                        DropdownMenuItem(text = { Text(if (chat.muted) "Включить уведомления" else "Без звука") }, leadingIcon = { Icon(Icons.Rounded.NotificationsOff, null) }, onClick = { menu = false; onMute() })
                        DropdownMenuItem(text = { Text(if (chat.archived) "Вернуть из архива" else "В архив") }, leadingIcon = { Icon(if (chat.archived) Icons.Rounded.Unarchive else Icons.Rounded.Archive, null) }, onClick = { menu = false; onArchive() })
                    }
                }
            }
        }
    }
}

private fun emptyTitle(filter: ChatFilter): String = when (filter) {
    ChatFilter.ALL -> "Пока нет чатов"
    ChatFilter.UNREAD -> "Всё прочитано"
    ChatFilter.DIRECT -> "Нет личных диалогов"
    ChatFilter.GROUPS -> "Нет групп"
    ChatFilter.ARCHIVED -> "Архив пуст"
}

private fun emptyMessage(filter: ChatFilter): String = when (filter) {
    ChatFilter.ALL -> "Найдите человека по username или создайте группу."
    ChatFilter.UNREAD -> "Новые сообщения появятся здесь."
    ChatFilter.DIRECT -> "Создайте личный диалог через быстрые действия."
    ChatFilter.GROUPS -> "Создайте группу и добавьте участников."
    ChatFilter.ARCHIVED -> "Скрытые диалоги будут храниться здесь."
}
