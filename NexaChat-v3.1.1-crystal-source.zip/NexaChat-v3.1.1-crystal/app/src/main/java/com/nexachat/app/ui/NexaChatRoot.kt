package com.nexachat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.nexachat.app.core.AppContainer
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.AuthState
import com.nexachat.app.core.network.NetworkMonitor
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.LoadingScreen
import com.nexachat.app.ui.components.OfflineBanner
import com.nexachat.app.ui.screens.auth.AuthScreen
import com.nexachat.app.ui.screens.auth.ProfileSetupScreen
import com.nexachat.app.ui.screens.chat.ChatScreen
import com.nexachat.app.ui.screens.chatinfo.ChatInfoScreen
import com.nexachat.app.ui.screens.chats.ChatsScreen
import com.nexachat.app.ui.screens.contacts.ContactsScreen
import com.nexachat.app.ui.screens.newchat.NewConversationScreen
import com.nexachat.app.ui.screens.profile.ProfileScreen
import com.nexachat.app.ui.screens.settings.SettingsScreen
import com.nexachat.app.ui.theme.NexaChatTheme
import com.nexachat.app.ui.viewmodel.AuthViewModel
import com.nexachat.app.ui.viewmodel.ChatInfoViewModel
import com.nexachat.app.ui.viewmodel.ChatViewModel
import com.nexachat.app.ui.viewmodel.ChatsViewModel
import com.nexachat.app.ui.viewmodel.ContactsViewModel
import com.nexachat.app.ui.viewmodel.NewChatViewModel
import com.nexachat.app.ui.viewmodel.ProfileViewModel
import com.nexachat.app.ui.viewmodel.SettingsViewModel

private object Routes {
    const val CHATS = "chats"
    const val CONTACTS = "contacts"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val NEW_CHAT = "new_chat?group={group}"
    const val CHAT = "chat/{chatId}"
    const val CHAT_INFO = "chat_info/{chatId}"
    fun newChat(group: Boolean) = "new_chat?group=$group"
    fun chat(id: String) = "chat/$id"
    fun chatInfo(id: String) = "chat_info/$id"
}

@Composable
fun NexaChatRoot(container: AppContainer) {
    val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
    val authState by container.auth.state.collectAsStateWithLifecycle()
    NexaChatTheme(settings) {
        when (val state = authState) {
            AuthState.Loading -> LoadingScreen("Запускаем NexaChat 3.1…")
            AuthState.SignedOut -> {
                val vm: AuthViewModel = viewModel(factory = AuthViewModel.Factory(container.auth))
                AuthScreen(vm)
            }
            is AuthState.SignedIn -> {
                if (state.profile != null && state.profile.username.isBlank()) {
                    val vm: AuthViewModel = viewModel(factory = AuthViewModel.Factory(container.auth))
                    ProfileSetupScreen(vm, state.session.email)
                } else MainArea(container, settings, state)
            }
        }
    }
}

@Composable
private fun MainArea(container: AppContainer, settings: AppSettings, authState: AuthState.SignedIn) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val monitor = remember(context) { NetworkMonitor(context.applicationContext) }
    val online by monitor.online.collectAsStateWithLifecycle(initialValue = true)
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBottom = route in setOf(Routes.CHATS, Routes.CONTACTS, Routes.PROFILE, Routes.SETTINGS)

    LaunchedEffect(online, authState.session.uid) {
        if (online) {
            runCatching { container.chats.retryPendingMessages() }
            runCatching { container.chats.syncChats() }
            runCatching { container.contacts.refresh() }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = Color.Transparent,
        bottomBar = { if (showBottom) MainNavigation(nav, route, settings) },
    ) { outerPadding ->
        Column(Modifier.fillMaxSize().padding(outerPadding)) {
            OfflineBanner(online)
            NavHost(navController = nav, startDestination = Routes.CHATS, modifier = Modifier.weight(1f)) {
                composable(Routes.CHATS) {
                    val vm: ChatsViewModel = viewModel(factory = ChatsViewModel.Factory(container.chats))
                    ChatsScreen(
                        viewModel = vm,
                        currentUid = authState.session.uid,
                        compact = settings.compactChats,
                        showGroupBadges = settings.groupBadges,
                        dashboardWidgets = settings.dashboardWidgets,
                        quickActions = settings.quickActions,
                        onOpenChat = { nav.navigate(Routes.chat(it)) },
                        onNewChat = { nav.navigate(Routes.newChat(false)) },
                        onNewGroup = { nav.navigate(Routes.newChat(true)) },
                        onOpenContacts = { nav.navigate(Routes.CONTACTS) },
                    )
                }
                composable(Routes.CONTACTS) {
                    val vm: ContactsViewModel = viewModel(factory = ContactsViewModel.Factory(container.contacts, container.chats))
                    ContactsScreen(vm, onDiscover = { nav.navigate(Routes.newChat(false)) }, onOpenChat = { nav.navigate(Routes.chat(it)) })
                }
                composable(Routes.PROFILE) {
                    val vm: ProfileViewModel = viewModel(factory = ProfileViewModel.Factory(container.auth, container.users, container.media))
                    ProfileScreen(vm, container.media::bytes)
                }
                composable(Routes.SETTINGS) {
                    val vm: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory(container.settings, container.auth, container.chats, container.media))
                    SettingsScreen(vm)
                }
                composable(
                    route = Routes.NEW_CHAT,
                    arguments = listOf(navArgument("group") { type = NavType.BoolType; defaultValue = false }),
                ) { backStackEntry ->
                    val vm: NewChatViewModel = viewModel(factory = NewChatViewModel.Factory(container.users, container.chats, container.contacts, container.sessions))
                    NewConversationScreen(
                        viewModel = vm,
                        initialGroupMode = backStackEntry.arguments?.getBoolean("group") ?: false,
                        onBack = nav::popBackStack,
                        onCreated = { chatId ->
                            nav.navigate(Routes.chat(chatId)) {
                                popUpTo(Routes.CHATS)
                            }
                        },
                    )
                }
                composable(
                    route = Routes.CHAT,
                    deepLinks = listOf(
                        navDeepLink { uriPattern = "nexachat://nexachat.app/chat/{chatId}" },
                        navDeepLink { uriPattern = "https://nexachat.app/chat/{chatId}" },
                    ),
                ) { backStackEntry ->
                    val chatId = backStackEntry.arguments?.getString("chatId").orEmpty()
                    val chats by container.chats.chats.collectAsStateWithLifecycle()
                    val vm: ChatViewModel = viewModel(
                        key = "chat-$chatId",
                        factory = ChatViewModel.Factory(chatId, container.chats, container.media, container.sessions),
                    )
                    ChatScreen(
                        viewModel = vm,
                        chat = chats.firstOrNull { it.id == chatId },
                        hapticEnabled = settings.hapticSend,
                        readReceiptsEnabled = settings.readReceipts,
                        showGroupBadges = settings.groupBadges,
                        showAvatarsInGroups = settings.showAvatarsInGroups,
                        showMessageTime = settings.showMessageTime,
                        linkPreviews = settings.linkPreviews,
                        autoLoadImages = settings.autoDownloadPhotos && !settings.dataSaver,
                        reduceMotion = settings.reduceMotion,
                        confirmBeforeDelete = settings.confirmBeforeDelete,
                        typingIndicatorsEnabled = settings.typingIndicators,
                        loadMedia = container.media::bytes,
                        voiceSpeed = settings.voicePlaybackSpeed,
                        sendOnEnter = settings.sendOnEnter,
                        onBack = nav::popBackStack,
                        onOpenInfo = { nav.navigate(Routes.chatInfo(chatId)) },
                    )
                }
                composable(Routes.CHAT_INFO) { backStackEntry ->
                    val chatId = backStackEntry.arguments?.getString("chatId").orEmpty()
                    val vm: ChatInfoViewModel = viewModel(
                        key = "info-$chatId",
                        factory = ChatInfoViewModel.Factory(chatId, container.chats, container.users, container.media, container.sessions),
                    )
                    ChatInfoScreen(vm, container.media::bytes, nav::popBackStack)
                }
            }
        }
    }
}

@Composable
private fun MainNavigation(nav: NavHostController, currentRoute: String?, settings: AppSettings) {
    val haptics = LocalHapticFeedback.current
    val destinations = listOf(
        Triple(Routes.CHATS, "Чаты", Icons.AutoMirrored.Rounded.Chat),
        Triple(Routes.CONTACTS, "Контакты", Icons.Rounded.Contacts),
        Triple(Routes.PROFILE, "Профиль", Icons.Rounded.Person),
        Triple(Routes.SETTINGS, "Настройки", Icons.Rounded.Settings),
    )
    Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 9.dp)) {
        GlassPanel(Modifier.fillMaxWidth(), radius = 36.dp, elevation = 20.dp) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                destinations.forEach { (route, label, icon) ->
                    val selected = currentRoute == route
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(22.dp))
                            .clickable {
                                if (settings.hapticSend) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                nav.navigate(route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                            .padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                    ) {
                        Box(
                            Modifier
                                .size(if (settings.dockLabels) 43.dp else 51.dp)
                                .clip(RoundedCornerShape(if (settings.dockLabels) 15.dp else 18.dp))
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.94f)
                                    else Color.White.copy(alpha = 0.08f),
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                icon,
                                label,
                                Modifier.size(if (settings.dockLabels) 24.dp else 27.dp),
                                tint = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                        if (settings.dockLabels) {
                            Text(
                                label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}
