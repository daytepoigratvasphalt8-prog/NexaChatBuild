package com.nexachat.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nexachat.app.core.model.WallpaperStyle
import com.nexachat.app.ui.theme.LocalNexaSettings
import kotlin.math.sin

@Composable
fun LiquidBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val settings = LocalNexaSettings.current
    val transition = rememberInfiniteTransition(label = "nexa-liquid")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (settings.reduceMotion) 120_000 else 22_000),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "phase",
    )
    val background = MaterialTheme.colorScheme.background
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary

    Box(modifier.fillMaxSize().background(background)) {
        Canvas(Modifier.fillMaxSize()) {
            drawLiquidWallpaper(settings.wallpaperStyle, phase, accent, secondary, tertiary, background.luminance() < 0.5f)
            drawRect(
                Brush.verticalGradient(
                    0f to Color.White.copy(alpha = if (settings.wallpaperStyle == WallpaperStyle.CRYSTAL) 0.05f else 0f),
                    0.48f to Color.Transparent,
                    1f to Color.Black.copy(alpha = 0.06f),
                ),
            )
        }
        content()
    }
}

private fun DrawScope.drawLiquidWallpaper(
    style: WallpaperStyle,
    phase: Float,
    accent: Color,
    secondary: Color,
    tertiary: Color,
    dark: Boolean,
) {
    if (style == WallpaperStyle.CLEAN) return
    val w = size.width
    val h = size.height
    val movement = sin(phase * Math.PI).toFloat()
    when (style) {
        WallpaperStyle.CRYSTAL -> {
            val crystalColors = if (dark) {
                listOf(Color(0xFF07132D), Color(0xFF0B3D67), Color(0xFF145EC8), Color(0xFF04122B))
            } else {
                listOf(Color(0xFFC8F4F3), Color(0xFF9EDDE8), accent.copy(alpha = 0.70f), Color(0xFF163F9A))
            }
            drawRect(
                Brush.linearGradient(
                    colors = crystalColors,
                    start = Offset(0f, h),
                    end = Offset(w, 0f),
                ),
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        (if (dark) Color(0xFF28D7CA) else Color(0xFFB9FFF0)).copy(alpha = if (dark) 0.46f else 0.96f),
                        Color(0xFF62DCCF).copy(alpha = if (dark) 0.30f else 0.70f),
                        Color.Transparent,
                    ),
                ),
                radius = w * 0.92f,
                center = Offset(w * (-0.10f + movement * 0.05f), h * 0.72f),
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(
                        (if (dark) Color(0xFF5D80FF) else Color(0xFFB6ECFF)).copy(alpha = if (dark) 0.42f else 0.78f),
                        Color(0xFF4675E8).copy(alpha = if (dark) 0.38f else 0.56f),
                        Color.Transparent,
                    ),
                ),
                radius = w * 0.96f,
                center = Offset(w * (0.92f - movement * 0.08f), h * 0.22f),
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color.White.copy(alpha = if (dark) 0.14f else 0.70f), Color.Transparent),
                ),
                radius = w * 0.58f,
                center = Offset(w * 0.18f, h * 0.10f),
            )
        }
        WallpaperStyle.AURORA -> {
            drawCircle(
                brush = Brush.radialGradient(listOf(accent.copy(alpha = 0.30f), Color.Transparent)),
                radius = w * 0.72f,
                center = Offset(w * (0.12f + movement * 0.22f), h * 0.08f),
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(tertiary.copy(alpha = 0.22f), Color.Transparent)),
                radius = w * 0.62f,
                center = Offset(w * (0.88f - movement * 0.18f), h * 0.48f),
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(secondary.copy(alpha = 0.18f), Color.Transparent)),
                radius = w * 0.68f,
                center = Offset(w * 0.4f, h * (0.94f - movement * 0.14f)),
            )
        }
        WallpaperStyle.BLOBS -> {
            repeat(5) { index ->
                val ratio = index / 4f
                val color = listOf(accent, secondary, tertiary)[index % 3]
                drawCircle(
                    brush = Brush.radialGradient(listOf(color.copy(alpha = 0.16f), Color.Transparent)),
                    radius = w * (0.36f + ratio * 0.12f),
                    center = Offset(
                        x = w * ((0.15f + index * 0.21f + movement * (if (index % 2 == 0) 0.08f else -0.08f)) % 1f),
                        y = h * (0.12f + ratio * 0.78f),
                    ),
                )
            }
        }
        WallpaperStyle.MIDNIGHT -> {
            drawRect(Brush.verticalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.12f), Color.Transparent)))
            drawCircle(
                brush = Brush.radialGradient(listOf(tertiary.copy(alpha = 0.16f), Color.Transparent)),
                radius = w * 0.65f,
                center = Offset(w * (0.75f - movement * 0.25f), h * 0.18f),
            )
        }
        WallpaperStyle.CLEAN -> Unit
    }
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    radius: Dp = 26.dp,
    elevation: Dp = 14.dp,
    padding: PaddingValues = PaddingValues(0.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val settings = LocalNexaSettings.current
    val shape = RoundedCornerShape(radius)
    val surface = MaterialTheme.colorScheme.surface
    val surfaceVariant = MaterialTheme.colorScheme.surfaceVariant
    val onSurface = MaterialTheme.colorScheme.onSurface
    val primary = MaterialTheme.colorScheme.primary
    val alpha = if (settings.glassEnabled) settings.glassIntensity.coerceIn(0.30f, 0.96f) else 1f
    val shine = if (settings.glassEnabled) settings.glassShine.coerceIn(0f, 1f) else 0f
    val panelBrush = if (settings.glassEnabled) {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.12f + shine * 0.18f),
                surface.copy(alpha = (alpha + 0.08f).coerceAtMost(0.98f)),
                surface.copy(alpha = alpha * 0.72f),
                surfaceVariant.copy(alpha = alpha * 0.48f),
            ),
            start = Offset.Zero,
            end = Offset(950f, 1250f),
        )
    } else Brush.linearGradient(listOf(surface, surface))
    val action = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Box(
        modifier = modifier
            .shadow(
                elevation,
                shape,
                ambientColor = Color(0xFF174A8A).copy(alpha = if (settings.glassRefraction) 0.20f else 0.10f),
                spotColor = Color.Black.copy(alpha = 0.20f),
            )
            .clip(shape)
            .background(panelBrush)
            .drawWithCache {
                val corner = CornerRadius(radius.toPx(), radius.toPx())
                onDrawWithContent {
                    drawContent()
                    if (settings.glassEnabled && shine > 0f) {
                        drawRoundRect(
                            brush = Brush.linearGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.26f * shine),
                                    Color.Transparent,
                                    if (settings.glassRefraction) primary.copy(alpha = 0.08f * shine) else Color.Transparent,
                                ),
                                start = Offset.Zero,
                                end = Offset(size.width, size.height),
                            ),
                            cornerRadius = corner,
                        )
                    }
                }
            }
            .border(
                width = if (settings.highContrast) 1.2.dp else 0.85.dp,
                color = onSurface.copy(alpha = if (settings.glassEnabled) 0.18f else 0.10f),
                shape = shape,
            )
            .then(action)
            .padding(padding),
        content = content,
    )
}

@Composable
fun GlassPill(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(50)
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surface
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(primary.copy(alpha = 0.98f), primary.copy(alpha = 0.74f)))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.13f), surface.copy(alpha = 0.58f))),
            )
            .border(0.8.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = if (selected) 0.12f else 0.18f), shape)
            .clickable(onClick = onClick),
        content = content,
    )
}

@Composable
fun CrystalWidget(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    GlassPanel(modifier = modifier, radius = 30.dp, elevation = 12.dp, onClick = onClick) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Icon(icon, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Text(value, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Light)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

@Composable
fun GlassActionTile(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badge: String? = null,
) {
    GlassPanel(modifier = modifier, radius = 24.dp, elevation = 9.dp, onClick = onClick) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 13.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Box(
                    Modifier
                        .size(45.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.96f),
                                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.82f),
                                ),
                            ),
                        )
                        .border(0.8.dp, Color.White.copy(alpha = 0.32f), RoundedCornerShape(15.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(icon, null, Modifier.size(25.dp), tint = MaterialTheme.colorScheme.onPrimary)
                }
                if (!badge.isNullOrBlank()) {
                    Box(
                        Modifier
                            .padding(top = 1.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.error)
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    ) {
                        Text(badge, color = Color.White, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(
                title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
