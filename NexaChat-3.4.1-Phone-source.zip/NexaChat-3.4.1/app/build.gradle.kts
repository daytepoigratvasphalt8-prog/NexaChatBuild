import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

val local = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use(::load)
}

fun config(name: String, fallback: String): String =
    (local.getProperty(name)?.takeIf(String::isNotBlank)
        ?: System.getenv(name)?.takeIf(String::isNotBlank)
        ?: fallback)
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")


val releaseKeystore = System.getenv("NEXA_KEYSTORE_PATH")
val releaseStorePassword = System.getenv("NEXA_STORE_PASSWORD")
val releaseKeyAlias = System.getenv("NEXA_KEY_ALIAS")
val releaseKeyPassword = System.getenv("NEXA_KEY_PASSWORD")

android {
    namespace = "com.nexachat.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.nexachat.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 30410
        versionName = "3.4.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true

        buildConfigField("String", "FIREBASE_API_KEY", "\"${config("NEXA_FIREBASE_API_KEY", "AIzaSyDYhIRKwdFYFe-QqnqXUy8pXAlNxjivt2g")}\"")
        buildConfigField("String", "DATABASE_URL", "\"${config("NEXA_DATABASE_URL", "https://nexachat-8c064-default-rtdb.asia-southeast1.firebasedatabase.app")}\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\"${config("NEXA_PROJECT_ID", "nexachat-8c064")}\"")
        buildConfigField("String", "STORAGE_BUCKET", "\"${config("NEXA_STORAGE_BUCKET", "nexachat-8c064.firebasestorage.app")}\"")
        buildConfigField("String", "FIREBASE_APP_ID", "\"${config("NEXA_FIREBASE_APP_ID", "1:897900866748:android:4c5c245a523cdb6c4ff4b9")}\"")
        buildConfigField("String", "FIREBASE_SENDER_ID", "\"${config("NEXA_FIREBASE_SENDER_ID", "897900866748")}\"")
        buildConfigField("String", "FUNCTIONS_BASE_URL", "\"${config("NEXA_FUNCTIONS_BASE_URL", "https://asia-southeast1-${config("NEXA_PROJECT_ID", "nexachat-8c064")}.cloudfunctions.net")}\"")
        buildConfigField("String", "TURN_URL", "\"${config("NEXA_TURN_URL", "")}\"")
        buildConfigField("String", "TURN_USERNAME", "\"${config("NEXA_TURN_USERNAME", "")}\"")
        buildConfigField("String", "TURN_CREDENTIAL", "\"${config("NEXA_TURN_CREDENTIAL", "")}\"")
    }

    signingConfigs {
        if (!releaseKeystore.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
            !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()
        ) {
            create("release") {
                storeFile = rootProject.file(releaseKeystore)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        }
    }

    buildTypes {
        debug {
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            signingConfig = signingConfigs.findByName("release")
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = true
        checkReleaseBuilds = true
        warningsAsErrors = false
    }

    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "/META-INF/LICENSE*",
            "/META-INF/NOTICE*",
        )
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.kotlinx.coroutines.android)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.messaging)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.foundation)
    implementation(libs.compose.material3)
    implementation(libs.compose.icons)
    implementation(libs.compose.ui.tooling.preview)

    debugImplementation(libs.compose.ui.tooling)
    debugImplementation(libs.compose.ui.test.manifest)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.test.espresso)
    androidTestImplementation(libs.compose.ui.test.junit4)
}
