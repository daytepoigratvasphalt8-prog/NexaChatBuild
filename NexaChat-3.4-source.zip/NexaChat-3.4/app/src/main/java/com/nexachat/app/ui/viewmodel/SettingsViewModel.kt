package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.media.MediaRepository
import com.nexachat.app.core.model.AccentTheme
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.BubbleStyle
import com.nexachat.app.core.model.PrivacyMode
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.core.model.WallpaperStyle
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.settings.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val auth: AuthRepository,
    private val chats: ChatRepository,
    private val media: MediaRepository,
) : ViewModel() {
    val chatWallpapers: List<String> = (1..40).map { "nexa_pack/wallpapers/wallpaper_${it.toString().padStart(2, '0')}.webp" }

    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AppSettings(),
    )

    fun setTheme(value: ThemeMode) = update { it.copy(themeMode = value) }
    fun setAccent(value: AccentTheme) = update { it.copy(accentTheme = value) }
    fun setWallpaper(value: WallpaperStyle) = update { it.copy(wallpaperStyle = value) }
    fun setBubbleStyle(value: BubbleStyle) = update { it.copy(bubbleStyle = value) }
    fun setDynamicColors(value: Boolean) = update { it.copy(dynamicColors = value) }
    fun setGlassEnabled(value: Boolean) = update { it.copy(glassEnabled = value) }
    fun setGlassIntensity(value: Float) = update { it.copy(glassIntensity = value.coerceIn(0.30f, 0.96f)) }
    fun setGlassShine(value: Float) = update { it.copy(glassShine = value.coerceIn(0f, 1f)) }
    fun setGlassRefraction(value: Boolean) = update { it.copy(glassRefraction = value) }
    fun setDashboardWidgets(value: Boolean) = update { it.copy(dashboardWidgets = value) }
    fun setQuickActions(value: Boolean) = update { it.copy(quickActions = value) }
    fun setDockLabels(value: Boolean) = update { it.copy(dockLabels = value) }
    fun setCompactChats(value: Boolean) = update { it.copy(compactChats = value) }
    fun setLargeText(value: Boolean) = update { it.copy(largeText = value) }
    fun setFontScale(value: Float) = update { it.copy(fontScale = value.coerceIn(0.85f, 1.35f)) }
    fun setHighContrast(value: Boolean) = update { it.copy(highContrast = value) }
    fun setReduceMotion(value: Boolean) = update { it.copy(reduceMotion = value) }
    fun setHaptic(value: Boolean) = update { it.copy(hapticSend = value) }
    fun setSendOnEnter(value: Boolean) = update { it.copy(sendOnEnter = value) }
    fun setShowOnline(value: Boolean) = update { it.copy(showOnline = value) }
    fun setReadReceipts(value: Boolean) = update { it.copy(readReceipts = value) }
    fun setTypingIndicators(value: Boolean) = update { it.copy(typingIndicators = value) }
    fun setDataSaver(value: Boolean) = update { it.copy(dataSaver = value) }
    fun setAutoPhotos(value: Boolean) = update { it.copy(autoDownloadPhotos = value) }
    fun setAutoVideos(value: Boolean) = update { it.copy(autoDownloadVideos = value) }
    fun setAutoplay(value: Boolean) = update { it.copy(autoPlayVideo = value) }
    fun setSaveGallery(value: Boolean) = update { it.copy(saveToGallery = value) }
    fun setBackgroundSync(value: Boolean) = update { it.copy(backgroundSync = value) }
    fun setNotifications(value: Boolean) = update { it.copy(notificationsEnabled = value) }
    fun setNotificationPreview(value: Boolean) = update { it.copy(notificationPreview = value) }
    fun setNotificationVibration(value: Boolean) = update { it.copy(notificationVibration = value) }
    fun setGroupBadges(value: Boolean) = update { it.copy(groupBadges = value) }
    fun setShowMessageTime(value: Boolean) = update { it.copy(showMessageTime = value) }
    fun setGroupAvatars(value: Boolean) = update { it.copy(showAvatarsInGroups = value) }
    fun setLinkPreviews(value: Boolean) = update { it.copy(linkPreviews = value) }
    fun setConfirmBeforeDelete(value: Boolean) = update { it.copy(confirmBeforeDelete = value) }
    fun setVoiceSpeed(value: Float) = update { it.copy(voicePlaybackSpeed = value.coerceIn(0.5f, 2f)) }
    fun setLastSeenPrivacy(value: PrivacyMode) = update { it.copy(lastSeenPrivacy = value) }
    fun setAvatarPrivacy(value: PrivacyMode) = update { it.copy(avatarPrivacy = value) }
    fun setGroupsPrivacy(value: PrivacyMode) = update { it.copy(groupsPrivacy = value) }
    fun setChatWallpaper(value: String) = update { it.copy(chatWallpaperAsset = value) }
    fun setChatWallpaperDim(value: Float) = update { it.copy(chatWallpaperDim = value.coerceIn(0f, 0.85f)) }
    fun setChatBubbleRadius(value: Float) = update { it.copy(chatBubbleRadius = value.coerceIn(8f, 28f)) }
    fun setChatMessageSpacing(value: Float) = update { it.copy(chatMessageSpacing = value.coerceIn(0f, 8f)) }
    fun setChatTextScale(value: Float) = update { it.copy(chatTextScale = value.coerceIn(0.9f, 1.25f)) }
    fun resetChatAppearance() = update {
        it.copy(
            chatWallpaperAsset = "",
            chatWallpaperDim = 0.50f,
            bubbleStyle = BubbleStyle.SOFT,
            chatBubbleRadius = 22f,
            chatMessageSpacing = 2f,
            chatTextScale = 1f,
            showMessageTime = true,
            showAvatarsInGroups = true,
            linkPreviews = true,
        )
    }

    fun clearCache() = viewModelScope.launch {
        chats.clearCache()
        media.clearCache()
    }

    fun signOut() = viewModelScope.launch { auth.signOut() }

    private fun update(block: (AppSettings) -> AppSettings) = viewModelScope.launch { settingsRepository.update(block) }

    class Factory(
        private val settings: SettingsRepository,
        private val auth: AuthRepository,
        private val chats: ChatRepository,
        private val media: MediaRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            SettingsViewModel(settings, auth, chats, media) as T
    }
}
