# NexaChat 3.2.0 Clean

- Removed liquid/crystal glass, animated wallpaper and blue full-screen background.
- Replaced the floating glass dock with a standard labeled bottom navigation bar.
- Simplified the chat screen: title, search, filters and conversations only.
- Removed duplicate dashboard counters, quick-action tiles and floating add button.
- Added a neutral iOS-inspired light/dark palette with color used only for actions and states.
- Converted all legacy glass panels into solid accessible cards.
- Converted message bubbles to solid soft/minimal styles.
- Simplified appearance settings and migrated existing 3.1 users to Clean mode automatically.

# NexaChat 3.1.1 Crystal Glass

- Fixed Kotlin compilation failure caused by an invalid explicit `matchParentSize` import.
- Added static detection for invalid Compose member-extension imports.
- Kept all 3.1 Crystal Glass design and functionality unchanged.

# NexaChat 3.1.0 — Crystal Glass

## Interface

- Added the new **Crystal** wallpaper inspired by the supplied frosted iPhone reference.
- Rebuilt glass surfaces with layered transparency, specular highlights, colored edge refraction and separate light/dark palettes.
- Replaced the standard Material bottom bar with a floating glass **Dock**.
- Added optional Dock labels, glass shine strength and refraction controls.
- Added a live appearance preview to Settings.
- Improved chat cards, avatars, message bubble borders and transparent top bars.

## Convenience and functionality

- Added home dashboard widgets for unread messages and active conversations.
- Added quick actions for a personal chat, group, contacts and archive.
- Added a real **Unread** chat filter.
- Improved chat sorting: pinned, unread and most recent conversations are prioritized.
- Added dedicated group creation launch from the home screen.
- Added favorite contacts as a horizontal quick-access section.
- Added clearer pinned/recent sections and improved empty states.
- Added one-tap search clearing in chats and contacts.

## Reliability

- Fixed Android App Link intent filters so HTTP and custom schemes are separated.
- Changed the custom chat link to `nexachat://nexachat.app/chat/{chatId}`.
- Added a one-time visual migration to Crystal without removing the rest of the user's settings.
- These 3.1 interface and navigation features do not require new Firebase Rules.
