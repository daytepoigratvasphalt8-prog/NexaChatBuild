#!/usr/bin/env python3
"""Generate NexaChat's built-in HD wallpaper and sticker feature pack.

The source archive intentionally stays small enough for GitHub's browser uploader.
GitHub Actions creates deterministic, useful media assets before Gradle packages the APK.
No filler files, audio tracks, or duplicated blobs are generated.
"""
from __future__ import annotations

import argparse
import colorsys
import json
import math
import random
import shutil
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PACK = ROOT / "app" / "src" / "main" / "assets" / "nexa_pack"
WALLPAPERS = PACK / "wallpapers"
STICKERS = PACK / "stickers"
WALLPAPER_COUNT = 60
STICKERS_PER_PACK = 18
WALLPAPER_WIDTH = 1080
WALLPAPER_HEIGHT = 1920
STICKER_SIZE = 512

PACKS: list[tuple[str, str, list[str]]] = [
    ("emotions", "Эмоции", [
        "ПРИВЕТ", "ПОКА", "СПАСИБО", "ПОЖАЛУЙСТА", "СУПЕР", "КЛАСС", "ВАУ", "УРА", "ОГО", "ЛЮБЛЮ",
        "ОБНИМАЮ", "СКУЧАЮ", "РАДОСТЬ", "СМЕХ", "ГРУСТЬ", "ЗЛЮСЬ", "СТРАШНО", "МИЛО", "СЕРЬЁЗНО", "СПОКОЙНО",
        "СОГЛАСЕН", "НЕ СОГЛАСЕН", "МОЖЕТ БЫТЬ", "ТОЧНО", "НЕ ЗНАЮ", "ИЗВИНИ", "ВСЁ ХОРОШО", "ДЕРЖИСЬ", "РЕСПЕКТ", "ТОП",
    ]),
    ("answers", "Ответы", [
        "ДА", "НЕТ", "ОК", "ГОТОВО", "ПОНЯЛ", "ПРИНЯТО", "ДОГОВОРИЛИСЬ", "СЕЙЧАС", "ПОЗЖЕ", "ЗАВТРА",
        "УЖЕ ИДУ", "БУДУ СКОРО", "ЖДУ", "НА МЕСТЕ", "ПОЗВОНИ", "НАПИШИ", "ОТПРАВЬ", "ПРОВЕРЮ", "СДЕЛАЮ", "НЕ УСПЕЮ",
        "МОГУ", "НЕ МОГУ", "ПОДХОДИТ", "НЕ ПОДХОДИТ", "ВОЗМОЖНО", "БЕЗ ПРОБЛЕМ", "ЕСТЬ ВОПРОС", "НУЖНА ПОМОЩЬ", "ВСЁ ВЕРНО", "ОТЛИЧНО",
    ]),
    ("work", "Работа", [
        "В РАБОТЕ", "ГОТОВО", "ПРОВЕРЬ", "СРОЧНО", "ВАЖНО", "ДЕДЛАЙН", "СОЗВОН", "ВСТРЕЧА", "ПЛАН", "ЗАДАЧА",
        "ОТЧЁТ", "ПРАВКИ", "СОГЛАСОВАНО", "ОТКЛОНЕНО", "НА РЕВЬЮ", "В ПРОД", "БАГ", "ФИКС", "РЕЛИЗ", "ТЕСТ",
        "ИДЕЯ", "РИСК", "ПРИОРИТЕТ", "КОМАНДА", "КЛИЕНТ", "БЮДЖЕТ", "КП", "ПРЕЗЕНТАЦИЯ", "РЕЗУЛЬТАТ", "ПОБЕДА",
    ]),
    ("study", "Учёба", [
        "УЧУСЬ", "УРОК", "ЛЕКЦИЯ", "КОНСПЕКТ", "ДОМАШКА", "ЭКЗАМЕН", "ЗАЧЁТ", "ТЕСТ", "ПРОЕКТ", "КУРСОВАЯ",
        "ДИПЛОМ", "СРОК", "ПЕРЕРЫВ", "ПОНЯТНО", "СЛОЖНО", "ЛЕГКО", "ВОПРОС", "ОТВЕТ", "ФОРМУЛА", "РЕШЕНИЕ",
        "ПОВТОРИ", "ЗАПОМНИ", "ПРОВЕРЬ", "ОЦЕНКА", "ПЯТЁРКА", "ГОТОВЛЮСЬ", "СДАЛ", "НЕ СДАЛ", "КАНИКУЛЫ", "МОЛОДЕЦ",
    ]),
    ("travel", "Поездки", [
        "В ПУТИ", "ПРИЕХАЛ", "УЛЕТАЮ", "ПРИЛЕТЕЛ", "ВОКЗАЛ", "АЭРОПОРТ", "ТАКСИ", "ОТЕЛЬ", "БИЛЕТЫ", "БАГАЖ",
        "МАРШРУТ", "КАРТА", "МОРЕ", "ГОРЫ", "ПЛЯЖ", "ГОРОД", "ПРОГУЛКА", "ФОТО", "КРАСИВО", "ОТДЫХ",
        "ПОЕХАЛИ", "ЖДУ ТЕБЯ", "Я РЯДОМ", "ЗАБЛУДИЛСЯ", "НА СВЯЗИ", "БЕЗ СВЯЗИ", "ДОМОЙ", "ПРИКЛЮЧЕНИЕ", "ВОСПОМИНАНИЯ", "СЧАСТЛИВОГО ПУТИ",
    ]),
    ("food", "Еда", [
        "ВКУСНО", "ХОЧУ ЕСТЬ", "ЗАВТРАК", "ОБЕД", "УЖИН", "КОФЕ", "ЧАЙ", "ПИЦЦА", "БУРГЕР", "СУШИ",
        "САЛАТ", "ДЕСЕРТ", "ТОРТ", "МОРОЖЕНОЕ", "ГОТОВЛЮ", "ЗАКАЗАЛ", "ДОСТАВКА", "ПРИЯТНОГО", "ЕЩЁ", "ХВАТИТ",
        "ОСТРО", "СЛАДКО", "СОЛЁНО", "ПОЛЕЗНО", "РЕЦЕПТ", "В КАФЕ", "ДОМА", "ЗА СТОЛ", "УГОЩАЙСЯ", "ШЕФ",
    ]),
    ("gaming", "Игры", [
        "ИГРАЕМ", "ГОТОВ", "СТАРТ", "ПОБЕДА", "ПОРАЖЕНИЕ", "GG", "WP", "ЛЕГКО", "СЛОЖНО", "ЕЩЁ РАЗ",
        "КОМАНДА", "СОЛО", "ЛОББИ", "ОНЛАЙН", "АФК", "ЛАГ", "ПИНГ", "РАНГ", "УРОВЕНЬ", "БОСС",
        "ЛУТ", "КВЕСТ", "МИССИЯ", "РЕКОРД", "СТРИМ", "ДИСКОРД", "МИКРОФОН", "СЛЫШНО", "НЕ СЛЫШНО", "КРАСИВАЯ ИГРА",
    ]),
    ("celebration", "Праздник", [
        "ПОЗДРАВЛЯЮ", "С ДНЁМ РОЖДЕНИЯ", "УРА", "ПРАЗДНИК", "ПОДАРОК", "СЮРПРИЗ", "ЖЕЛАЮ СЧАСТЬЯ", "ЗДОРОВЬЯ", "УСПЕХОВ", "ЛЮБВИ",
        "ШАМПАНСКОЕ", "ТОРТ", "СВЕЧИ", "КОНФЕТТИ", "ТАНЦЫ", "МУЗЫКА", "ВЕЧЕРИНКА", "ГОСТИ", "ФОТО", "КРАСОТА",
        "ЛУЧШИЙ ДЕНЬ", "С НОВЫМ ГОДОМ", "С 8 МАРТА", "С 23 ФЕВРАЛЯ", "СВАДЬБА", "ГОДОВЩИНА", "КАНИКУЛЫ", "ВЫХОДНОЙ", "ОТДЫХАЕМ", "ЗА ТЕБЯ",
    ]),
    ("support", "Поддержка", [
        "Я РЯДОМ", "ДЕРЖИСЬ", "ТЫ СМОЖЕШЬ", "ВЕРЮ В ТЕБЯ", "НЕ СДАВАЙСЯ", "ОТДОХНИ", "ВЫДОХНИ", "ВСЁ ПОЛУЧИТСЯ", "ТЫ НЕ ОДИН", "ОБНИМАЮ",
        "ПОМОГУ", "РАССКАЖИ", "Я СЛУШАЮ", "НЕ СПЕШИ", "БЕРЕГИ СЕБЯ", "СПАСИБО ТЕБЕ", "ТЫ МОЛОДЕЦ", "ГОРЖУСЬ", "СИЛ ТЕБЕ", "ТЕПЛА",
        "МИРА", "СПОКОЙСТВИЯ", "ХОРОШЕГО ДНЯ", "ДОБРОГО УТРА", "ДОБРОЙ НОЧИ", "ПОПРАВЛЯЙСЯ", "УДАЧИ", "ВПЕРЁД", "ВМЕСТЕ", "ЛУЧИ ДОБРА",
    ]),
    ("nexa", "Nexa", [
        "NEXA", "NEXACHAT", "В СЕТИ", "ПЕЧАТАЮ", "НОВОЕ СООБЩЕНИЕ", "ЗАКРЕПЛЕНО", "СОХРАНЕНО", "ОТПРАВЛЕНО", "ДОСТАВЛЕНО", "ПРОЧИТАНО",
        "БЕЗ ЗВУКА", "В АРХИВ", "ИЗБРАННОЕ", "КОНТАКТЫ", "ГРУППА", "КАНАЛ", "ЛИЧНЫЙ ЧАТ", "СЕКРЕТНО", "ОФЛАЙН", "СИНХРОНИЗАЦИЯ",
        "БЫСТРО", "БЕЗОПАСНО", "КРАСИВО", "УДОБНО", "3.4", "НОВАЯ ТЕМА", "НОВЫЙ СТИКЕР", "ОБОИ", "НАСТРОЙКИ", "ДОБРО ПОЖАЛОВАТЬ",
    ]),
]

PALETTES = [
    ((10, 22, 48), (45, 97, 218), (178, 225, 255)),
    ((32, 14, 46), (131, 69, 182), (255, 184, 219)),
    ((8, 40, 38), (20, 154, 132), (195, 245, 225)),
    ((55, 25, 8), (238, 102, 47), (255, 221, 146)),
    ((13, 30, 53), (0, 163, 190), (190, 247, 255)),
    ((38, 17, 42), (179, 76, 176), (250, 209, 246)),
    ((7, 28, 63), (31, 102, 210), (165, 212, 255)),
    ((49, 9, 29), (222, 45, 102), (255, 188, 211)),
    ((20, 27, 30), (72, 113, 125), (205, 235, 239)),
    ((34, 24, 4), (183, 137, 24), (255, 241, 174)),
]


def font(size: int) -> ImageFont.FreeTypeFont:
    candidates = [
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def mix(a: np.ndarray, b: np.ndarray, t: np.ndarray) -> np.ndarray:
    return a * (1.0 - t) + b * t


def wallpaper(index: int, path: Path) -> None:
    rng = np.random.default_rng(730_000 + index * 97)
    randomizer = random.Random(910_000 + index * 131)
    palette = PALETTES[(index - 1) % len(PALETTES)]
    p0, p1, p2 = (np.array(color, dtype=np.float32)[None, None, :] for color in palette)

    y = np.linspace(0.0, 1.0, WALLPAPER_HEIGHT, dtype=np.float32)[:, None, None]
    x = np.linspace(0.0, 1.0, WALLPAPER_WIDTH, dtype=np.float32)[None, :, None]
    base = mix(p0, p1, np.clip(y * (0.9 + (index % 5) * 0.06), 0.0, 1.0))
    diagonal = np.clip((x * (0.65 + index % 3 * 0.1) + y - 0.55) / 0.95, 0.0, 1.0)
    pixels = mix(base, p2, diagonal * (0.38 + (index % 4) * 0.07))

    # Structured multi-frequency detail keeps the HD background crisp without noisy pixel blocks.
    wave = (
        np.sin(x * math.tau * (1.2 + index % 6 * 0.34) + y * math.tau * 1.7)
        + np.cos(x * math.tau * 2.4 - y * math.tau * (1.1 + index % 7 * 0.21))
    )
    pixels += wave * (4.0 + index % 5)
    pixels += rng.normal(0.0, 4.8, size=(WALLPAPER_HEIGHT, WALLPAPER_WIDTH, 1)).astype(np.float32)
    image = Image.fromarray(np.clip(pixels, 0, 255).astype(np.uint8), "RGB").convert("RGBA")

    layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer, "RGBA")
    for shape_index in range(16):
        cx = randomizer.randint(-WALLPAPER_WIDTH // 4, WALLPAPER_WIDTH + WALLPAPER_WIDTH // 4)
        cy = randomizer.randint(-WALLPAPER_HEIGHT // 5, WALLPAPER_HEIGHT + WALLPAPER_HEIGHT // 5)
        radius_x = randomizer.randint(120, 520)
        radius_y = randomizer.randint(180, 760)
        color = palette[1 + shape_index % 2]
        alpha = randomizer.randint(12, 44)
        draw.ellipse((cx - radius_x, cy - radius_y, cx + radius_x, cy + radius_y), fill=(*color, alpha))
    layer = layer.filter(ImageFilter.GaussianBlur(radius=58 + index % 5 * 8))
    image = Image.alpha_composite(image, layer)

    lines = Image.new("RGBA", image.size, (0, 0, 0, 0))
    line_draw = ImageDraw.Draw(lines, "RGBA")
    for line_index in range(7):
        points = []
        base_y = randomizer.randint(-200, WALLPAPER_HEIGHT + 200)
        amplitude = randomizer.randint(45, 170)
        frequency = randomizer.uniform(0.7, 2.0)
        phase = randomizer.uniform(0.0, math.tau)
        for px in range(-100, WALLPAPER_WIDTH + 120, 24):
            py = base_y + math.sin(px / WALLPAPER_WIDTH * math.tau * frequency + phase) * amplitude
            points.append((px, py))
        line_draw.line(points, fill=(*palette[2], randomizer.randint(24, 70)), width=randomizer.randint(3, 10), joint="curve")
    lines = lines.filter(ImageFilter.GaussianBlur(radius=2.2))
    image = Image.alpha_composite(image, lines).convert("RGB")
    image.save(path, "JPEG", quality=99, subsampling=0, optimize=True, progressive=True)


def sticker(pack_index: int, item_index: int, text: str, path: Path) -> None:
    seed = 1_300_000 + pack_index * 1000 + item_index * 17
    rng = np.random.default_rng(seed)
    randomizer = random.Random(seed)
    hue = ((pack_index * 0.105) + item_index * 0.017) % 1.0
    primary = tuple(int(channel * 255) for channel in colorsys.hsv_to_rgb(hue, 0.68, 0.95))
    secondary = tuple(int(channel * 255) for channel in colorsys.hsv_to_rgb((hue + 0.11) % 1.0, 0.55, 1.0))

    canvas = np.zeros((STICKER_SIZE, STICKER_SIZE, 4), dtype=np.uint8)
    yy, xx = np.mgrid[0:STICKER_SIZE, 0:STICKER_SIZE]
    center_x = STICKER_SIZE / 2 + randomizer.randint(-14, 14)
    center_y = STICKER_SIZE / 2 + randomizer.randint(-10, 18)
    radius = STICKER_SIZE * randomizer.uniform(0.385, 0.43)
    wobble = 1.0 + 0.035 * np.sin(np.arctan2(yy - center_y, xx - center_x) * (5 + item_index % 4))
    mask = ((xx - center_x) ** 2 + (yy - center_y) ** 2) <= (radius * wobble) ** 2

    radial = np.sqrt((xx - center_x) ** 2 + (yy - center_y) ** 2) / radius
    blend = np.clip((xx / STICKER_SIZE * 0.55 + yy / STICKER_SIZE * 0.45), 0.0, 1.0)[..., None]
    rgb = np.array(primary, dtype=np.float32) * (1.0 - blend) + np.array(secondary, dtype=np.float32) * blend
    pattern = (
        np.sin(xx / (9.0 + item_index % 8) + yy / 17.0)
        + np.cos(yy / (11.0 + pack_index) - xx / 23.0)
    )[..., None] * 7.0
    texture = rng.normal(0.0, 5.0, size=(STICKER_SIZE, STICKER_SIZE, 1))
    rgb = np.clip(rgb + pattern + texture - radial[..., None] * 16.0, 0, 255).astype(np.uint8)
    canvas[..., :3] = rgb
    canvas[..., 3] = np.where(mask, 255, 0).astype(np.uint8)
    image = Image.fromarray(canvas, "RGBA")

    draw = ImageDraw.Draw(image, "RGBA")
    # Decorative useful category symbol, drawn from primitives to avoid external icon licensing.
    symbol_y = 124
    symbol_color = (255, 255, 255, 225)
    if pack_index % 5 == 0:
        draw.ellipse((215, symbol_y - 32, 297, symbol_y + 50), outline=symbol_color, width=9)
        draw.arc((230, symbol_y - 5, 282, symbol_y + 34), 12, 168, fill=symbol_color, width=7)
    elif pack_index % 5 == 1:
        draw.rounded_rectangle((214, symbol_y - 28, 298, symbol_y + 46), radius=16, outline=symbol_color, width=9)
        draw.line((235, symbol_y + 8, 252, symbol_y + 24, 281, symbol_y - 8), fill=symbol_color, width=8)
    elif pack_index % 5 == 2:
        draw.rectangle((220, symbol_y - 24, 292, symbol_y + 42), outline=symbol_color, width=8)
        draw.line((220, symbol_y - 5, 292, symbol_y - 5), fill=symbol_color, width=7)
    elif pack_index % 5 == 3:
        draw.polygon([(256, symbol_y - 38), (303, symbol_y + 42), (209, symbol_y + 42)], outline=symbol_color)
        draw.ellipse((247, symbol_y + 1, 265, symbol_y + 19), fill=symbol_color)
    else:
        draw.ellipse((222, symbol_y - 30, 290, symbol_y + 38), outline=symbol_color, width=8)
        draw.line((256, symbol_y - 46, 256, symbol_y + 54), fill=symbol_color, width=7)
        draw.line((206, symbol_y + 4, 306, symbol_y + 4), fill=symbol_color, width=7)

    # Fit text to a maximum width and at most three lines.
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) <= 15 or not current:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    while len(lines) > 3:
        lines[-2] = f"{lines[-2]} {lines[-1]}"
        lines.pop()

    size = 62 if len(text) <= 10 else 50 if len(text) <= 18 else 42
    face = font(size)
    while size > 30:
        widths = [draw.textbbox((0, 0), line, font=face, stroke_width=2)[2] for line in lines]
        if max(widths, default=0) <= 390:
            break
        size -= 2
        face = font(size)
    total_height = len(lines) * (size + 10)
    start_y = 300 - total_height / 2
    for line_index, line in enumerate(lines):
        draw.text(
            (STICKER_SIZE / 2, start_y + line_index * (size + 10)),
            line,
            font=face,
            anchor="mm",
            align="center",
            fill=(255, 255, 255, 255),
            stroke_width=4,
            stroke_fill=(18, 22, 35, 210),
        )

    # White sticker edge and soft shadow.
    alpha = image.getchannel("A")
    edge = alpha.filter(ImageFilter.MaxFilter(9))
    edge_layer = Image.new("RGBA", image.size, (255, 255, 255, 0))
    edge_layer.putalpha(edge)
    edge_layer.alpha_composite(image)
    shadow = edge.filter(ImageFilter.GaussianBlur(14))
    shadow_layer = Image.new("RGBA", image.size, (0, 0, 0, 0))
    shadow_layer.putalpha(shadow.point(lambda value: int(value * 0.28)))
    final = Image.new("RGBA", image.size, (0, 0, 0, 0))
    final.alpha_composite(shadow_layer, (4, 10))
    final.alpha_composite(edge_layer)
    final.save(path, "PNG", optimize=False, compress_level=1)


def clean() -> None:
    if PACK.exists():
        shutil.rmtree(PACK)
    WALLPAPERS.mkdir(parents=True, exist_ok=True)
    STICKERS.mkdir(parents=True, exist_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true", help="Generate a tiny validation pack")
    args = parser.parse_args()
    clean()

    wallpaper_count = 4 if args.quick else WALLPAPER_COUNT
    sticker_count = 3 if args.quick else STICKERS_PER_PACK

    for index in range(1, wallpaper_count + 1):
        wallpaper(index, WALLPAPERS / f"wallpaper_{index:03d}.jpg")

    manifest_packs = []
    for pack_index, (pack_id, title, phrases) in enumerate(PACKS):
        pack_dir = STICKERS / pack_id
        pack_dir.mkdir(parents=True, exist_ok=True)
        items = []
        for item_index, phrase in enumerate(phrases[:sticker_count], start=1):
            name = f"sticker_{item_index:03d}.png"
            sticker(pack_index, item_index, phrase, pack_dir / name)
            items.append(f"stickers/{pack_id}/{name}")
        manifest_packs.append({"id": pack_id, "title": title, "items": items})

    manifest = {
        "version": 34,
        "name": "NexaChat 3.4 Feature Pack",
        "wallpapers": [f"wallpapers/wallpaper_{index:03d}.jpg" for index in range(1, wallpaper_count + 1)],
        "stickerPacks": manifest_packs,
    }
    (PACK / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    size = sum(path.stat().st_size for path in PACK.rglob("*") if path.is_file())
    print(f"Generated {wallpaper_count} HD wallpapers and {len(PACKS) * sticker_count} stickers: {size / 1024 / 1024:.2f} MiB")
    if not args.quick and not 105 * 1024 * 1024 <= size <= 130 * 1024 * 1024:
        raise SystemExit(f"Feature pack size outside useful target range: {size / 1024 / 1024:.2f} MiB")


if __name__ == "__main__":
    main()
