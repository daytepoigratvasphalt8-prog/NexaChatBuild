# NexaChat 3.4 build status

Static verification passed locally. GitHub Actions performs Android unit tests, APK compilation, signature verification, and a minimum 100 MiB size check.
