# NexaChat 3.4 Chat Reliability Fix

- Fixed HTTP 400 when opening chats: Firebase REST limit queries now include orderBy.
- Added automatic fallback for projects without the createdAt index; no Rules update is required.
- Typing-indicator failures no longer block chat opening.
- Added a legacy message-write fallback for older NexaChat Firebase schemas.
- Reduced outgoing message payloads by omitting empty optional fields.

# NexaChat 3.4 Built-in Media — Chat UI

- Removed the Tools destination from the bottom navigation.
- Added a dedicated Settings → Chat appearance screen.
- Added a live message preview and a 40-wallpaper gallery.
- Added wallpaper dimming, bubble radius, message spacing and chat text size controls.
- Moved bubble style and visual chat options into the dedicated screen.
- Kept scheduled sending and saved-message internals available inside chats.
- The GitHub workflow still enforces a final APK size of at least 100 MiB.

# NexaChat 3.4 Built-in Media

- Added a fifth **Tools** tab with local notes, scheduled messages, saved messages, offline wallpapers, local statistics, and JSON export.
- Added true scheduled sending through WorkManager with cancellation, status tracking, retry, and persistence in SQLite.
- Added message bookmarks available from the long-press message menu.
- Added quick-reply templates in the composer.
- Added selectable offline chat wallpapers and 12 looping ambient tracks.
- Added a CI-generated **Built-in Media Pack** containing 40 built-in wallpapers.
- Added an APK size gate: the build fails if the final APK is below 100 MiB.
- Upgraded the local database to schema version 4 for notes, schedules, and saved messages.
- Kept the clean, non-glass 3.2 visual style.
