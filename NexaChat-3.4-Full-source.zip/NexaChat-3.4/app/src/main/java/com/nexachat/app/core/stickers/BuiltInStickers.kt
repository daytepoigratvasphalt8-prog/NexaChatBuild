package com.nexachat.app.core.stickers

data class StickerPack(
    val id: String,
    val title: String,
    val icon: String,
    val assets: List<String>,
)

object BuiltInStickers {
    private const val itemCount = 18

    val packs: List<StickerPack> = listOf(
        pack("emotions", "Эмоции", "☺"),
        pack("answers", "Ответы", "✓"),
        pack("work", "Работа", "▣"),
        pack("study", "Учёба", "A"),
        pack("travel", "Поездки", "✈"),
        pack("food", "Еда", "●"),
        pack("gaming", "Игры", "◆"),
        pack("celebration", "Праздник", "★"),
        pack("support", "Поддержка", "♥"),
        pack("nexa", "Nexa", "N"),
    )

    val allAssets: Set<String> = packs.flatMap(StickerPack::assets).toSet()

    fun isBuiltIn(asset: String): Boolean = asset in allAssets

    private fun pack(id: String, title: String, icon: String): StickerPack = StickerPack(
        id = id,
        title = title,
        icon = icon,
        assets = (1..itemCount).map { index ->
            "nexa_pack/stickers/$id/sticker_${index.toString().padStart(3, '0')}.png"
        },
    )
}
