package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.LocalNote
import com.nexachat.app.core.model.SavedMessage
import com.nexachat.app.core.model.ScheduledMessage
import com.nexachat.app.core.repository.LocalToolsRepository
import com.nexachat.app.core.settings.SettingsRepository
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class HubViewModel(
    val tools: LocalToolsRepository,
    private val settings: SettingsRepository,
) : ViewModel() {
    val notes: StateFlow<List<LocalNote>> = tools.notes
    val scheduled: StateFlow<List<ScheduledMessage>> = tools.scheduled
    val saved: StateFlow<List<SavedMessage>> = tools.saved
    val wallpapers: List<String> = tools.wallpapers

    fun saveNote(id: String?, title: String, body: String) = tools.saveNote(id, title, body)
    fun deleteNote(id: String) = tools.deleteNote(id)
    fun cancelScheduled(id: String) = tools.cancelScheduled(id)
    fun deleteScheduled(id: String) = tools.deleteScheduled(id)
    fun deleteSaved(id: String) = tools.deleteSaved(id)
    fun refresh() = tools.refresh()
    fun setWallpaper(asset: String) = viewModelScope.launch { settings.update { it.copy(chatWallpaperAsset = asset) } }
    fun clearWallpaper() = setWallpaper("")

    class Factory(
        private val tools: LocalToolsRepository,
        private val settings: SettingsRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = HubViewModel(tools, settings) as T
    }
}
