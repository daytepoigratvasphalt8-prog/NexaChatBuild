package com.nexachat.app.core.repository

import com.nexachat.app.core.database.ProfileCache
import com.nexachat.app.core.model.AuthState
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.network.FirebaseAuthService
import com.nexachat.app.core.network.FirebaseMapper
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.util.Validation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

class AuthRepository(
    private val authService: FirebaseAuthService,
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
    private val profileCache: ProfileCache,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<AuthState>(AuthState.Loading)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    init {
        scope.launch { restore() }
    }

    suspend fun restore() {
        val saved = sessions.session.value
        if (saved == null) {
            _state.value = AuthState.SignedOut
            return
        }
        runCatching {
            val session = sessions.current()
            val profileJson = database.getObject("users/${session.uid}", session.idToken)
            val profile = profileJson.takeIf { it.length() > 0 }?.let { FirebaseMapper.profile(session.uid, it) }
                ?: profileCache.read(session.uid)?.copy(email = session.email)
            profile?.let {
                profileCache.write(it)
                publishPublicProfile(it, session.idToken)
            }
            _state.value = AuthState.SignedIn(session, profile)
        }.onFailure {
            // Keep refreshable sessions; only hard-sign-out on an authentication rejection.
            val network = it as? com.nexachat.app.core.network.NetworkException
            if (network?.statusCode == 401) {
                sessions.clear()
                profileCache.clear()
                _state.value = AuthState.SignedOut
            } else {
                _state.value = AuthState.SignedIn(saved, profileCache.read(saved.uid)?.copy(email = saved.email))
            }
        }
    }

    suspend fun signIn(email: String, password: String) {
        Validation.email(email)?.let { throw IllegalArgumentException(it) }
        Validation.password(password)?.let { throw IllegalArgumentException(it) }
        val session = authService.signIn(email, password)
        sessions.save(session)
        val profileJson = database.getObject("users/${session.uid}", session.idToken)
        val profile = profileJson.takeIf { it.length() > 0 }?.let { FirebaseMapper.profile(session.uid, it) }
            ?: profileCache.read(session.uid)?.copy(email = session.email)
        profile?.let {
            profileCache.write(it)
            publishPublicProfile(it, session.idToken)
        }
        _state.value = AuthState.SignedIn(session, profile)
    }

    suspend fun signUp(email: String, password: String) {
        Validation.email(email)?.let { throw IllegalArgumentException(it) }
        Validation.password(password, strict = true)?.let { throw IllegalArgumentException(it) }
        val session = authService.signUp(email, password)
        sessions.save(session)
        val now = System.currentTimeMillis()
        val initial = UserProfile(uid = session.uid, email = session.email, createdAt = now, updatedAt = now)
        database.put("users/${session.uid}", session.idToken, FirebaseMapper.profileJson(initial))
        publishPublicProfile(initial, session.idToken)
        profileCache.write(initial)
        _state.value = AuthState.SignedIn(session, initial)
    }

    suspend fun completeProfile(
        username: String,
        firstName: String,
        lastName: String,
        bio: String = "",
        avatarUrl: String = "",
    ) {
        Validation.username(username)?.let { throw IllegalArgumentException(it) }
        Validation.displayName(firstName, lastName)?.let { throw IllegalArgumentException(it) }
        Validation.bio(bio)?.let { throw IllegalArgumentException(it) }
        val session = sessions.current()
        val normalized = username.lowercase()
        val claimed = database.compareAndSet("usernames/$normalized", session.idToken, transform = { current ->
            when {
                current == "null" -> JSONObject.quote(session.uid)
                current.trim('"') == session.uid -> JSONObject.quote(session.uid)
                else -> null
            }
        })
        if (!claimed) throw IllegalStateException("Этот username уже занят")
        val existing = database.getObject("users/${session.uid}", session.idToken)
        val old = FirebaseMapper.profile(session.uid, existing)
        val profile = old.copy(
            email = session.email,
            username = username,
            usernameLower = normalized,
            firstName = firstName.trim(),
            lastName = lastName.trim(),
            bio = bio.trim(),
            avatarUrl = avatarUrl.ifBlank { old.avatarUrl },
            updatedAt = System.currentTimeMillis(),
        )
        database.patch("users/${session.uid}", session.idToken, FirebaseMapper.profileJson(profile))
        publishPublicProfile(profile, session.idToken)
        profileCache.write(profile)
        _state.value = AuthState.SignedIn(session, profile)
    }

    suspend fun refreshProfile(): UserProfile? {
        val session = sessions.current()
        val json = database.getObject("users/${session.uid}", session.idToken)
        val profile = json.takeIf { it.length() > 0 }?.let { FirebaseMapper.profile(session.uid, it) }
            ?: profileCache.read(session.uid)?.copy(email = session.email)
        profile?.let {
            profileCache.write(it)
            publishPublicProfile(it, session.idToken)
        }
        _state.value = AuthState.SignedIn(session, profile)
        return profile
    }

    suspend fun resetPassword(email: String) {
        Validation.email(email)?.let { throw IllegalArgumentException(it) }
        authService.sendPasswordReset(email)
    }

    suspend fun sendVerification() {
        authService.sendEmailVerification(sessions.token())
    }

    private suspend fun publishPublicProfile(profile: UserProfile, token: String) {
        // Public-profile migration must never block authentication on an older backend configuration.
        runCatching {
            database.patch("publicProfiles/${profile.uid}", token, FirebaseMapper.publicProfileJson(profile))
        }
    }

    suspend fun signOut() {
        sessions.clear()
        profileCache.clear()
        _state.value = AuthState.SignedOut
    }
}
