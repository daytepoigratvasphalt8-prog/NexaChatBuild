package com.nexachat.app.ui.screens.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Forward
import androidx.compose.material.icons.rounded.InsertEmoticon
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Reply
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.media.VoicePlayer
import com.nexachat.app.core.media.VoiceRecorder
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.model.DeliveryState
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.stickers.BuiltInStickers
import com.nexachat.app.core.stickers.StickerPack
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.ChatWallpaperBackground
import com.nexachat.app.ui.components.MessageBubble
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.components.StickerAssetImage
import com.nexachat.app.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    chat: ChatSummary?,
    hapticEnabled: Boolean,
    readReceiptsEnabled: Boolean,
    showGroupBadges: Boolean,
    showAvatarsInGroups: Boolean,
    showMessageTime: Boolean,
    linkPreviews: Boolean,
    autoLoadImages: Boolean,
    reduceMotion: Boolean,
    confirmBeforeDelete: Boolean,
    typingIndicatorsEnabled: Boolean,
    loadMedia: suspend (String) -> ByteArray,
    voiceSpeed: Float,
    sendOnEnter: Boolean,
    chatWallpaperAsset: String,
    chatWallpaperDim: Float,
    onBack: () -> Unit,
    onOpenInfo: () -> Unit = {},
) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val availableChats by viewModel.availableChats.collectAsStateWithLifecycle()
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val typing by viewModel.typing.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val haptics = LocalHapticFeedback.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val voicePlayer = remember { VoicePlayer() }
    val recorder = remember { VoiceRecorder(context) }
    var recording by remember { mutableStateOf(false) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    var recordingSeconds by remember { mutableIntStateOf(0) }
    val recordingWaveform = remember { mutableStateListOf<Int>() }
    var editing by remember { mutableStateOf<Message?>(null) }
    var editText by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Message?>(null) }
    var forwardTarget by remember { mutableStateOf<Message?>(null) }
    var headerMenu by remember { mutableStateOf(false) }
    var scheduleDialog by remember { mutableStateOf(false) }
    var quickReplies by remember { mutableStateOf(false) }
    var stickerPicker by remember { mutableStateOf(false) }
    val title = chat?.titleFor(viewModel.currentUid) ?: "Переписка"

    fun startRecording() {
        val file = viewModel.newVoiceFile()
        runCatching { recorder.start(file) }
            .onSuccess {
                recordingFile = file
                recordingWaveform.clear()
                recordingSeconds = 0
                recording = true
            }
    }

    val microphonePermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording()
    }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.sendAttachment(uri)
    }

    LaunchedEffect(recording) {
        while (recording) {
            recordingWaveform += recorder.sample()
            recordingSeconds += if (recordingWaveform.size % 6 == 0) 1 else 0
            delay(160)
        }
    }
    DisposableEffect(Unit) { onDispose { recorder.cancel(); voicePlayer.stop() } }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            if (reduceMotion) listState.scrollToItem(messages.lastIndex) else listState.animateScrollToItem(messages.lastIndex)
            if (readReceiptsEnabled) viewModel.markRead()
        }
    }

    ChatWallpaperBackground(chatWallpaperAsset, dim = chatWallpaperDim) {
        Column(Modifier.fillMaxSize()) {
            NexaTopBar(
                title = title,
                subtitle = when {
                    typingIndicatorsEnabled && typing.isNotEmpty() -> typingSubtitle(typing.map { chat?.memberNames?.get(it.uid).orEmpty().ifBlank { it.username.ifBlank { "Кто-то" } } })
                    chat == null -> "Синхронизация…"
                    chat.type == ChatType.GROUP && showGroupBadges -> "${chat.memberIds.size} участников"
                    chat.type == ChatType.GROUP -> "Групповой чат"
                    else -> "Личный чат"
                },
                onBack = onBack,
                actions = {
                    IconButton(onClick = viewModel::toggleSearch) { Icon(Icons.Rounded.Search, "Поиск") }
                    Box {
                        IconButton(onClick = { headerMenu = true }) { Icon(Icons.Rounded.MoreVert, "Меню") }
                        DropdownMenu(expanded = headerMenu, onDismissRequest = { headerMenu = false }) {
                            DropdownMenuItem(text = { Text("Информация о чате") }, onClick = { headerMenu = false; onOpenInfo() })
                            DropdownMenuItem(text = { Text(if (chat?.muted == true) "Включить уведомления" else "Без звука") }, onClick = { headerMenu = false })
                        }
                    }
                },
            )
            if (ui.searchVisible) {
                OutlinedTextField(
                    value = ui.searchQuery,
                    onValueChange = viewModel::setSearchQuery,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = { IconButton(onClick = viewModel::toggleSearch) { Icon(Icons.Rounded.Close, "Закрыть") } },
                    placeholder = { Text("Поиск в переписке") },
                    supportingText = { if (ui.searchQuery.isNotBlank()) Text("Найдено: ${ui.searchResults.size}") },
                    singleLine = true,
                    shape = RoundedCornerShape(22.dp),
                )
            }
            ErrorBanner(ui.error, viewModel::clearError)
            if (ui.uploading) {
                GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), radius = 18.dp) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Отправляем: ${ui.uploadName}", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { ui.uploadProgress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }

            Box(Modifier.weight(1f)) {
                val shownMessages = if (ui.searchVisible && ui.searchQuery.isNotBlank()) ui.searchResults.reversed() else messages
                when {
                    ui.loading && shownMessages.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    shownMessages.isEmpty() -> EmptyState(
                        title = if (ui.searchVisible) "Ничего не найдено" else "Начните разговор",
                        message = if (ui.searchVisible) "Попробуйте изменить запрос." else "Отправьте сообщение, фото, видео, документ или голосовую запись.",
                        modifier = Modifier.fillMaxSize(),
                    )
                    else -> LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 10.dp, bottom = 12.dp),
                    ) {
                        items(shownMessages, key = { it.id }) { raw ->
                            val mine = raw.senderId == viewModel.currentUid
                            val message = if (mine && raw.readBy.any { it != viewModel.currentUid }) raw.copy(state = DeliveryState.READ) else raw
                            MessageBubble(
                                message = message,
                                mine = mine,
                                showSender = chat?.type == ChatType.GROUP && showAvatarsInGroups,
                                showTime = showMessageTime,
                                autoLoadImages = autoLoadImages,
                                linkPreviews = linkPreviews,
                                onLongClick = { viewModel.select(message) },
                                onRetry = { viewModel.retry(message) },
                                loadMedia = loadMedia,
                                onOpenMedia = {
                                    scope.launch {
                                        runCatching { viewModel.mediaFile(message) }.onSuccess { file -> openFile(context, file, message.attachmentMime) }
                                    }
                                },
                                onPlayVoice = {
                                    scope.launch {
                                        runCatching { viewModel.mediaFile(message) }.onSuccess { file -> voicePlayer.play(file, voiceSpeed) }
                                    }
                                },
                                onOpenLink = { url -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) } },
                            )
                        }
                    }
                }
            }

            MessageComposer(
                value = ui.input,
                reply = ui.replyTo,
                sending = ui.sending,
                uploading = ui.uploading,
                recording = recording,
                recordingSeconds = recordingSeconds,
                onValueChange = viewModel::setInput,
                onCancelReply = { viewModel.setReply(null) },
                onAttach = { attachmentPicker.launch(arrayOf("image/*", "video/*", "audio/*", "application/pdf", "text/*", "application/zip")) },
                onSchedule = { if (ui.input.isNotBlank()) scheduleDialog = true },
                onQuickReplies = { quickReplies = true },
                onStickers = { stickerPicker = true },
                onRecord = {
                    if (!recording) {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
                        else microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
                    } else {
                        val result = recorder.stop()
                        val file = recordingFile
                        recording = false
                        if (result != null && file != null && result.durationMs >= 500) viewModel.sendVoice(file, result.durationMs, result.waveform)
                        else file?.delete()
                    }
                },
                onSend = {
                    if (hapticEnabled) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    viewModel.send()
                },
                sendOnEnter = sendOnEnter,
            )
        }
    }

    if (stickerPicker) {
        StickerPickerDialog(
            packs = BuiltInStickers.packs,
            onDismiss = { stickerPicker = false },
            onSticker = { asset ->
                viewModel.sendSticker(asset)
                stickerPicker = false
            },
        )
    }

    ui.selected?.let { message ->
        MessageActionsDialog(
            message = message,
            mine = message.senderId == viewModel.currentUid,
            onDismiss = { viewModel.select(null) },
            onReply = { viewModel.setReply(message) },
            onEdit = { editText = message.text; editing = message; viewModel.select(null) },
            onDelete = { if (confirmBeforeDelete) deleteTarget = message else viewModel.delete(message, true); viewModel.select(null) },
            onReact = { emoji -> viewModel.react(message, emoji); viewModel.select(null) },
            onPin = { viewModel.pin(message); viewModel.select(null) },
            onForward = { forwardTarget = message; viewModel.select(null) },
            onSave = { viewModel.saveMessage(message); viewModel.select(null) },
        )
    }


    if (scheduleDialog) {
        AlertDialog(
            onDismissRequest = { scheduleDialog = false },
            title = { Text("Отправить позже") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(ui.input, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    Text("Выберите время", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    listOf(
                        "Через 15 минут" to 15L * 60_000L,
                        "Через 1 час" to 60L * 60_000L,
                        "Через 3 часа" to 3L * 60L * 60_000L,
                        "Завтра" to 24L * 60L * 60_000L,
                    ).forEach { (label, delayMs) ->
                        TextButton(
                            onClick = {
                                viewModel.schedule(System.currentTimeMillis() + delayMs)
                                scheduleDialog = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(label, Modifier.weight(1f)); Icon(Icons.Rounded.Schedule, null) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { scheduleDialog = false }) { Text("Отмена") } },
        )
    }

    if (quickReplies) {
        val replies = listOf(
            "Хорошо, договорились.",
            "Я напишу чуть позже.",
            "Спасибо!",
            "Уже в пути.",
            "Можешь позвонить?",
            "Сейчас занят, отвечу позже.",
            "Да, мне подходит.",
            "Нет, к сожалению, не получится.",
        )
        AlertDialog(
            onDismissRequest = { quickReplies = false },
            title = { Text("Быстрый ответ") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    items(replies) { replyText ->
                        TextButton(
                            onClick = { viewModel.setInput(replyText); quickReplies = false },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(replyText, Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Start) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { quickReplies = false }) { Text("Закрыть") } },
        )
    }

    forwardTarget?.let { message ->
        AlertDialog(
            onDismissRequest = { forwardTarget = null },
            title = { Text("Переслать в…") },
            text = {
                val targets = availableChats.filter { it.id != viewModel.chatId }
                if (targets.isEmpty()) {
                    Text("Сначала создайте ещё один чат или группу.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(targets, key = { it.id }) { target ->
                            TextButton(
                                onClick = { viewModel.forward(message, target.id); forwardTarget = null },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(target.titleFor(viewModel.currentUid), Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (target.type == ChatType.GROUP) "Группа" else "Чат", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { forwardTarget = null }) { Text("Отмена") } },
        )
    }

    editing?.let { message ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Редактировать сообщение") },
            text = { OutlinedTextField(editText, { editText = it.take(8_000) }, Modifier.fillMaxWidth(), minLines = 3, supportingText = { Text("${editText.length}/8000") }) },
            confirmButton = { Button(onClick = { viewModel.edit(message, editText); editing = null }, enabled = editText.isNotBlank()) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Отмена") } },
        )
    }

    deleteTarget?.let { message ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить сообщение?") },
            text = { Text("Можно удалить его только у себя или у всех участников.") },
            confirmButton = { TextButton(onClick = { viewModel.delete(message, true); deleteTarget = null }) { Text("У всех") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { viewModel.delete(message, false); deleteTarget = null }) { Text("У меня") }
                    TextButton(onClick = { deleteTarget = null }) { Text("Отмена") }
                }
            },
        )
    }
}

@Composable
private fun MessageComposer(
    value: String,
    reply: Message?,
    sending: Boolean,
    uploading: Boolean,
    recording: Boolean,
    recordingSeconds: Int,
    onValueChange: (String) -> Unit,
    onCancelReply: () -> Unit,
    onAttach: () -> Unit,
    onSchedule: () -> Unit,
    onQuickReplies: () -> Unit,
    onStickers: () -> Unit,
    onRecord: () -> Unit,
    onSend: () -> Unit,
    sendOnEnter: Boolean,
) {
    GlassPanel(Modifier.fillMaxWidth().imePadding().padding(horizontal = 8.dp, vertical = 6.dp), radius = 24.dp, elevation = 10.dp) {
        Column(Modifier.fillMaxWidth()) {
            if (reply != null) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Reply, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.size(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Ответ ${reply.senderName.ifBlank { reply.senderUsername }}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(reply.text.ifBlank { "Сообщение" }, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onCancelReply) { Icon(Icons.Rounded.Close, "Отменить ответ") }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.16f))
            }
            if (recording) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.size(10.dp))
                    Text("Запись ${recordingSeconds / 60}:${(recordingSeconds % 60).toString().padStart(2, '0')}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = onRecord) { Icon(Icons.Rounded.Stop, "Завершить", tint = MaterialTheme.colorScheme.error) }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp), verticalAlignment = Alignment.Bottom) {
                    IconButton(onClick = onAttach, enabled = !uploading) { Icon(Icons.Rounded.AttachFile, "Прикрепить", tint = MaterialTheme.colorScheme.primary) }
                    IconButton(onClick = onQuickReplies, enabled = !uploading) { Icon(Icons.Rounded.Bolt, "Быстрый ответ", tint = MaterialTheme.colorScheme.primary) }
                    IconButton(onClick = onStickers, enabled = !uploading && !sending) { Icon(Icons.Rounded.InsertEmoticon, "Стикеры", tint = MaterialTheme.colorScheme.primary) }
                    OutlinedTextField(
                        value = value,
                        onValueChange = onValueChange,
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Сообщение") },
                        minLines = 1,
                        maxLines = 5,
                        shape = RoundedCornerShape(22.dp),
                        keyboardOptions = KeyboardOptions(imeAction = if (sendOnEnter) ImeAction.Send else ImeAction.Default),
                        keyboardActions = KeyboardActions(onSend = { if (sendOnEnter) onSend() }),
                    )
                    Spacer(Modifier.size(4.dp))
                    if (value.isNotBlank()) {
                        IconButton(onClick = onSchedule, enabled = !sending && !uploading) { Icon(Icons.Rounded.Schedule, "Отправить позже", tint = MaterialTheme.colorScheme.primary) }
                    }
                    if (value.isBlank()) {
                        IconButton(onClick = onRecord, enabled = !uploading) { Icon(Icons.Rounded.Mic, "Голосовое", tint = MaterialTheme.colorScheme.primary) }
                    } else {
                        IconButton(onClick = onSend, enabled = !sending && !uploading) {
                            if (sending) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Rounded.Send, "Отправить", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StickerPickerDialog(
    packs: List<StickerPack>,
    onDismiss: () -> Unit,
    onSticker: (String) -> Unit,
) {
    var selectedPackId by remember { mutableStateOf(packs.firstOrNull()?.id.orEmpty()) }
    val selected = packs.firstOrNull { it.id == selectedPackId } ?: packs.firstOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Встроенные стикеры") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(min = 360.dp, max = 560.dp)) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(packs, key = { it.id }) { pack ->
                        Surface(
                            modifier = Modifier.clickable { selectedPackId = pack.id },
                            shape = RoundedCornerShape(14.dp),
                            color = if (pack.id == selectedPackId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (pack.id == selectedPackId) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        ) {
                            Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(pack.icon, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.size(5.dp))
                                Text(pack.title, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (selected != null) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        gridItems(selected.assets, key = { it }) { asset ->
                            Surface(
                                modifier = Modifier.aspectRatio(1f).clickable { onSticker(asset) },
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            ) {
                                StickerAssetImage(asset, Modifier.fillMaxSize().padding(4.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
    )
}

@Composable
private fun MessageActionsDialog(
    message: Message,
    mine: Boolean,
    onDismiss: () -> Unit,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onReact: (String) -> Unit,
    onPin: () -> Unit,
    onForward: () -> Unit,
    onSave: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Действия") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LazyRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    items(listOf("👍", "❤️", "😂", "🔥", "😮", "😢")) { emoji -> TextButton(onClick = { onReact(emoji) }) { Text(emoji, style = MaterialTheme.typography.titleLarge) } }
                }
                ActionButton(Icons.Rounded.Reply, "Ответить", onReply)
                ActionButton(Icons.Rounded.PushPin, if (message.pinned) "Открепить" else "Закрепить", onPin)
                ActionButton(Icons.Rounded.Forward, "Переслать", onForward)
                ActionButton(Icons.Rounded.Bookmark, "Сохранить", onSave)
                if (mine && !message.isDeleted && message.text.isNotBlank()) ActionButton(Icons.Rounded.Edit, "Редактировать", onEdit)
                ActionButton(Icons.Rounded.Delete, "Удалить", onDelete, destructive = true)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
    )
}

@Composable
private fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, onClick: () -> Unit, destructive: Boolean = false) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Icon(icon, null, tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(8.dp))
        Text(title, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
    }
}

private fun typingSubtitle(names: List<String>): String = when {
    names.size == 1 -> "${names.first()} печатает…"
    names.size == 2 -> "${names.take(2).joinToString(" и ")} печатают…"
    else -> "Несколько участников печатают…"
}

private fun openFile(context: android.content.Context, file: File, mime: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mime.ifBlank { "*/*" })
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(intent) }
}
