package com.nexachat.app.core.repository

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.nexachat.app.core.database.NexaCacheDb
import com.nexachat.app.core.model.LocalNote
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.model.MessageType
import com.nexachat.app.core.model.OfflinePackInfo
import com.nexachat.app.core.model.SavedMessage
import com.nexachat.app.core.model.ScheduledMessage
import com.nexachat.app.core.model.ScheduledMessageState
import com.nexachat.app.core.work.ScheduledMessageWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

class LocalToolsRepository(
    private val context: Context,
    private val cache: NexaCacheDb,
) {
    private val _notes = MutableStateFlow(cache.notes())
    val notes: StateFlow<List<LocalNote>> = _notes.asStateFlow()

    private val _scheduled = MutableStateFlow(cache.scheduledMessages())
    val scheduled: StateFlow<List<ScheduledMessage>> = _scheduled.asStateFlow()

    private val _saved = MutableStateFlow(cache.savedMessages())
    val saved: StateFlow<List<SavedMessage>> = _saved.asStateFlow()

    val offlinePackInfo = OfflinePackInfo()
    val wallpapers: List<String> = (1..60).map { "nexa_pack/wallpapers/wallpaper_${it.toString().padStart(3, '0')}.jpg" }

    fun refresh() {
        _notes.value = cache.notes()
        _scheduled.value = cache.scheduledMessages()
        _saved.value = cache.savedMessages()
    }

    fun saveNote(existingId: String?, title: String, body: String): LocalNote {
        val now = System.currentTimeMillis()
        val old = existingId?.let { id -> _notes.value.firstOrNull { it.id == id } }
        val note = LocalNote(
            id = old?.id ?: UUID.randomUUID().toString(),
            title = title.trim().ifBlank { "Без названия" }.take(120),
            body = body.trim().take(20_000),
            createdAt = old?.createdAt ?: now,
            updatedAt = now,
        )
        cache.upsertNote(note)
        refresh()
        return note
    }

    fun deleteNote(id: String) {
        cache.deleteNote(id)
        refresh()
    }

    fun scheduleMessage(chatId: String, chatTitle: String, text: String, sendAt: Long): ScheduledMessage {
        require(text.isNotBlank()) { "Введите сообщение" }
        require(sendAt > System.currentTimeMillis() + 5_000) { "Выберите время в будущем" }
        val now = System.currentTimeMillis()
        val item = ScheduledMessage(
            id = UUID.randomUUID().toString(),
            chatId = chatId,
            chatTitle = chatTitle.ifBlank { "Диалог" },
            text = text.trim().take(8_000),
            sendAt = sendAt,
            createdAt = now,
        )
        cache.upsertScheduledMessage(item)
        enqueue(item)
        refresh()
        return item
    }

    fun cancelScheduled(id: String) {
        cache.updateScheduledMessage(id, ScheduledMessageState.CANCELLED)
        WorkManager.getInstance(context).cancelUniqueWork(workName(id))
        refresh()
    }

    fun deleteScheduled(id: String) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(id))
        cache.deleteScheduledMessage(id)
        refresh()
    }

    fun markScheduled(id: String, state: ScheduledMessageState, error: String = "") {
        cache.updateScheduledMessage(id, state, error.take(500))
        refresh()
    }

    fun scheduledById(id: String): ScheduledMessage? = cache.scheduledMessage(id)

    fun saveMessage(message: Message, chatTitle: String) {
        val now = System.currentTimeMillis()
        cache.upsertSavedMessage(
            SavedMessage(
                id = "${message.chatId}:${message.id}",
                chatId = message.chatId,
                chatTitle = chatTitle.ifBlank { "Диалог" },
                messageId = message.id,
                senderName = message.senderName.ifBlank { message.senderUsername.ifBlank { "Пользователь" } },
                text = message.text.ifBlank { if (message.type == MessageType.STICKER) "Стикер" else message.attachmentName.ifBlank { message.type.name.lowercase() } },
                createdAt = message.createdAt,
                savedAt = now,
            ),
        )
        refresh()
    }

    fun deleteSaved(id: String) {
        cache.deleteSavedMessage(id)
        refresh()
    }

    fun readAsset(path: String): ByteArray = context.assets.open(path).use { it.readBytes() }

    fun exportBundle(): Pair<File, Uri> {
        val root = JSONObject()
            .put("format", "NexaChat local tools export")
            .put("version", 1)
            .put("createdAt", System.currentTimeMillis())
            .put("notes", JSONArray().also { array ->
                notes.value.forEach { note ->
                    array.put(JSONObject().put("id", note.id).put("title", note.title).put("body", note.body).put("createdAt", note.createdAt).put("updatedAt", note.updatedAt))
                }
            })
            .put("scheduled", JSONArray().also { array ->
                scheduled.value.forEach { item ->
                    array.put(JSONObject().put("id", item.id).put("chatId", item.chatId).put("chatTitle", item.chatTitle).put("text", item.text).put("sendAt", item.sendAt).put("state", item.state.name).put("error", item.error))
                }
            })
            .put("savedMessages", JSONArray().also { array ->
                saved.value.forEach { item ->
                    array.put(JSONObject().put("id", item.id).put("chatId", item.chatId).put("chatTitle", item.chatTitle).put("messageId", item.messageId).put("senderName", item.senderName).put("text", item.text).put("createdAt", item.createdAt).put("savedAt", item.savedAt))
                }
            })
        val file = File(context.cacheDir, "NexaChat-local-export-${System.currentTimeMillis()}.json")
        file.writeText(root.toString(2))
        return file to FileProvider.getUriForFile(context, "${context.packageName}.files", file)
    }

    fun localStats(): Pair<Int, Int> = cache.chatCount() to cache.messageCount()

    private fun enqueue(item: ScheduledMessage) {
        val delay = (item.sendAt - System.currentTimeMillis()).coerceAtLeast(5_000)
        val request = OneTimeWorkRequestBuilder<ScheduledMessageWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(Data.Builder().putString(ScheduledMessageWorker.KEY_ID, item.id).build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(workName(item.id), ExistingWorkPolicy.REPLACE, request)
    }

    private fun workName(id: String) = "nexachat_scheduled_$id"
}
