package com.nexachat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.media.MediaRepository
import com.nexachat.app.core.model.AccentTheme
import com.nexachat.app.core.model.AuthState
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.settings.SettingsRepository
import com.nexachat.app.core.util.Validation
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AuthPage { WELCOME, OPTIONS, FORM }
enum class RegistrationStep { IDENTITY, ABOUT, APPEARANCE, COMPLETE }

data class AuthUiState(
    val authPage: AuthPage = AuthPage.WELCOME,
    val registrationStep: RegistrationStep = RegistrationStep.IDENTITY,
    val register: Boolean = false,
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val username: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val bio: String = "",
    val selectedAvatarUri: String = "",
    val avatarProgress: Float = 0f,
    val selectedThemeMode: ThemeMode = ThemeMode.LIGHT,
    val selectedAccentTheme: AccentTheme = AccentTheme.OCEAN,
    val loading: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
)

class AuthViewModel(
    private val repository: AuthRepository,
    private val settings: SettingsRepository,
    private val media: MediaRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(AuthUiState())
    val ui: StateFlow<AuthUiState> = _ui.asStateFlow()
    private var appearanceJob: Job? = null

    init {
        val profile = (repository.state.value as? AuthState.SignedIn)?.profile
        if (profile != null) {
            _ui.update {
                it.copy(
                    username = profile.username,
                    firstName = profile.firstName,
                    lastName = profile.lastName,
                    bio = profile.bio,
                    registrationStep = if (profile.username.isBlank()) RegistrationStep.IDENTITY else RegistrationStep.APPEARANCE,
                )
            }
        }
        viewModelScope.launch {
            val current = settings.settings.first()
            _ui.update {
                it.copy(
                    selectedThemeMode = if (current.themeMode == ThemeMode.SYSTEM) ThemeMode.LIGHT else current.themeMode,
                    selectedAccentTheme = current.accentTheme,
                )
            }
        }
    }

    fun showOptions() = _ui.update { it.copy(authPage = AuthPage.OPTIONS, error = null, notice = null) }

    fun showForm(register: Boolean) = _ui.update {
        it.copy(
            authPage = AuthPage.FORM,
            register = register,
            password = "",
            confirmPassword = "",
            error = null,
            notice = null,
        )
    }

    fun backAuth() = _ui.update {
        it.copy(
            authPage = when (it.authPage) {
                AuthPage.FORM -> AuthPage.OPTIONS
                AuthPage.OPTIONS -> AuthPage.WELCOME
                AuthPage.WELCOME -> AuthPage.WELCOME
            },
            error = null,
            notice = null,
        )
    }

    fun setRegister(value: Boolean) = showForm(value)
    fun setEmail(value: String) = _ui.update { it.copy(email = value.take(160), error = null) }
    fun setPassword(value: String) = _ui.update { it.copy(password = value.take(128), error = null) }
    fun setConfirmPassword(value: String) = _ui.update { it.copy(confirmPassword = value.take(128), error = null) }
    fun setUsername(value: String) = _ui.update {
        it.copy(
            username = value.removePrefix("@").filter { char -> char.isLetterOrDigit() || char == '_' }.take(32),
            error = null,
        )
    }
    fun setFirstName(value: String) = _ui.update { it.copy(firstName = value.take(48), error = null) }
    fun setLastName(value: String) = _ui.update { it.copy(lastName = value.take(48), error = null) }
    fun setBio(value: String) = _ui.update { it.copy(bio = value.take(160), error = null) }
    fun setAvatar(uri: Uri?) = _ui.update { it.copy(selectedAvatarUri = uri?.toString().orEmpty(), error = null) }
    fun clearError() = _ui.update { it.copy(error = null) }

    fun submit() {
        val state = _ui.value
        if (state.register && state.password != state.confirmPassword) {
            _ui.update { it.copy(error = "Пароли не совпадают") }
            return
        }
        runAction {
            if (state.register) {
                repository.signUp(state.email, state.password)
                settings.update { it.copy(onboardingPending = true) }
            } else {
                repository.signIn(state.email, state.password)
                val signedIn = repository.state.value as? AuthState.SignedIn
                settings.update { it.copy(onboardingPending = signedIn?.profile?.username.isNullOrBlank()) }
            }
        }
    }

    fun nextIdentity() {
        val state = _ui.value
        Validation.username(state.username)?.let { message ->
            _ui.update { it.copy(error = message) }
            return
        }
        Validation.displayName(state.firstName, state.lastName)?.let { message ->
            _ui.update { it.copy(error = message) }
            return
        }
        _ui.update { it.copy(registrationStep = RegistrationStep.ABOUT, error = null) }
    }

    fun backOnboarding() = _ui.update {
        it.copy(
            registrationStep = when (it.registrationStep) {
                RegistrationStep.IDENTITY -> RegistrationStep.IDENTITY
                RegistrationStep.ABOUT -> RegistrationStep.IDENTITY
                RegistrationStep.APPEARANCE -> RegistrationStep.ABOUT
                RegistrationStep.COMPLETE -> RegistrationStep.APPEARANCE
            },
            error = null,
        )
    }

    fun completeProfile() {
        val state = _ui.value
        runAction(
            onSuccess = { _ui.update { it.copy(registrationStep = RegistrationStep.APPEARANCE) } },
        ) {
            val avatarUrl = state.selectedAvatarUri.takeIf(String::isNotBlank)?.let { raw ->
                media.uploadUri(Uri.parse(raw), scope = "avatars") { progress ->
                    _ui.update { current -> current.copy(avatarProgress = progress) }
                }.downloadUrl
            }.orEmpty()
            repository.completeProfile(
                username = state.username,
                firstName = state.firstName,
                lastName = state.lastName,
                bio = state.bio,
                avatarUrl = avatarUrl,
            )
        }
    }

    fun setThemeMode(value: ThemeMode) {
        _ui.update { it.copy(selectedThemeMode = value, error = null) }
        saveAppearancePreview()
    }

    fun setAccentTheme(value: AccentTheme) {
        _ui.update { it.copy(selectedAccentTheme = value, error = null) }
        saveAppearancePreview()
    }

    private fun saveAppearancePreview() {
        appearanceJob?.cancel()
        appearanceJob = viewModelScope.launch {
            val state = _ui.value
            settings.update {
                it.copy(
                    themeMode = state.selectedThemeMode,
                    accentTheme = state.selectedAccentTheme,
                    dynamicColors = false,
                )
            }
        }
    }

    fun completeAppearance() {
        val state = _ui.value
        runAction(
            onSuccess = { _ui.update { it.copy(registrationStep = RegistrationStep.COMPLETE) } },
        ) {
            settings.update {
                it.copy(
                    themeMode = state.selectedThemeMode,
                    accentTheme = state.selectedAccentTheme,
                    dynamicColors = false,
                )
            }
        }
    }

    fun finishOnboarding() = runAction {
        settings.update { it.copy(onboardingPending = false) }
    }

    fun cancelOnboarding() = runAction {
        settings.update { it.copy(onboardingPending = false) }
        repository.signOut()
    }

    fun resetPassword() {
        val email = _ui.value.email
        runAction(success = "Письмо для сброса пароля отправлено") { repository.resetPassword(email) }
    }

    private fun runAction(
        success: String? = null,
        onSuccess: () -> Unit = {},
        action: suspend () -> Unit,
    ) {
        if (_ui.value.loading) return
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null, notice = null, avatarProgress = 0f) }
            runCatching { action() }
                .onSuccess {
                    _ui.update { it.copy(loading = false, notice = success) }
                    onSuccess()
                }
                .onFailure { error ->
                    _ui.update {
                        it.copy(
                            loading = false,
                            error = error.message ?: "Неизвестная ошибка",
                            avatarProgress = 0f,
                        )
                    }
                }
        }
    }

    class Factory(
        private val repository: AuthRepository,
        private val settings: SettingsRepository,
        private val media: MediaRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            AuthViewModel(repository, settings, media) as T
    }
}
