package com.nexachat.app.ui.screens.auth

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.R
import com.nexachat.app.core.model.AccentTheme
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.viewmodel.AuthPage
import com.nexachat.app.ui.viewmodel.AuthUiState
import com.nexachat.app.ui.viewmodel.AuthViewModel
import com.nexachat.app.ui.viewmodel.RegistrationStep

@Composable
fun AuthScreen(viewModel: AuthViewModel) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    OnboardingBackground {
        Crossfade(targetState = state.authPage, label = "auth-page") { page ->
            when (page) {
                AuthPage.WELCOME -> WelcomePage(onStart = viewModel::showOptions)
                AuthPage.OPTIONS -> AuthOptionsPage(
                    onBack = viewModel::backAuth,
                    onSignIn = { viewModel.showForm(false) },
                    onRegister = { viewModel.showForm(true) },
                )
                AuthPage.FORM -> CredentialsPage(state, viewModel)
            }
        }
    }
}

@Composable
private fun WelcomePage(onStart: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        BrandHero()
        Spacer(Modifier.weight(1f))
        OnboardingPrimaryButton("Начать", onStart)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun AuthOptionsPage(
    onBack: () -> Unit,
    onSignIn: () -> Unit,
    onRegister: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        OnboardingTopBar(onBack)
        Spacer(Modifier.weight(0.7f))
        BrandHero(subtitle = "Простой, быстрый и приватный мессенджер")
        Spacer(Modifier.weight(1f))
        OnboardingPrimaryButton("Войти по электронной почте", onSignIn)
        Spacer(Modifier.height(10.dp))
        OnboardingSecondaryButton("Зарегистрироваться без номера", onRegister)
        Spacer(Modifier.height(18.dp))
        Text(
            "Для аккаунта без номера используется электронная почта. PIN-код не требуется.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun CredentialsPage(state: AuthUiState, viewModel: AuthViewModel) {
    var passwordVisible by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 12.dp),
    ) {
        OnboardingTopBar(viewModel::backAuth)
        Spacer(Modifier.height(26.dp))
        Text(
            if (state.register) "Аккаунт без номера" else "С возвращением",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (state.register) "Создайте аккаунт по электронной почте — номер телефона и PIN-код не нужны."
            else "Войдите в NexaChat по электронной почте.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(22.dp))
        GlassPanel(Modifier.fillMaxWidth(), radius = 24.dp) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                OutlinedTextField(
                    value = state.email,
                    onValueChange = viewModel::setEmail,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Электронная почта") },
                    leadingIcon = { Icon(Icons.Rounded.AlternateEmail, null) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                    shape = RoundedCornerShape(16.dp),
                )
                OutlinedTextField(
                    value = state.password,
                    onValueChange = viewModel::setPassword,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Пароль") },
                    supportingText = { if (state.register) Text("Минимум 6 символов") },
                    leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                if (passwordVisible) "Скрыть пароль" else "Показать пароль",
                            )
                        }
                    },
                    singleLine = true,
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = if (state.register) ImeAction.Next else ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                    shape = RoundedCornerShape(16.dp),
                )
                AnimatedVisibility(state.register) {
                    OutlinedTextField(
                        value = state.confirmPassword,
                        onValueChange = viewModel::setConfirmPassword,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Повторите пароль") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                        shape = RoundedCornerShape(16.dp),
                    )
                }
                ErrorBanner(state.error, viewModel::clearError)
                if (!state.notice.isNullOrBlank()) {
                    Text(
                        state.notice.orEmpty(),
                        color = Color(0xFF30A14E),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                OnboardingPrimaryButton(
                    if (state.register) "Создать аккаунт" else "Войти",
                    viewModel::submit,
                    loading = state.loading,
                )
                if (!state.register) {
                    Text(
                        "Забыли пароль?",
                        Modifier.align(Alignment.CenterHorizontally).clickable(onClick = viewModel::resetPassword).padding(8.dp),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            if (state.register) "Уже есть аккаунт? Войти" else "Нет аккаунта? Зарегистрироваться без номера",
            Modifier.align(Alignment.CenterHorizontally).clickable { viewModel.showForm(!state.register) }.padding(10.dp),
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "Продолжая, вы соглашаетесь с правилами сервиса и политикой конфиденциальности.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun ProfileSetupScreen(viewModel: AuthViewModel, email: String) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    OnboardingBackground {
        Crossfade(targetState = state.registrationStep, label = "registration-step") { step ->
            when (step) {
                RegistrationStep.IDENTITY -> IdentityStep(state, email, viewModel)
                RegistrationStep.ABOUT -> AboutStep(state, viewModel)
                RegistrationStep.APPEARANCE -> AppearanceStep(state, viewModel)
                RegistrationStep.COMPLETE -> CompleteStep(state.loading, viewModel::finishOnboarding)
            }
        }
    }
}

@Composable
private fun IdentityStep(state: AuthUiState, email: String, viewModel: AuthViewModel) {
    RegistrationPage(
        step = 1,
        title = "Аккаунт без номера",
        subtitle = "Придумайте username и укажите имя, которое увидят собеседники.",
        onBack = viewModel::cancelOnboarding,
    ) {
        GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(email, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    state.username,
                    viewModel::setUsername,
                    Modifier.fillMaxWidth(),
                    label = { Text("Username") },
                    prefix = { Text("@") },
                    leadingIcon = { Icon(Icons.Rounded.Badge, null) },
                    supportingText = { Text("5–32 символа: буквы, цифры и _") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    shape = RoundedCornerShape(16.dp),
                )
                OutlinedTextField(
                    state.firstName,
                    viewModel::setFirstName,
                    Modifier.fillMaxWidth(),
                    label = { Text("Имя") },
                    leadingIcon = { Icon(Icons.Rounded.Person, null) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    shape = RoundedCornerShape(16.dp),
                )
                OutlinedTextField(
                    state.lastName,
                    viewModel::setLastName,
                    Modifier.fillMaxWidth(),
                    label = { Text("Фамилия") },
                    leadingIcon = { Icon(Icons.Rounded.Person, null) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { viewModel.nextIdentity() }),
                    shape = RoundedCornerShape(16.dp),
                )
            }
        }
        ErrorBanner(state.error, viewModel::clearError)
        OnboardingPrimaryButton("Далее", viewModel::nextIdentity, loading = state.loading)
    }
}

@Composable
private fun AboutStep(state: AuthUiState, viewModel: AuthViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent(), viewModel::setAvatar)
    RegistrationPage(
        step = 2,
        title = "О себе",
        subtitle = "Добавьте фото и пару слов о себе — этот шаг можно пропустить.",
        onBack = viewModel::backOnboarding,
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            AvatarChooser(state.selectedAvatarUri) { picker.launch("image/*") }
            Spacer(Modifier.height(10.dp))
            Text(
                if (state.selectedAvatarUri.isBlank()) "Выбрать фото" else "Изменить фото",
                Modifier.clickable { picker.launch("image/*") }.padding(8.dp),
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
            )
        }
        GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp) {
            OutlinedTextField(
                state.bio,
                viewModel::setBio,
                Modifier.fillMaxWidth().padding(14.dp),
                label = { Text("Расскажите о себе…") },
                minLines = 4,
                supportingText = { Text("${state.bio.length}/160") },
                shape = RoundedCornerShape(16.dp),
            )
        }
        if (state.loading && state.selectedAvatarUri.isNotBlank()) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Загружаем фото…", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.material3.LinearProgressIndicator(
                    progress = { state.avatarProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        ErrorBanner(state.error, viewModel::clearError)
        OnboardingPrimaryButton("Продолжить", viewModel::completeProfile, loading = state.loading)
        Text(
            "Пропустить",
            Modifier.align(Alignment.CenterHorizontally).clickable(onClick = viewModel::completeProfile).padding(10.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun AppearanceStep(state: AuthUiState, viewModel: AuthViewModel) {
    RegistrationPage(
        step = 3,
        title = "Выберите тему",
        subtitle = "Настройте внешний вид NexaChat. Позже это можно изменить в настройках.",
        onBack = viewModel::backOnboarding,
    ) {
        GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PreviewMessage("Привет! Как дела?", incoming = true)
                PreviewMessage("Всё хорошо, спасибо 😊", incoming = false)
                PreviewMessage("Пишу из NexaChat", incoming = true)
                PreviewMessage("Рад знакомству!", incoming = false)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ThemeChoice(
                title = "Светлая",
                icon = Icons.Rounded.LightMode,
                selected = state.selectedThemeMode == ThemeMode.LIGHT,
                darkPreview = false,
                modifier = Modifier.weight(1f),
            ) { viewModel.setThemeMode(ThemeMode.LIGHT) }
            ThemeChoice(
                title = "Тёмная",
                icon = Icons.Rounded.DarkMode,
                selected = state.selectedThemeMode == ThemeMode.DARK,
                darkPreview = true,
                modifier = Modifier.weight(1f),
            ) { viewModel.setThemeMode(ThemeMode.DARK) }
        }
        Text("Акцентный цвет", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            AccentTheme.entries.forEach { accent ->
                AccentChoice(accent, selected = accent == state.selectedAccentTheme) {
                    viewModel.setAccentTheme(accent)
                }
            }
        }
        ErrorBanner(state.error, viewModel::clearError)
        OnboardingPrimaryButton("Продолжить", viewModel::completeAppearance, loading = state.loading)
    }
}

@Composable
private fun CompleteStep(loading: Boolean, onDone: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        Image(painterResource(R.drawable.ic_launcher), "NexaChat", Modifier.size(104.dp))
        Spacer(Modifier.height(18.dp))
        Text("NexaChat", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Аккаунт создан", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        OnboardingPrimaryButton("Готово", onDone, loading = loading)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun RegistrationPage(
    step: Int,
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        OnboardingTopBar(onBack)
        StepIndicator(step)
        Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        content()
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun StepIndicator(active: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(4) { index ->
            Box(
                Modifier.weight(1f).height(4.dp).clip(CircleShape)
                    .background(
                        if (index < active) MaterialTheme.colorScheme.onBackground
                        else MaterialTheme.colorScheme.surfaceVariant,
                    ),
            )
        }
    }
}

@Composable
private fun OnboardingTopBar(onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Назад")
        }
        Spacer(Modifier.weight(1f))
        Image(painterResource(R.drawable.ic_launcher), "NexaChat", Modifier.size(34.dp))
    }
}

@Composable
private fun BrandHero(subtitle: String? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.ic_launcher), "NexaChat", Modifier.size(112.dp))
        Spacer(Modifier.height(16.dp))
        Text("NexaChat", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        if (!subtitle.isNullOrBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                subtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}

@Composable
private fun OnboardingPrimaryButton(
    text: String,
    onClick: () -> Unit,
    loading: Boolean = false,
) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    Button(
        onClick = onClick,
        enabled = !loading,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (dark) Color.White else Color.Black,
            contentColor = if (dark) Color.Black else Color.White,
        ),
    ) {
        if (loading) {
            CircularProgressIndicator(
                Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = if (dark) Color.Black else Color.White,
            )
        } else Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun OnboardingSecondaryButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurface,
        ),
    ) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun AvatarChooser(uri: String, onClick: () -> Unit) {
    val context = LocalContext.current
    val bitmap = remember(uri) {
        uri.takeIf(String::isNotBlank)?.let { raw ->
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(raw))
                    ?.use { input -> BitmapFactory.decodeStream(input) }
                    ?.asImageBitmap()
            }.getOrNull()
        }
    }
    Box(
        Modifier.size(108.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(bitmap, "Фото профиля", Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Rounded.Person, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Surface(
            modifier = Modifier.align(Alignment.BottomEnd).size(34.dp),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
        ) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.AddAPhoto, null, Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun PreviewMessage(text: String, incoming: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (incoming) Arrangement.Start else Arrangement.End) {
        Surface(
            color = if (incoming) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary,
            contentColor = if (incoming) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onPrimary,
            shape = RoundedCornerShape(16.dp),
        ) {
            Text(text, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ThemeChoice(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    darkPreview: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val previewBackground = if (darkPreview) Color(0xFF17171A) else Color(0xFFF3F3F7)
    val previewText = if (darkPreview) Color.White else Color.Black
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface)
            .border(
                if (selected) 2.dp else 1.dp,
                if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                RoundedCornerShape(18.dp),
            ).clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1.45f).clip(RoundedCornerShape(12.dp)).background(previewBackground),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = previewText) }
        Text(title, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun AccentChoice(accent: AccentTheme, selected: Boolean, onClick: () -> Unit) {
    val color = when (accent) {
        AccentTheme.OCEAN -> Color(0xFF007AFF)
        AccentTheme.VIOLET -> Color(0xFF7C4DFF)
        AccentTheme.ROSE -> Color(0xFFE83E8C)
        AccentTheme.MINT -> Color(0xFF0AAE76)
        AccentTheme.SUNSET -> Color(0xFFF47721)
    }
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(color).clickable(onClick = onClick)
            .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onBackground, CircleShape) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Rounded.Check, "Выбрано", tint = Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun OnboardingBackground(content: @Composable () -> Unit) {
    val background = MaterialTheme.colorScheme.background
    val dot = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.42f)
    Box(Modifier.fillMaxSize().background(background)) {
        Canvas(Modifier.matchParentSize()) {
            val dots = listOf(
                Triple(0.08f, 0.18f, 8f), Triple(0.28f, 0.10f, 13f), Triple(0.77f, 0.14f, 7f),
                Triple(0.91f, 0.28f, 12f), Triple(0.12f, 0.45f, 10f), Triple(0.82f, 0.55f, 8f),
                Triple(0.18f, 0.78f, 14f), Triple(0.52f, 0.88f, 7f), Triple(0.88f, 0.84f, 11f),
            )
            dots.forEach { (x, y, radius) ->
                drawCircle(dot, radius.dp.toPx(), center = androidx.compose.ui.geometry.Offset(size.width * x, size.height * y))
            }
        }
        content()
    }
}
