#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

python3 -m json.tool firebase/database.rules.json >/dev/null
node --check tools/migration/migrate-public-profiles.mjs
node --check functions/index.js
sh -n gradlew

python3 - <<'PY'
from pathlib import Path
from xml.etree import ElementTree

for path in Path('app/src/main').rglob('*.xml'):
    ElementTree.parse(path)

for path in Path('.').rglob('*'):
    if not path.is_file() or path.as_posix() == 'tools/verify-static.sh' or any(part in {'.git', 'build', '.gradle'} for part in path.parts):
        continue
    raw = path.read_bytes()
    if b'-----BEGIN PRIVATE KEY-----' in raw or b'"private_key"' in raw:
        raise SystemExit(f'Potential private credential in {path}')

bad_imports = (
    'import androidx.compose.foundation.layout.weight',
    'import androidx.compose.foundation.layout.matchParentSize',
)
for path in Path('app/src/main/java').rglob('*.kt'):
    text = path.read_text(encoding='utf-8')
    for bad_import in bad_imports:
        if bad_import in text:
            raise SystemExit(f'Invalid Compose member-extension import in {path}: {bad_import}')
    if text.count('{') != text.count('}'):
        raise SystemExit(f'Unbalanced braces in {path}')

required = [
    Path('firebase/storage.rules'),
    Path('app/src/main/java/com/nexachat/app/core/media/MediaRepository.kt'),
    Path('app/src/main/java/com/nexachat/app/ui/components/LiquidGlass.kt'),
    Path('app/src/main/java/com/nexachat/app/ui/screens/settings/ChatAppearanceScreen.kt'),
    Path('app/src/main/java/com/nexachat/app/core/repository/LocalToolsRepository.kt'),
    Path('app/src/main/java/com/nexachat/app/core/stickers/BuiltInStickers.kt'),
    Path('app/src/main/java/com/nexachat/app/ui/components/StickerAssetImage.kt'),
    Path('tools/generate_feature_pack.py'),
    Path('functions/index.js'),
    Path('app/src/main/java/com/nexachat/app/core/security/E2eRepository.kt'),
    Path('app/src/main/java/com/nexachat/app/core/security/E2eTrustStore.kt'),
    Path('app/src/main/java/com/nexachat/app/core/push/NexaMessagingService.kt'),
    Path('app/src/main/java/com/nexachat/app/core/push/CallActionReceiver.kt'),
    Path('app/src/main/java/com/nexachat/app/CallActivity.kt'),
    Path('app/src/main/java/com/nexachat/app/ui/screens/settings/SecurityScreen.kt'),
]
for path in required:
    if not path.exists():
        raise SystemExit(f'Missing required NexaChat file: {path}')

manifest = Path('app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
if 'android:scheme="nexachat" android:host=' in manifest:
    raise SystemExit('Custom deep-link scheme and host must be split into separate data tags')
if manifest.count('<intent-filter') < 3:
    raise SystemExit('Expected launcher, custom-link and HTTPS App Link intent filters')


root_ui = Path('app/src/main/java/com/nexachat/app/ui/NexaChatRoot.kt').read_text(encoding='utf-8')
if 'Routes.HUB' in root_ui or '"Инструменты"' in root_ui:
    raise SystemExit('Tools must not be present in the main bottom navigation')
if 'Routes.CHAT_APPEARANCE' not in root_ui:
    raise SystemExit('Chat appearance settings route is missing')

models = Path('app/src/main/java/com/nexachat/app/core/model/Models.kt').read_text(encoding='utf-8')
for token in ('WallpaperStyle.CLEAN', 'dashboardWidgets', 'chatWallpaperAsset', 'chatWallpaperDim', 'chatBubbleRadius', 'chatMessageSpacing', 'chatTextScale', 'ScheduledMessage', 'TEXT, IMAGE, VIDEO, FILE, VOICE, STICKER, SYSTEM'):
    if token not in models:
        raise SystemExit(f'Missing 3.3 compatibility token: {token}')


feature_generator = Path('tools/generate_feature_pack.py').read_text(encoding='utf-8')
compile(feature_generator, 'tools/generate_feature_pack.py', 'exec')

assets_root = Path('app/src/main/assets/nexa_pack')
if assets_root.exists():
    if any(path.is_file() for path in (assets_root / 'sounds').rglob('*')) if (assets_root / 'sounds').exists() else False:
        raise SystemExit('Audio tracks must not be bundled in the feature pack')
    wallpapers = list((assets_root / 'wallpapers').glob('wallpaper_*.jpg')) if (assets_root / 'wallpapers').exists() else []
    stickers = list((assets_root / 'stickers').rglob('sticker_*.png')) if (assets_root / 'stickers').exists() else []
    if wallpapers and len(wallpapers) != 60:
        raise SystemExit(f'Expected 60 HD wallpapers, found {len(wallpapers)}')
    if stickers and len(stickers) != 180:
        raise SystemExit(f'Expected 180 built-in stickers, found {len(stickers)}')

chat_repo = Path('app/src/main/java/com/nexachat/app/core/repository/ChatRepository.kt').read_text(encoding='utf-8')
for token in ('"orderBy" to JSONObject.quote("createdAt")', 'if (error.statusCode == 400) database.getObject', 'e2e.encrypt', 'map(e2e::decrypt)'):
    if token not in chat_repo:
        raise SystemExit(f'Missing secure chat token: {token}')

e2e = Path('app/src/main/java/com/nexachat/app/core/security/E2eRepository.kt').read_text(encoding='utf-8')
for token in ('mediaKey = ""', 'mediaIv = ""', 'trustStore.verifyOrPin'):
    if token not in e2e:
        raise SystemExit(f'Missing E2E privacy token: {token}')

functions = Path('functions/index.js').read_text(encoding='utf-8')
for token in ('exports.messagePush', 'exports.callPush', 'exports.expireCalls', 'exports.revokeAllSessions', 'exports.deleteAccount'):
    if token not in functions:
        raise SystemExit(f'Missing backend function: {token}')

rules = Path('firebase/database.rules.json').read_text(encoding='utf-8')
for token in ('deviceKeys', 'deviceSessions', 'pushTokens', 'callSignals', 'cipherText'):
    if token not in rules:
        raise SystemExit(f'Missing secure Firebase rule: {token}')
PY


if grep -R "sessionUid" app/src/main/java >/dev/null; then
  echo "Undefined legacy sessionUid reference found" >&2
  exit 1
fi

printf 'Static verification passed.\n'

# NexaChat must not reintroduce the animated glass wallpaper.
if grep -R "drawLiquidWallpaper\|rememberInfiniteTransition(label = "nexa-liquid")" app/src/main/java/com/nexachat/app/ui/components >/dev/null; then
  echo "Animated glass wallpaper found in current design" >&2
  exit 1
fi
