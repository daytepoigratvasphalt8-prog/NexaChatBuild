# Build status

Static project verification passes locally. The GitHub Actions workflow performs:

1. source archive SHA-256 verification;
2. offline Power Pack generation;
3. static checks;
4. unit tests;
5. debug APK build and signature verification;
6. hard validation that the APK is at least 100 MiB;
7. artifact upload before non-blocking Android Lint.
