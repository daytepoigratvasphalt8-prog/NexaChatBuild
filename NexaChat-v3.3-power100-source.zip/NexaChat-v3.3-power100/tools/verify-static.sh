#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

python3 -m json.tool firebase/database.rules.json >/dev/null
node --check tools/migration/migrate-public-profiles.mjs
sh -n gradlew

python3 - <<'PY'
from pathlib import Path
from xml.etree import ElementTree

for path in Path('app/src/main').rglob('*.xml'):
    ElementTree.parse(path)

for path in Path('.').rglob('*'):
    if not path.is_file() or path.as_posix() == 'tools/verify-static.sh' or any(part in {'.git', 'build', '.gradle'} for part in path.parts):
        continue
    raw = path.read_bytes()
    if b'-----BEGIN PRIVATE KEY-----' in raw or b'"private_key"' in raw:
        raise SystemExit(f'Potential private credential in {path}')

bad_imports = (
    'import androidx.compose.foundation.layout.weight',
    'import androidx.compose.foundation.layout.matchParentSize',
)
for path in Path('app/src/main/java').rglob('*.kt'):
    text = path.read_text(encoding='utf-8')
    for bad_import in bad_imports:
        if bad_import in text:
            raise SystemExit(f'Invalid Compose member-extension import in {path}: {bad_import}')
    if text.count('{') != text.count('}'):
        raise SystemExit(f'Unbalanced braces in {path}')

required = [
    Path('firebase/storage.rules'),
    Path('app/src/main/java/com/nexachat/app/core/media/MediaRepository.kt'),
    Path('app/src/main/java/com/nexachat/app/ui/components/LiquidGlass.kt'),
    Path('app/src/main/java/com/nexachat/app/ui/screens/hub/HubScreen.kt'),
    Path('app/src/main/java/com/nexachat/app/core/repository/LocalToolsRepository.kt'),
    Path('tools/generate_offline_pack.py'),
]
for path in required:
    if not path.exists():
        raise SystemExit(f'Missing required NexaChat file: {path}')

manifest = Path('app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
if 'android:scheme="nexachat" android:host=' in manifest:
    raise SystemExit('Custom deep-link scheme and host must be split into separate data tags')
if manifest.count('<intent-filter') < 3:
    raise SystemExit('Expected launcher, custom-link and HTTPS App Link intent filters')

compile(Path('tools/generate_offline_pack.py').read_text(encoding='utf-8'), 'tools/generate_offline_pack.py', 'exec')

models = Path('app/src/main/java/com/nexachat/app/core/model/Models.kt').read_text(encoding='utf-8')
for token in ('WallpaperStyle.CLEAN', 'dashboardWidgets', 'glassShine', 'dockLabels', 'chatWallpaperAsset', 'ScheduledMessage'):
    if token not in models:
        raise SystemExit(f'Missing 3.3 compatibility token: {token}')
PY

printf 'Static verification passed.\n'

# NexaChat 3.3 must not reintroduce the animated glass wallpaper.
if grep -R "drawLiquidWallpaper\|rememberInfiniteTransition(label = "nexa-liquid")" app/src/main/java/com/nexachat/app/ui/components >/dev/null; then
  echo "Animated glass wallpaper found in Power 100 design" >&2
  exit 1
fi
