# NexaChat 3.3.0 Power 100

- Added a fifth **Tools** tab with local notes, scheduled messages, saved messages, offline wallpapers, ambient sounds, local statistics, and JSON export.
- Added true scheduled sending through WorkManager with cancellation, status tracking, retry, and persistence in SQLite.
- Added message bookmarks available from the long-press message menu.
- Added quick-reply templates in the composer.
- Added selectable offline chat wallpapers and 12 looping ambient tracks.
- Added a CI-generated **Power Pack 100** containing 40 high-resolution procedural wallpapers and 12 offline audio tracks.
- Added an APK size gate: the build fails if the final APK is below 100 MiB.
- Upgraded the local database to schema version 4 for notes, schedules, and saved messages.
- Kept the clean, non-glass 3.2 visual style.
