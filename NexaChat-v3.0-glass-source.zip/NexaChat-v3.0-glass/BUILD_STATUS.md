# Build status

Version: **3.0.0**  
Application ID: `com.nexachat.app`  
Debug application ID: `com.nexachat.app.debug`  
Compile/target SDK: **36**  
Minimum SDK: **26**  
Java: **17**

## Completed checks in the generation environment

- Realtime Database rules parse as JSON.
- Android XML resources parse successfully.
- Shell scripts pass syntax validation.
- Migration JavaScript passes Node syntax validation.
- Static secret scan finds no embedded private key.
- Pure Kotlin model/validation smoke tests are included.

## Build verification

A full Android compilation requires Android SDK and Maven access. The supplied GitHub Actions workflow runs:

1. static verification;
2. unit tests;
3. debug APK compilation;
4. Android lint;
5. APK artifact upload;
6. build log upload if compilation fails.
