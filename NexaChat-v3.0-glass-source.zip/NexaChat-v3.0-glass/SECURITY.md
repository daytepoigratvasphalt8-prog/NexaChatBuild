# Security policy

Report vulnerabilities privately to the repository owner. Do not open a public issue containing credentials, tokens, private messages or exploitable account data.

NexaChat stores Firebase refresh/session material in Android Keystore-backed encrypted storage. The APK must contain only public Firebase client configuration; never add a service-account private key or administrative database secret.

Before public deployment:

- deploy the supplied Realtime Database and Storage rules;
- enable App Check where compatible with the chosen REST architecture;
- rate-limit account discovery and media uploads through a trusted backend;
- add server-side moderation and push fan-out;
- review privacy disclosures and retention requirements;
- rotate credentials if they were ever committed to Git.
