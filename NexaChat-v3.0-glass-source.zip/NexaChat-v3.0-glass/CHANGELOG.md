# Changelog

## 3.0.0 — Liquid Glass

### Interface
- Rebuilt the main navigation, chat list, conversation, profile, settings, contacts, authentication and group information screens around translucent Liquid Glass panels.
- Added animated Aurora, Blobs, Midnight and Clean wallpapers.
- Added Ocean, Violet, Rose, Mint and Sunset accent palettes.
- Added Liquid Glass, Soft and Minimal message bubble styles.
- Added adjustable glass intensity, font scale, contrast and reduced-motion settings.
- Preserved the original NexaChat application icon.

### Messaging
- Added photo, video, audio/document and generic file attachments.
- Added voice recording, waveform rendering and 0.5×–2× playback.
- Added upload progress, local media cache and safe file opening through FileProvider.
- Added forwarding to another existing chat, pinning, replies, reactions, editing and both delete modes.
- Added in-chat search and link cards.
- Added admin-only posting enforcement on both client and Firebase rules.
- Raised group capacity to 200 members.

### People and groups
- Added contacts, favourites and blocked-user storage.
- Added profile photo upload, username editing, status, bio, copy/share actions and account recovery actions.
- Added group photo, title, description, member search/addition, roles, removal and group permissions.

### Reliability and backend
- Added Firebase Storage REST integration with authenticated uploads and a 50 MB limit.
- Added Storage rules and expanded Realtime Database rules for media, contacts, roles and new chat fields.
- Kept client-generated message IDs and offline outbox retry behaviour.
- Fixed chat metadata updates so group edits do not overwrite another member’s mute/archive/pin preferences.
