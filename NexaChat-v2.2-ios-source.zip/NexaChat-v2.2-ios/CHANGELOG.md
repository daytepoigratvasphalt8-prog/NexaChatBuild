# Changelog

## 2.2.0

- Fixed people search on legacy Firebase databases and installations without deployed query indexes.
- Added exact username lookup plus safe publicProfiles/users compatibility fallbacks.
- Prevented raw Firebase HTTP 400 errors from appearing in the new-conversation screen.
- Fixed invisible black NexaChat wordmark and authentication headings in dark mode.
- Rebuilt the profile area in a Telegram-inspired grouped layout.
- Added editable username with conflict-safe claiming and cleanup of the old username index.
- Added profile link copy/share actions, email verification and password reset actions.
- Added clearer profile save notices and validation.


## 2.1.1

- Fixed the Settings cache action failing to compile because `ChatRepository.clearCache()` was missing.
- Cache clearing now preserves queued and sending messages in the local outbox.
- Reset in-memory chat, message and typing state after cache cleanup.

## 2.1.0

- Restored the original NexaChat 1.6 launcher and in-app brand icon.
- Fixed false offline detection on dual-SIM, VPN and OEM network stacks.
- Reworked the interface with an iOS-inspired neutral palette, grouped settings and segmented controls.
- Refined the login, registration and profile-completion screens.
- Expanded settings with message time, typing status, notification preview/vibration, background sync, reduced motion and delete confirmation.
- Connected the new settings to chat, notification and synchronization behavior.
- Moved the project to stable Android SDK 36 for reproducible GitHub Actions builds.

## 2.0.0

- Rewritten in Kotlin and Jetpack Compose.
- Added offline-first cache, drafts and optimistic message retry.
- Added realtime streaming with reconnect and automatic token refresh.
- Added direct/group chats, reactions, replies, edit/delete and read receipts.
- Added public profile index that excludes email.
- Added encrypted session storage through Android Keystore.
- Added themes, accessibility options, profile/settings screens and deep links.
- Added background sync, notifications, hardened Firebase rules and migration tooling.
- Added automated tests, lint, debug CI and signed APK/AAB release workflow.
