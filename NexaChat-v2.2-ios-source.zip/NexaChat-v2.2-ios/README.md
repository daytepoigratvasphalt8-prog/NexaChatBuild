# NexaChat 2.1

NexaChat 2.2 is a complete Android rewrite of the original 1.6 prototype. It keeps the existing Firebase Authentication and Realtime Database project compatible while replacing the legacy Java/View layer with a Kotlin + Jetpack Compose application built around offline-first messaging.

## What is included

- Email registration, login, password reset and email verification.
- Unique usernames with conflict-safe ETag claiming.
- Direct and group chats, member management and deterministic direct-chat IDs.
- Realtime Firebase REST streaming with reconnect and token refresh.
- Offline SQLite cache, drafts, an idempotent outbox and automatic retry after reconnect.
- Replies, reactions, edit/delete (including persistent local hide), read receipts, typing status and unread counters.
- Chat pin, mute and archive preferences.
- Public profile search by username or display name without exposing private email addresses.
- Encrypted authentication session storage through Android Keystore/AES-GCM.
- iOS-inspired system/light/dark themes, optional dynamic colors, large text, high contrast and reduced motion.
- Restored original v1.6 icon and expanded functional settings for messages, privacy, notifications and data usage.
- Legacy-safe people search and Telegram-inspired profile management with username editing, sharing and account actions.
- Background synchronization and notification channels.
- Hardened Realtime Database rules, migration tooling, unit tests, lint and CI.
- Reproducible debug builds plus signed APK/AAB release workflow.

## Requirements

- Android Studio with JDK 17.
- Android SDK Platform 36.
- Firebase Email/Password Authentication enabled.
- Firebase Realtime Database.

The app supports Android 8.0 and newer (`minSdk 26`).

## First build

1. Copy `local.properties.example` to `local.properties`.
2. Set `NEXA_FIREBASE_API_KEY`, `NEXA_DATABASE_URL` and `NEXA_PROJECT_ID`.
3. Open the project in Android Studio, or run:

```bash
./tools/verify-static.sh
./gradlew :app:assembleDebug
```

The wrapper bootstrap verifies the official Gradle wrapper JAR checksum before executing it.

## Backend rollout

Do not deploy the hardened rules before migrating legacy users to `publicProfiles`.

```bash
cd tools/migration
npm install
export GOOGLE_APPLICATION_CREDENTIALS=/secure/path/service-account.json
export NEXA_DATABASE_URL=https://your-database-url
npm run migrate:public-profiles
cd ../..
cp .firebaserc.example .firebaserc
firebase deploy --only database
```

Each user who signs in with v2 is also migrated automatically. See `docs/MIGRATION.md` for the full rollout and rollback procedure.

## GitHub Actions secrets

Debug CI can use:

- `NEXA_FIREBASE_API_KEY`
- `NEXA_DATABASE_URL`
- `NEXA_PROJECT_ID`

Signed releases additionally require:

- `NEXA_KEYSTORE_B64`
- `NEXA_STORE_PASSWORD`
- `NEXA_KEY_ALIAS`
- `NEXA_KEY_PASSWORD`

Push a tag such as `v2.1.0` to build a signed APK and AAB and attach their SHA-256 checksums to a GitHub Release.

## Project map

- `app/` — Android application.
- `firebase/` — hardened Realtime Database rules.
- `tools/migration/` — one-time legacy profile migration.
- `.github/workflows/` — debug verification and signed release pipelines.
- `docs/` — architecture, security, testing, rollout and audit notes.
- `BUILD_STATUS.md` — checks completed locally and checks delegated to CI.

## Important security note

A Firebase Android API key is a public client identifier, not a database password. Security is enforced by Authentication and Realtime Database Rules. Never place a service-account key, release keystore or passwords in the repository.
