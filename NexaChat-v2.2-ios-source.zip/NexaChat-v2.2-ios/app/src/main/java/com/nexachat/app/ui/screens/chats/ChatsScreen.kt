package com.nexachat.app.ui.screens.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.util.TimeFormat
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaLogo
import com.nexachat.app.ui.viewmodel.ChatFilter
import com.nexachat.app.ui.viewmodel.ChatsViewModel

@Composable
fun ChatsScreen(
    viewModel: ChatsViewModel,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
) {
    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val meta by viewModel.meta.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp, start = 16.dp, end = 16.dp, bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Чаты", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        NexaLogo(compact = true)
                    }
                    IconButton(onClick = viewModel::refresh, enabled = !meta.refreshing) {
                        Icon(Icons.Rounded.Refresh, "Обновить", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                TextField(
                    value = meta.query,
                    onValueChange = viewModel::setQuery,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    placeholder = { Text("Поиск") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent,
                    ),
                )

                FilterSelector(meta.filter, viewModel::setFilter)
                ErrorBanner(meta.error, viewModel::clearError)
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNewChat,
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            ) {
                Icon(Icons.Rounded.Add, "Новый чат")
            }
        },
    ) { padding ->
        if (chats.isEmpty()) {
            EmptyState(
                title = if (meta.query.isBlank()) "Пока нет чатов" else "Ничего не найдено",
                message = if (meta.query.isBlank()) {
                    "Найдите человека по username или создайте группу."
                } else {
                    "Попробуйте изменить запрос или фильтр."
                },
                modifier = Modifier.fillMaxSize().padding(padding),
                icon = if (meta.query.isBlank()) Icons.Rounded.ChatBubbleOutline else Icons.Rounded.Search,
                actionText = if (meta.query.isBlank()) "Начать общение" else null,
                onAction = if (meta.query.isBlank()) onNewChat else null,
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 96.dp),
            ) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                    ) {
                        Column {
                            chats.forEachIndexed { index, chat ->
                                ChatRow(
                                    chat = chat,
                                    currentUid = currentUid,
                                    compact = compact,
                                    showGroupBadges = showGroupBadges,
                                    onClick = { onOpenChat(chat.id) },
                                    onPin = { viewModel.togglePin(chat) },
                                    onMute = { viewModel.toggleMute(chat) },
                                    onArchive = { viewModel.toggleArchive(chat) },
                                )
                                if (index != chats.lastIndex) {
                                    HorizontalDivider(
                                        Modifier.padding(start = if (compact) 70.dp else 78.dp),
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.32f),
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterSelector(selected: ChatFilter, onClick: (ChatFilter) -> Unit) {
    val values = listOf(
        ChatFilter.ALL to "Все",
        ChatFilter.DIRECT to "Личные",
        ChatFilter.GROUPS to "Группы",
        ChatFilter.ARCHIVED to "Архив",
    )
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
            .padding(2.dp),
    ) {
        values.forEach { (value, label) ->
            val active = selected == value
            Box(
                Modifier
                    .weight(1f)
                    .background(if (active) MaterialTheme.colorScheme.surface else Color.Transparent, RoundedCornerShape(8.dp))
                    .clickable { onClick(value) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun ChatRow(
    chat: ChatSummary,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    onClick: () -> Unit,
    onPin: () -> Unit,
    onMute: () -> Unit,
    onArchive: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val title = chat.titleFor(currentUid)

    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = if (compact) 9.dp else 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NexaAvatar(title, size = if (compact) 43.dp else 50.dp)
        Spacer(Modifier.size(11.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    title,
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    TimeFormat.message(chat.updatedAt),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showGroupBadges && chat.type == ChatType.GROUP) {
                    Icon(Icons.Rounded.Group, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.size(4.dp))
                }
                Text(
                    chat.lastMessage.ifBlank { "Начало переписки" },
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (chat.muted) {
                    Icon(Icons.Rounded.NotificationsOff, null, Modifier.size(15.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (chat.unreadCount > 0) {
                    Spacer(Modifier.size(6.dp))
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                        Text(
                            chat.unreadCount.coerceAtMost(99).toString(),
                            Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Rounded.MoreHoriz, "Меню", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(if (chat.pinned) "Открепить" else "Закрепить") },
                    leadingIcon = { Icon(Icons.Rounded.PushPin, null) },
                    onClick = { menu = false; onPin() },
                )
                DropdownMenuItem(
                    text = { Text(if (chat.muted) "Включить уведомления" else "Без звука") },
                    leadingIcon = { Icon(Icons.Rounded.NotificationsOff, null) },
                    onClick = { menu = false; onMute() },
                )
                DropdownMenuItem(
                    text = { Text(if (chat.archived) "Вернуть из архива" else "В архив") },
                    leadingIcon = { Icon(if (chat.archived) Icons.Rounded.Unarchive else Icons.Rounded.Archive, null) },
                    onClick = { menu = false; onArchive() },
                )
            }
        }
    }
}
