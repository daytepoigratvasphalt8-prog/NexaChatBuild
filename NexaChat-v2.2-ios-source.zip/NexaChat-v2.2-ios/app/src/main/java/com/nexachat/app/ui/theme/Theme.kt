package com.nexachat.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.ThemeMode

private val DarkColors = darkColorScheme(
    primary = IosBlueDark,
    onPrimary = Color.White,
    secondary = NexaCyan,
    tertiary = NexaPink,
    background = DarkBackground,
    onBackground = DarkText,
    surface = DarkSurface,
    onSurface = DarkText,
    surfaceVariant = DarkSurfaceHigh,
    onSurfaceVariant = DarkMuted,
    outline = DarkOutline,
    outlineVariant = DarkOutline,
    error = NexaRed,
    errorContainer = Color(0xFF3A1515),
    onErrorContainer = Color(0xFFFFDAD6),
)

private val LightColors = lightColorScheme(
    primary = IosBlue,
    onPrimary = Color.White,
    secondary = Color(0xFF0086A3),
    tertiary = Color(0xFFAF2D7A),
    background = LightBackground,
    onBackground = LightText,
    surface = LightSurface,
    onSurface = LightText,
    surfaceVariant = LightSurfaceHigh,
    onSurfaceVariant = LightMuted,
    outline = LightOutline,
    outlineVariant = LightOutline,
    error = NexaRed,
    errorContainer = Color(0xFFFFE5E5),
    onErrorContainer = Color(0xFF7A1010),
)

@Composable
fun NexaChatTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val context = LocalContext.current
    val baseColors = when {
        settings.dynamicColors && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        dark -> DarkColors
        else -> LightColors
    }
    val colors = if (settings.highContrast) {
        baseColors.copy(
            outline = baseColors.onSurface.copy(alpha = 0.82f),
            outlineVariant = baseColors.onSurface.copy(alpha = 0.55f),
            onSurfaceVariant = baseColors.onSurface.copy(alpha = 0.90f),
        )
    } else baseColors

    val scale = if (settings.largeText) 1.12f else 1f
    fun type(size: Float, weight: FontWeight) = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = weight,
        fontSize = (size * scale).sp,
    )
    val typography = Typography(
        displaySmall = type(34f, FontWeight.Bold),
        headlineLarge = type(30f, FontWeight.Bold),
        headlineMedium = type(24f, FontWeight.Bold),
        titleLarge = type(20f, FontWeight.SemiBold),
        titleMedium = type(17f, FontWeight.SemiBold),
        bodyLarge = type(17f, FontWeight.Normal),
        bodyMedium = type(15f, FontWeight.Normal),
        labelLarge = type(15f, FontWeight.SemiBold),
        labelMedium = type(12f, FontWeight.Medium),
    )

    MaterialTheme(colorScheme = colors, typography = typography, content = content)
}
