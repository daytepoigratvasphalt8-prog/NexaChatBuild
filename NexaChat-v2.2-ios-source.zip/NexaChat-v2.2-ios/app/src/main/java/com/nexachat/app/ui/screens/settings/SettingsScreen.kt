package com.nexachat.app.ui.screens.settings

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.DataSaverOn
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.MarkChatRead
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.BuildConfig
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var signOutDialog by remember { mutableStateOf(false) }
    var clearDialog by remember { mutableStateOf(false) }
    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> viewModel.setNotifications(granted) }

    Scaffold(topBar = { NexaTopBar("Настройки") }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(bottom = 34.dp),
        ) {
            Text(
                "Настройте NexaChat под себя",
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 4.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            SectionTitle("ОФОРМЛЕНИЕ")
            SettingsGroup {
                ThemeSelector(settings.themeMode, viewModel::setTheme)
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.ColorLens,
                    "Цвета системы",
                    "Использовать палитру Android вместо фирменного iOS-стиля",
                    settings.dynamicColors,
                    viewModel::setDynamicColors,
                    Color(0xFFAF52DE),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.Smartphone,
                    "Компактный список",
                    "Уменьшить высоту строк чатов",
                    settings.compactChats,
                    viewModel::setCompactChats,
                    Color(0xFF5AC8FA),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.Groups,
                    "Подписи групп",
                    "Показывать тип и число участников",
                    settings.groupBadges,
                    viewModel::setGroupBadges,
                    Color(0xFF5856D6),
                )
            }

            SectionTitle("СООБЩЕНИЯ")
            SettingsGroup {
                SettingSwitch(
                    Icons.Rounded.Schedule,
                    "Время сообщений",
                    "Показывать время внутри пузырей",
                    settings.showMessageTime,
                    viewModel::setShowMessageTime,
                    Color(0xFF007AFF),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.TouchApp,
                    "Вибрация при отправке",
                    "Короткий тактильный отклик",
                    settings.hapticSend,
                    viewModel::setHaptic,
                    Color(0xFFFF9500),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.ChatBubbleOutline,
                    "Статус «печатает…»",
                    "Отправлять и показывать индикатор набора",
                    settings.typingIndicators,
                    viewModel::setTypingIndicators,
                    Color(0xFF30B0C7),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.DeleteOutline,
                    "Подтверждать удаление",
                    "Спрашивать перед удалением сообщения",
                    settings.confirmBeforeDelete,
                    viewModel::setConfirmBeforeDelete,
                    Color(0xFFFF3B30),
                )
            }

            SectionTitle("КОНФИДЕНЦИАЛЬНОСТЬ")
            SettingsGroup {
                SettingSwitch(
                    Icons.Rounded.Public,
                    "Статус «В сети»",
                    "Разрешить другим видеть присутствие",
                    settings.showOnline,
                    viewModel::setShowOnline,
                    Color(0xFF34C759),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.MarkChatRead,
                    "Отчёты о прочтении",
                    "Показывать двойную галочку",
                    settings.readReceipts,
                    viewModel::setReadReceipts,
                    Color(0xFF007AFF),
                )
            }

            SectionTitle("УВЕДОМЛЕНИЯ")
            SettingsGroup {
                SettingSwitch(
                    Icons.Rounded.Notifications,
                    "Новые сообщения",
                    "Разрешить системные уведомления",
                    settings.notificationsEnabled,
                    { enabled ->
                        if (enabled && Build.VERSION.SDK_INT >= 33) {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else viewModel.setNotifications(enabled)
                    },
                    Color(0xFFFF3B30),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.Visibility,
                    "Предпросмотр текста",
                    "Показывать содержание в уведомлении",
                    settings.notificationPreview,
                    viewModel::setNotificationPreview,
                    Color(0xFF007AFF),
                    enabled = settings.notificationsEnabled,
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.NotificationsActive,
                    "Вибрация уведомлений",
                    "Использовать вибрацию для новых сообщений",
                    settings.notificationVibration,
                    viewModel::setNotificationVibration,
                    Color(0xFFFF9500),
                    enabled = settings.notificationsEnabled,
                )
            }

            SectionTitle("ДАННЫЕ И ПАМЯТЬ")
            SettingsGroup {
                SettingSwitch(
                    Icons.Rounded.Sync,
                    "Фоновая синхронизация",
                    "Проверять новые сообщения вне приложения",
                    settings.backgroundSync,
                    viewModel::setBackgroundSync,
                    Color(0xFF34C759),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.DataSaverOn,
                    "Экономия трафика",
                    "Загружать меньше истории и фоновых данных",
                    settings.dataSaver,
                    viewModel::setDataSaver,
                    Color(0xFF30B0C7),
                )
                GroupDivider()
                ActionRow(
                    Icons.Rounded.CleaningServices,
                    "Очистить локальный кэш",
                    "Переписки останутся на сервере",
                    Color(0xFF8E8E93),
                ) { clearDialog = true }
            }

            SectionTitle("ДОСТУПНОСТЬ")
            SettingsGroup {
                SettingSwitch(
                    Icons.Rounded.TextFields,
                    "Крупный текст",
                    "Увеличить шрифт на основных экранах",
                    settings.largeText,
                    viewModel::setLargeText,
                    Color(0xFF007AFF),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.Contrast,
                    "Повышенный контраст",
                    "Сделать вторичный текст и границы заметнее",
                    settings.highContrast,
                    viewModel::setHighContrast,
                    Color(0xFF5856D6),
                )
                GroupDivider()
                SettingSwitch(
                    Icons.Rounded.AutoAwesome,
                    "Меньше анимации",
                    "Сократить плавные переходы и прокрутку",
                    settings.reduceMotion,
                    viewModel::setReduceMotion,
                    Color(0xFFAF52DE),
                )
            }

            SectionTitle("АККАУНТ")
            SettingsGroup {
                ActionRow(
                    Icons.Rounded.Logout,
                    "Выйти из аккаунта",
                    "Сессия и локальные данные будут удалены",
                    Color(0xFFFF3B30),
                    destructive = true,
                ) { signOutDialog = true }
            }

            Text(
                "NexaChat ${BuildConfig.VERSION_NAME} • ${BuildConfig.FIREBASE_PROJECT_ID}",
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (signOutDialog) {
        AlertDialog(
            onDismissRequest = { signOutDialog = false },
            title = { Text("Выйти из аккаунта?") },
            text = { Text("Сессия и локальный кэш будут удалены с устройства.") },
            confirmButton = {
                TextButton(onClick = { signOutDialog = false; viewModel.signOut() }) {
                    Text("Выйти", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { signOutDialog = false }) { Text("Отмена") } },
        )
    }

    if (clearDialog) {
        AlertDialog(
            onDismissRequest = { clearDialog = false },
            title = { Text("Очистить кэш?") },
            text = { Text("Сообщения снова загрузятся с сервера при открытии чатов.") },
            confirmButton = {
                TextButton(onClick = { clearDialog = false; viewModel.clearCache() }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { clearDialog = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        Modifier.padding(start = 22.dp, top = 24.dp, bottom = 8.dp),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = FontWeight.SemiBold,
    )
}

@Composable
private fun SettingsGroup(content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 0.dp,
    ) {
        Column { content() }
    }
}

@Composable
private fun GroupDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 60.dp),
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
    )
}

@Composable
private fun ThemeSelector(selected: ThemeMode, onSelect: (ThemeMode) -> Unit) {
    Column(Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(Icons.Rounded.DarkMode, Color(0xFF5856D6))
            Spacer(Modifier.size(12.dp))
            Text("Тема", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                .padding(2.dp),
        ) {
            ThemeOption("Система", Icons.Rounded.Smartphone, ThemeMode.SYSTEM, selected, onSelect, Modifier.weight(1f))
            ThemeOption("Светлая", Icons.Rounded.LightMode, ThemeMode.LIGHT, selected, onSelect, Modifier.weight(1f))
            ThemeOption("Тёмная", Icons.Rounded.DarkMode, ThemeMode.DARK, selected, onSelect, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ThemeOption(
    label: String,
    icon: ImageVector,
    value: ThemeMode,
    selected: ThemeMode,
    onSelect: (ThemeMode) -> Unit,
    modifier: Modifier,
) {
    val active = selected == value
    Row(
        modifier
            .background(if (active) MaterialTheme.colorScheme.surface else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable { onSelect(value) }
            .padding(horizontal = 6.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(16.dp), tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.size(5.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium)
    }
}

@Composable
private fun SettingSwitch(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit,
    iconColor: Color,
    enabled: Boolean = true,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onChecked(!checked) }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTile(icon, iconColor)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else 0.45f),
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.45f),
            )
        }
        Switch(checked = checked, onCheckedChange = onChecked, enabled = enabled)
    }
}

@Composable
private fun ActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconColor: Color,
    destructive: Boolean = false,
    onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTile(icon, iconColor)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                fontWeight = FontWeight.Medium,
                color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            )
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun IconTile(icon: ImageVector, color: Color) {
    Box(
        Modifier.size(30.dp).background(color, RoundedCornerShape(7.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, Modifier.size(19.dp), tint = Color.White)
    }
}
