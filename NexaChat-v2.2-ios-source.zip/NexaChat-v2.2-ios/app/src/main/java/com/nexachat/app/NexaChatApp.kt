package com.nexachat.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.nexachat.app.core.AppContainer
import com.nexachat.app.core.work.SyncWorker
import java.util.concurrent.TimeUnit

class NexaChatApp : Application() {
    val container: AppContainer by lazy(LazyThreadSafetyMode.SYNCHRONIZED) { AppContainer(this) }

    override fun onCreate() {
        super.onCreate()
        container // initialize secure session before workers
        createNotificationChannels()
        scheduleSync()
    }

    private fun createNotificationChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_MESSAGES,
                "Сообщения",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "Новые личные и групповые сообщения"
                enableVibration(true)
            },
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_MESSAGES_SILENT,
                "Сообщения без вибрации",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Новые сообщения без вибрации"
                enableVibration(false)
                setSound(null, null)
            },
        )
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_SERVICE,
                "Служебные уведомления",
                NotificationManager.IMPORTANCE_LOW,
            ).apply { description = "Синхронизация и состояние аккаунта" },
        )
    }

    private fun scheduleSync() {
        val request = PeriodicWorkRequestBuilder<SyncWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "nexachat_periodic_sync",
            ExistingPeriodicWorkPolicy.UPDATE,
            request,
        )
    }

    companion object {
        const val CHANNEL_MESSAGES = "messages"
        const val CHANNEL_MESSAGES_SILENT = "messages_silent"
        const val CHANNEL_SERVICE = "service"
    }
}
