package com.nexachat.app.ui.screens.chat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Reply
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.model.DeliveryState
import com.nexachat.app.core.model.Message
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.MessageBubble
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.ChatViewModel

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    chat: ChatSummary?,
    hapticEnabled: Boolean,
    readReceiptsEnabled: Boolean,
    showGroupBadges: Boolean,
    showMessageTime: Boolean,
    reduceMotion: Boolean,
    confirmBeforeDelete: Boolean,
    typingIndicatorsEnabled: Boolean,
    onBack: () -> Unit,
) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val typing by viewModel.typing.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val haptics = LocalHapticFeedback.current
    var editing by remember { mutableStateOf<Message?>(null) }
    var editText by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Message?>(null) }
    val title = chat?.titleFor(viewModel.currentUid) ?: "Переписка"

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            if (reduceMotion) listState.scrollToItem(messages.lastIndex)
            else listState.animateScrollToItem(messages.lastIndex)
            if (readReceiptsEnabled) viewModel.markRead()
        }
    }

    Scaffold(
        topBar = {
            NexaTopBar(
                title = title,
                subtitle = when {
                    typingIndicatorsEnabled && typing.isNotEmpty() -> {
                        val names = typing.take(2).map { state ->
                            chat?.memberNames?.get(state.uid).orEmpty().ifBlank { state.username.ifBlank { "Кто-то" } }
                        }
                        when {
                            typing.size == 1 -> "${names.first()} печатает…"
                            typing.size == 2 -> "${names.joinToString(" и ")} печатают…"
                            else -> "Несколько участников печатают…"
                        }
                    }
                    chat == null -> "Синхронизация…"
                    chat.type == ChatType.GROUP && showGroupBadges -> "${chat.memberIds.size} участников"
                    chat.type == ChatType.GROUP -> "Групповой чат"
                    else -> "Личный чат"
                },
                onBack = onBack,
            )
        },
        bottomBar = {
            MessageComposer(
                value = ui.input,
                reply = ui.replyTo,
                sending = ui.sending,
                onValueChange = viewModel::setInput,
                onCancelReply = { viewModel.setReply(null) },
                onSend = {
                    if (hapticEnabled) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    viewModel.send()
                },
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            ErrorBanner(ui.error, viewModel::clearError)
            when {
                ui.loading && messages.isEmpty() -> {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        CircularProgressIndicator()
                        Spacer(Modifier.size(12.dp))
                        Text("Загружаем сообщения…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                messages.isEmpty() -> EmptyState(
                    title = "Начните разговор",
                    message = "Отправьте первое сообщение. Оно сразу появится на экране и синхронизируется при подключении к сети.",
                    modifier = Modifier.fillMaxSize(),
                )
                else -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp),
                ) {
                    items(messages, key = { it.id }) { raw ->
                        val mine = raw.senderId == viewModel.currentUid
                        val message = if (mine && raw.readBy.any { it != viewModel.currentUid }) raw.copy(state = DeliveryState.READ) else raw
                        MessageBubble(
                            message = message,
                            mine = mine,
                            showSender = chat?.type == ChatType.GROUP,
                            showTime = showMessageTime,
                            onLongClick = { viewModel.select(message) },
                            onRetry = { viewModel.retry(message) },
                        )
                    }
                }
            }
        }
    }

    ui.selected?.let { message ->
        MessageActionsDialog(
            message = message,
            mine = message.senderId == viewModel.currentUid,
            onDismiss = { viewModel.select(null) },
            onReply = { viewModel.setReply(message) },
            onEdit = {
                editText = message.text
                editing = message
                viewModel.select(null)
            },
            onDelete = {
                if (confirmBeforeDelete) deleteTarget = message
                else viewModel.delete(message, true)
                viewModel.select(null)
            },
            onReact = { emoji -> viewModel.react(message, emoji); viewModel.select(null) },
        )
    }

    editing?.let { message ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Редактировать сообщение") },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it.take(8_000) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    supportingText = { Text("${editText.length}/8000") },
                )
            },
            confirmButton = {
                Button(onClick = { viewModel.edit(message, editText); editing = null }, enabled = editText.isNotBlank()) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Отмена") } },
        )
    }

    deleteTarget?.let { message ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить сообщение?") },
            text = { Text("Можно удалить его только у себя или у всех участников.") },
            confirmButton = {
                TextButton(onClick = { viewModel.delete(message, true); deleteTarget = null }) { Text("У всех") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { viewModel.delete(message, false); deleteTarget = null }) { Text("У меня") }
                    TextButton(onClick = { deleteTarget = null }) { Text("Отмена") }
                }
            },
        )
    }
}

@Composable
private fun MessageComposer(
    value: String,
    reply: Message?,
    sending: Boolean,
    onValueChange: (String) -> Unit,
    onCancelReply: () -> Unit,
    onSend: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().imePadding()) {
            if (reply != null) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Reply, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.size(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Ответ ${reply.senderName.ifBlank { reply.senderUsername }}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(reply.text.ifBlank { "Сообщение" }, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onCancelReply) { Icon(Icons.Rounded.Close, "Отменить ответ") }
                }
                HorizontalDivider()
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Сообщение") },
                    minLines = 1,
                    maxLines = 5,
                    shape = RoundedCornerShape(22.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                )
                Spacer(Modifier.size(8.dp))
                IconButton(onClick = onSend, enabled = value.isNotBlank() && !sending) {
                    if (sending) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Rounded.Send, "Отправить", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun MessageActionsDialog(
    message: Message,
    mine: Boolean,
    onDismiss: () -> Unit,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onReact: (String) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Действия") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    items(listOf("👍", "❤️", "😂", "🔥", "😮", "😢")) { emoji ->
                        TextButton(onClick = { onReact(emoji) }) {
                            Text(emoji, style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
                TextButton(onClick = onReply, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Reply, null); Spacer(Modifier.size(8.dp)); Text("Ответить")
                }
                if (mine && !message.isDeleted) {
                    TextButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Edit, null); Spacer(Modifier.size(8.dp)); Text("Редактировать")
                    }
                }
                TextButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error); Spacer(Modifier.size(8.dp)); Text("Удалить", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } },
    )
}
