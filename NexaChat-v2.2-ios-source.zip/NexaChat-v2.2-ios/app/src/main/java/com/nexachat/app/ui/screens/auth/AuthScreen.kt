package com.nexachat.app.ui.screens.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.NexaLogo
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.viewmodel.AuthViewModel

@Composable
fun AuthScreen(viewModel: AuthViewModel) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    var passwordVisible by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(18.dp))
        NexaLogo()
        Spacer(Modifier.height(18.dp))
        Text(
            if (state.register) "Создайте аккаунт" else "С возвращением",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (state.register) "Почта, пароль — и можно начинать общение" else "Войдите в NexaChat по электронной почте",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                        .padding(2.dp),
                ) {
                    ModeTab("Вход", !state.register, Modifier.weight(1f)) { viewModel.setRegister(false) }
                    ModeTab("Регистрация", state.register, Modifier.weight(1f)) { viewModel.setRegister(true) }
                }

                OutlinedTextField(
                    value = state.email,
                    onValueChange = viewModel::setEmail,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Электронная почта") },
                    leadingIcon = { Icon(Icons.Rounded.AlternateEmail, null) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                    shape = RoundedCornerShape(13.dp),
                )

                OutlinedTextField(
                    value = state.password,
                    onValueChange = viewModel::setPassword,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Пароль") },
                    supportingText = if (state.register) ({ Text("Минимум 6 символов") }) else null,
                    leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                if (passwordVisible) "Скрыть пароль" else "Показать пароль",
                            )
                        }
                    },
                    singleLine = true,
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = if (state.register) ImeAction.Next else ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                    shape = RoundedCornerShape(13.dp),
                )

                AnimatedVisibility(state.register) {
                    OutlinedTextField(
                        value = state.confirmPassword,
                        onValueChange = viewModel::setConfirmPassword,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Повторите пароль") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                        shape = RoundedCornerShape(13.dp),
                    )
                }

                ErrorBanner(state.error, viewModel::clearError)

                if (!state.notice.isNullOrBlank()) {
                    Surface(
                        color = Color(0xFF34C759).copy(alpha = 0.14f),
                        shape = RoundedCornerShape(12.dp),
                    ) {
                        Text(
                            state.notice.orEmpty(),
                            Modifier.fillMaxWidth().padding(12.dp),
                            color = Color(0xFF34C759),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }

                NexaPrimaryButton(
                    text = if (state.register) "Создать аккаунт" else "Войти",
                    onClick = viewModel::submit,
                    loading = state.loading,
                )

                if (!state.register) {
                    Text(
                        "Забыли пароль?",
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .clickable(onClick = viewModel::resetPassword)
                            .padding(8.dp),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Продолжая, вы соглашаетесь с правилами сервиса и политикой конфиденциальности.",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun ProfileSetupScreen(viewModel: AuthViewModel, email: String) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        NexaLogo(compact = true)
        Spacer(Modifier.height(8.dp))
        Text(
            "Завершите профиль",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold,
        )
        Text("Username нужен для поиска, а имя будет видно в чатах.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface) {
            Text(email, Modifier.fillMaxWidth().padding(13.dp), style = MaterialTheme.typography.bodyMedium)
        }

        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = state.username,
                    onValueChange = viewModel::setUsername,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Username") },
                    prefix = { Text("@") },
                    leadingIcon = { Icon(Icons.Rounded.Badge, null) },
                    supportingText = { Text("5–32 символа: A–Z, 0–9 и _") },
                    singleLine = true,
                    shape = RoundedCornerShape(13.dp),
                )
                OutlinedTextField(
                    value = state.firstName,
                    onValueChange = viewModel::setFirstName,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Имя") },
                    leadingIcon = { Icon(Icons.Rounded.Person, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(13.dp),
                )
                OutlinedTextField(
                    value = state.lastName,
                    onValueChange = viewModel::setLastName,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Фамилия") },
                    leadingIcon = { Icon(Icons.Rounded.Person, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(13.dp),
                )
                OutlinedTextField(
                    value = state.bio,
                    onValueChange = viewModel::setBio,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("О себе") },
                    minLines = 3,
                    supportingText = { Text("${state.bio.length}/160") },
                    shape = RoundedCornerShape(13.dp),
                )
            }
        }

        ErrorBanner(state.error, viewModel::clearError)
        NexaPrimaryButton("Сохранить и продолжить", viewModel::completeProfile, loading = state.loading)
    }
}

@Composable
private fun ModeTab(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .background(if (selected) MaterialTheme.colorScheme.surface else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
