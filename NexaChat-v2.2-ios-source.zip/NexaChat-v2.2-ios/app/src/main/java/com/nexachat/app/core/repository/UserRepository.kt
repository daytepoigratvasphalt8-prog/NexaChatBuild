package com.nexachat.app.core.repository

import com.nexachat.app.core.model.SearchResult
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.network.FirebaseMapper
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.network.NetworkException
import com.nexachat.app.core.util.keysList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONTokener
import java.util.Locale

class UserRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
) {
    suspend fun get(uid: String): UserProfile? = withAuthRetry { token ->
        readProfileCompatible(uid, token)
    }

    /**
     * Updates all editable profile fields and keeps the username index consistent.
     * The new username is claimed before the profile is changed and the old index is
     * released only after both the private and public profile writes have succeeded.
     */
    suspend fun update(profile: UserProfile, requestedUsername: String = profile.username): UserProfile =
        withAuthRetry { token ->
            val ownUid = sessions.current().uid
            require(profile.uid == ownUid) { "Можно изменять только свой профиль" }

            val username = requestedUsername.trim().removePrefix("@")
            val normalized = username.lowercase(Locale.ROOT)
            val current = database.getObject("users/$ownUid", token)
                .takeIf { it.length() > 0 }
                ?.let { FirebaseMapper.profile(ownUid, it) }
                ?: profile
            val oldNormalized = current.usernameLower.ifBlank { current.username.lowercase(Locale.ROOT) }
            val usernameChanged = normalized != oldNormalized

            if (usernameChanged) {
                val claimed = database.compareAndSet("usernames/$normalized", token, transform = { value ->
                    when {
                        value == "null" -> JSONObject.quote(ownUid)
                        decodeJsonString(value) == ownUid -> JSONObject.quote(ownUid)
                        else -> null
                    }
                })
                if (!claimed) throw IllegalStateException("Этот username уже занят")
            }

            val updated = profile.copy(
                username = username,
                usernameLower = normalized,
                updatedAt = System.currentTimeMillis(),
            )

            try {
                database.patch("users/$ownUid", token, FirebaseMapper.profileJson(updated))
                // Older installations may not have publicProfiles yet. Profile editing must
                // still work; search will use compatibility fallbacks until migration is done.
                runCatching {
                    database.patch("publicProfiles/$ownUid", token, FirebaseMapper.publicProfileJson(updated))
                }
            } catch (error: Throwable) {
                if (usernameChanged) releaseUsername(normalized, ownUid, token)
                throw error
            }

            if (usernameChanged && oldNormalized.isNotBlank()) {
                runCatching { releaseUsername(oldNormalized, ownUid, token) }
            }
            updated
        }

    suspend fun claimUsername(uid: String, username: String): Boolean {
        require(uid == sessions.current().uid) { "Можно изменять только свой юзернейм" }
        val normalized = username.lowercase(Locale.ROOT)
        return withAuthRetry { token ->
            val claimed = database.compareAndSet("usernames/$normalized", token, transform = { current ->
                when {
                    current == "null" -> JSONObject.quote(uid)
                    decodeJsonString(current) == uid -> JSONObject.quote(uid)
                    else -> null
                }
            })
            if (claimed) {
                val now = System.currentTimeMillis()
                val patch = JSONObject()
                    .put("username", username)
                    .put("usernameLower", normalized)
                    .put("updatedAt", now)
                database.patch("users/$uid", token, patch)
                runCatching { database.patch("publicProfiles/$uid", token, patch) }
            }
            claimed
        }
    }

    /**
     * Searches both the hardened v2 public profile index and the original v1 users tree.
     * This deliberately avoids surfacing Firebase HTTP 400 errors when the production
     * database has not received the new `.indexOn` rules yet.
     */
    suspend fun search(query: String, limit: Int = 30): List<SearchResult> = withContext(Dispatchers.IO) {
        val normalized = query.trim().removePrefix("@").lowercase(Locale.ROOT)
        if (normalized.length < 2) return@withContext emptyList()

        withAuthRetry { token ->
            val profiles = linkedMapOf<String, UserProfile>()

            suspend fun addUid(uid: String?) {
                if (uid.isNullOrBlank() || profiles.containsKey(uid)) return
                readProfileCompatible(uid, token)?.let { profiles[it.uid] = it }
            }

            // Exact lookup is cheap and works even without query indexes.
            compatibilityCall {
                val raw = database.get("usernames/$normalized", token)
                addUid(decodeJsonString(raw))
            }

            // Prefer server-side prefix search when the corresponding indexes are deployed.
            val sources = listOf("publicProfiles", "users")
            val fields = listOf("usernameLower", "displayNameLower")
            for (source in sources) {
                for (field in fields) {
                    if (profiles.size >= limit) break
                    compatibilityCall { queryProfiles(source, token, field, normalized, limit) }
                        .orEmpty()
                        .forEach { profiles.putIfAbsent(it.profile.uid, it.profile) }
                }
            }

            // Compatibility fallback for the original database/rules. A small legacy user
            // base can be filtered locally and, unlike an indexed query, this never returns
            // "Index not defined". Permission failures are intentionally ignored.
            if (profiles.size < limit) {
                for (source in sources) {
                    compatibilityCall { database.getObject(source, token) }
                        ?.let { all ->
                            all.keysList().forEach { uid ->
                                val json = all.optJSONObject(uid) ?: return@forEach
                                val candidate = FirebaseMapper.profile(uid, json)
                                if (candidate.matches(normalized)) {
                                    profiles.putIfAbsent(uid, candidate)
                                }
                            }
                        }
                    if (profiles.size >= limit) break
                }
            }

            profiles.values
                .filter { it.uid.isNotBlank() && it.username.isNotBlank() }
                .sortedWith(
                    compareBy<UserProfile> {
                        when {
                            it.usernameLower == normalized -> 0
                            it.usernameLower.startsWith(normalized) -> 1
                            it.displayName.lowercase(Locale.ROOT).startsWith(normalized) -> 2
                            else -> 3
                        }
                    }.thenBy { it.displayName.lowercase(Locale.ROOT) },
                )
                .take(limit)
                .map(::SearchResult)
        }
    }

    private suspend fun queryProfiles(
        source: String,
        token: String,
        field: String,
        normalized: String,
        limit: Int,
    ): List<SearchResult> {
        val end = normalized + "\uf8ff"
        val result = database.getObject(
            source,
            token,
            mapOf(
                "orderBy" to "\"$field\"",
                "startAt" to "\"$normalized\"",
                "endAt" to "\"$end\"",
                "limitToFirst" to limit.toString(),
            ),
        )
        return result.keysList().mapNotNull { uid ->
            result.optJSONObject(uid)?.let { SearchResult(FirebaseMapper.profile(uid, it)) }
        }
    }

    private suspend fun readProfileCompatible(uid: String, token: String): UserProfile? {
        val ownUid = sessions.current().uid
        val paths = if (uid == ownUid) listOf("users/$uid", "publicProfiles/$uid")
        else listOf("publicProfiles/$uid", "users/$uid")
        for (path in paths) {
            val profile = compatibilityCall {
                database.getObject(path, token)
                    .takeIf { it.length() > 0 }
                    ?.let { FirebaseMapper.profile(uid, it) }
            }
            if (profile != null) return profile
        }
        return null
    }

    private suspend fun releaseUsername(normalized: String, uid: String, token: String) {
        if (normalized.isBlank()) return
        database.compareAndSet("usernames/$normalized", token, transform = { current ->
            if (decodeJsonString(current) == uid) "null" else null
        })
    }

    suspend fun setPresence(online: Boolean, showOnline: Boolean) {
        val session = sessions.session.value ?: return
        withAuthRetry { token ->
            val now = System.currentTimeMillis()
            val presencePatch = JSONObject()
                .put("online", online && showOnline)
                .put("lastSeen", now)
                .put("updatedAt", now)
            database.patch("users/${session.uid}", token, presencePatch)
            runCatching { database.patch("publicProfiles/${session.uid}", token, presencePatch) }
            database.put(
                "presence/${session.uid}",
                token,
                JSONObject().put("online", online && showOnline).put("lastSeen", now),
            )
        }
    }


    private suspend fun <T> compatibilityCall(block: suspend () -> T): T? = try {
        block()
    } catch (error: NetworkException) {
        if (error.statusCode in setOf(400, 403, 404)) null else throw error
    }

    private fun UserProfile.matches(query: String): Boolean {
        val usernameValue = usernameLower.ifBlank { username.lowercase(Locale.ROOT) }
        val nameValue = displayName.lowercase(Locale.ROOT)
        return usernameValue.startsWith(query) || nameValue.contains(query)
    }

    private fun decodeJsonString(raw: String): String? = runCatching {
        (JSONTokener(raw).nextValue() as? String)?.takeIf(String::isNotBlank)
    }.getOrNull()

    private suspend fun <T> withAuthRetry(block: suspend (String) -> T): T = try {
        block(sessions.token())
    } catch (error: NetworkException) {
        if (error.statusCode == 401) block(sessions.token(forceRefresh = true)) else throw error
    }
}
