package com.nexachat.app.ui.theme

import androidx.compose.ui.graphics.Color

// Original NexaChat brand colors (also used by the restored v1.6 icon).
val NexaPurple = Color(0xFF8868FF)
val NexaPurpleLight = Color(0xFFA78BFA)
val NexaCyan = Color(0xFF5DE5FF)
val NexaPink = Color(0xFFFF5EC2)
val NexaGreen = Color(0xFF34C759)
val NexaRed = Color(0xFFFF3B30)
val NexaAmber = Color(0xFFFF9500)

// iOS-like neutral palette.
val IosBlue = Color(0xFF007AFF)
val IosBlueDark = Color(0xFF0A84FF)

val DarkBackground = Color(0xFF000000)
val DarkSurface = Color(0xFF1C1C1E)
val DarkSurfaceHigh = Color(0xFF2C2C2E)
val DarkOutline = Color(0xFF3A3A3C)
val DarkText = Color(0xFFFFFFFF)
val DarkMuted = Color(0xFF8E8E93)

val LightBackground = Color(0xFFF2F2F7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFE5E5EA)
val LightOutline = Color(0xFFC6C6C8)
val LightText = Color(0xFF000000)
val LightMuted = Color(0xFF8E8E93)
