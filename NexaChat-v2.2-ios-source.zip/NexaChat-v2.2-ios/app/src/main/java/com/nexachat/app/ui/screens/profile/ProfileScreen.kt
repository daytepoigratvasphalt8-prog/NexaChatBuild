package com.nexachat.app.ui.screens.profile

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LockReset
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.LoadingScreen
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.ProfileViewModel

@Composable
fun ProfileScreen(viewModel: ProfileViewModel) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val profile = ui.profile
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    Scaffold(
        topBar = {
            NexaTopBar(
                title = if (ui.editing) "Изменить профиль" else "Профиль",
                actions = {
                    if (profile != null) {
                        if (ui.editing) {
                            TextButton(onClick = viewModel::cancelEdit, enabled = !ui.saving) {
                                Text("Отмена")
                            }
                        } else {
                            IconButton(onClick = viewModel::startEdit) {
                                Icon(Icons.Rounded.Edit, "Изменить профиль")
                            }
                        }
                    }
                },
            )
        },
    ) { padding ->
        if (profile == null) {
            LoadingScreen("Загружаем профиль…")
            return@Scaffold
        }

        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (ui.editing) {
                EditProfileContent(ui = ui, viewModel = viewModel)
            } else {
                NexaAvatar(profile.displayName, size = 104.dp, online = profile.online)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        profile.displayName,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        "@${profile.username}",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (profile.statusText.isNotBlank()) {
                        Text(
                            profile.statusText,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    }
                }

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    ProfileAction(
                        label = "Изменить",
                        icon = Icons.Rounded.Edit,
                        modifier = Modifier.weight(1f),
                        onClick = viewModel::startEdit,
                    )
                    ProfileAction(
                        label = "Ссылка",
                        icon = Icons.Rounded.Link,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            clipboard.setText(AnnotatedString("https://nexachat.app/u/${profile.username}"))
                        },
                    )
                    ProfileAction(
                        label = "Поделиться",
                        icon = Icons.Rounded.Share,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val text = "${profile.displayName} в NexaChat: @${profile.username}"
                            val intent = Intent(Intent.ACTION_SEND)
                                .setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, text)
                            context.startActivity(Intent.createChooser(intent, "Поделиться профилем"))
                        },
                    )
                }

                ErrorBanner(ui.error, viewModel::clearError)
                NoticeBanner(ui.notice, viewModel::clearNotice)

                ProfileSection(title = "О себе") {
                    ProfileRow(
                        icon = Icons.Rounded.Info,
                        title = "Информация",
                        value = profile.bio.ifBlank { "Добавьте несколько слов о себе" },
                        onClick = viewModel::startEdit,
                    )
                    ProfileDivider()
                    ProfileRow(
                        icon = Icons.Rounded.Person,
                        title = "Имя",
                        value = profile.displayName,
                        onClick = viewModel::startEdit,
                    )
                }

                ProfileSection(title = "Публичные данные") {
                    ProfileRow(
                        icon = Icons.Rounded.Badge,
                        title = "Имя пользователя",
                        value = "@${profile.username}",
                        onClick = {
                            clipboard.setText(AnnotatedString("@${profile.username}"))
                        },
                        trailingIcon = Icons.Rounded.ContentCopy,
                    )
                    ProfileDivider()
                    ProfileRow(
                        icon = Icons.Rounded.AlternateEmail,
                        title = "Ссылка на профиль",
                        value = "nexachat.app/u/${profile.username}",
                        onClick = {
                            clipboard.setText(AnnotatedString("https://nexachat.app/u/${profile.username}"))
                        },
                        trailingIcon = Icons.Rounded.ContentCopy,
                    )
                }

                ProfileSection(title = "Аккаунт") {
                    ProfileRow(
                        icon = Icons.Rounded.Mail,
                        title = "Электронная почта",
                        value = profile.email,
                        onClick = viewModel::sendVerification,
                        trailingText = "Подтвердить",
                    )
                    ProfileDivider()
                    ProfileRow(
                        icon = Icons.Rounded.LockReset,
                        title = "Изменить пароль",
                        value = "Отправить ссылку на почту",
                        onClick = viewModel::sendPasswordReset,
                    )
                }

                if (ui.actionInProgress) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                }
                Spacer(Modifier.size(6.dp))
            }
        }
    }
}

@Composable
private fun EditProfileContent(
    ui: com.nexachat.app.ui.viewmodel.ProfileUiState,
    viewModel: ProfileViewModel,
) {
    val profile = ui.profile ?: return
    NexaAvatar(profile.displayName, size = 92.dp, online = profile.online)
    Text(
        "Данные профиля",
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onBackground,
        fontWeight = FontWeight.Bold,
    )

    ErrorBanner(ui.error, viewModel::clearError)
    NoticeBanner(ui.notice, viewModel::clearNotice)

    ProfileSection(title = "Основное") {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = ui.firstName,
                onValueChange = viewModel::setFirstName,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Имя") },
                leadingIcon = { Icon(Icons.Rounded.Person, null) },
                singleLine = true,
                shape = RoundedCornerShape(13.dp),
            )
            OutlinedTextField(
                value = ui.lastName,
                onValueChange = viewModel::setLastName,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Фамилия") },
                leadingIcon = { Icon(Icons.Rounded.Person, null) },
                singleLine = true,
                shape = RoundedCornerShape(13.dp),
            )
            OutlinedTextField(
                value = ui.statusText,
                onValueChange = viewModel::setStatus,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Статус") },
                supportingText = { Text("${ui.statusText.length}/70") },
                singleLine = true,
                shape = RoundedCornerShape(13.dp),
            )
            OutlinedTextField(
                value = ui.bio,
                onValueChange = viewModel::setBio,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("О себе") },
                minLines = 3,
                supportingText = { Text("${ui.bio.length}/160") },
                shape = RoundedCornerShape(13.dp),
            )
        }
    }

    ProfileSection(title = "Имя пользователя") {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = ui.username,
                onValueChange = viewModel::setUsername,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Username") },
                prefix = { Text("@") },
                leadingIcon = { Icon(Icons.Rounded.Badge, null) },
                supportingText = { Text("5–32 символа: латиница, цифры и _") },
                singleLine = true,
                shape = RoundedCornerShape(13.dp),
            )
            Text(
                "По имени пользователя другие люди смогут найти вас в NexaChat.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.AlternateEmail, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Электронная почта", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(profile.email, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }

    NexaPrimaryButton(
        text = "Сохранить изменения",
        onClick = viewModel::save,
        loading = ui.saving,
        icon = Icons.Rounded.Save,
        modifier = Modifier.fillMaxWidth(),
    )
    OutlinedButton(
        onClick = viewModel::cancelEdit,
        modifier = Modifier.fillMaxWidth(),
        enabled = !ui.saving,
    ) {
        Text("Отмена")
    }
    Spacer(Modifier.size(6.dp))
}

@Composable
private fun ProfileAction(
    label: String,
    icon: ImageVector,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Column(
            Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)) {
                Icon(icon, null, Modifier.padding(9.dp), tint = MaterialTheme.colorScheme.primary)
            }
            Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
private fun ProfileSection(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            title.uppercase(),
            modifier = Modifier.padding(horizontal = 12.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column { content() }
        }
    }
}

@Composable
private fun ProfileRow(
    icon: ImageVector,
    title: String,
    value: String,
    onClick: (() -> Unit)? = null,
    trailingIcon: ImageVector? = null,
    trailingText: String? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (!trailingText.isNullOrBlank()) {
            Text(trailingText, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
        } else if (trailingIcon != null) {
            Icon(trailingIcon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
private fun ProfileDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 50.dp),
        thickness = 0.5.dp,
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f),
    )
}

@Composable
private fun NoticeBanner(message: String?, onDismiss: () -> Unit) {
    if (message.isNullOrBlank()) return
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onDismiss),
        shape = RoundedCornerShape(13.dp),
        color = Color(0xFF34C759).copy(alpha = 0.16f),
    ) {
        Text(
            message,
            Modifier.padding(13.dp),
            color = Color(0xFF34C759),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
        )
    }
}
