package com.nexachat.app.core.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "nexachat_settings")

class SettingsRepository(private val context: Context) {
    val settings: Flow<AppSettings> = context.settingsDataStore.data.map(::read)

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { preferences ->
            write(preferences, transform(read(preferences)))
        }
    }

    private fun read(preferences: Preferences): AppSettings = AppSettings(
        themeMode = runCatching {
            ThemeMode.valueOf(preferences[THEME] ?: ThemeMode.SYSTEM.name)
        }.getOrDefault(ThemeMode.SYSTEM),
        dynamicColors = preferences[DYNAMIC_COLORS] ?: false,
        compactChats = preferences[COMPACT_CHATS] ?: false,
        largeText = preferences[LARGE_TEXT] ?: false,
        highContrast = preferences[HIGH_CONTRAST] ?: false,
        reduceMotion = preferences[REDUCE_MOTION] ?: false,
        hapticSend = preferences[HAPTIC_SEND] ?: true,
        showOnline = preferences[SHOW_ONLINE] ?: true,
        readReceipts = preferences[READ_RECEIPTS] ?: true,
        typingIndicators = preferences[TYPING_INDICATORS] ?: true,
        dataSaver = preferences[DATA_SAVER] ?: false,
        backgroundSync = preferences[BACKGROUND_SYNC] ?: true,
        notificationsEnabled = preferences[NOTIFICATIONS] ?: true,
        notificationPreview = preferences[NOTIFICATION_PREVIEW] ?: true,
        notificationVibration = preferences[NOTIFICATION_VIBRATION] ?: true,
        groupBadges = preferences[GROUP_BADGES] ?: true,
        showMessageTime = preferences[SHOW_MESSAGE_TIME] ?: true,
        confirmBeforeDelete = preferences[CONFIRM_BEFORE_DELETE] ?: true,
    )

    private fun write(preferences: androidx.datastore.preferences.core.MutablePreferences, value: AppSettings) {
        preferences[THEME] = value.themeMode.name
        preferences[DYNAMIC_COLORS] = value.dynamicColors
        preferences[COMPACT_CHATS] = value.compactChats
        preferences[LARGE_TEXT] = value.largeText
        preferences[HIGH_CONTRAST] = value.highContrast
        preferences[REDUCE_MOTION] = value.reduceMotion
        preferences[HAPTIC_SEND] = value.hapticSend
        preferences[SHOW_ONLINE] = value.showOnline
        preferences[READ_RECEIPTS] = value.readReceipts
        preferences[TYPING_INDICATORS] = value.typingIndicators
        preferences[DATA_SAVER] = value.dataSaver
        preferences[BACKGROUND_SYNC] = value.backgroundSync
        preferences[NOTIFICATIONS] = value.notificationsEnabled
        preferences[NOTIFICATION_PREVIEW] = value.notificationPreview
        preferences[NOTIFICATION_VIBRATION] = value.notificationVibration
        preferences[GROUP_BADGES] = value.groupBadges
        preferences[SHOW_MESSAGE_TIME] = value.showMessageTime
        preferences[CONFIRM_BEFORE_DELETE] = value.confirmBeforeDelete
    }

    private companion object {
        val THEME = stringPreferencesKey("theme")
        val DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        val COMPACT_CHATS = booleanPreferencesKey("compact_chats")
        val LARGE_TEXT = booleanPreferencesKey("large_text")
        val HIGH_CONTRAST = booleanPreferencesKey("high_contrast")
        val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
        val HAPTIC_SEND = booleanPreferencesKey("haptic_send")
        val SHOW_ONLINE = booleanPreferencesKey("show_online")
        val READ_RECEIPTS = booleanPreferencesKey("read_receipts")
        val TYPING_INDICATORS = booleanPreferencesKey("typing_indicators")
        val DATA_SAVER = booleanPreferencesKey("data_saver")
        val BACKGROUND_SYNC = booleanPreferencesKey("background_sync")
        val NOTIFICATIONS = booleanPreferencesKey("notifications")
        val NOTIFICATION_PREVIEW = booleanPreferencesKey("notification_preview")
        val NOTIFICATION_VIBRATION = booleanPreferencesKey("notification_vibration")
        val GROUP_BADGES = booleanPreferencesKey("group_badges")
        val SHOW_MESSAGE_TIME = booleanPreferencesKey("show_message_time")
        val CONFIRM_BEFORE_DELETE = booleanPreferencesKey("confirm_before_delete")
    }
}
