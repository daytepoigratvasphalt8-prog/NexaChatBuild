package com.nexachat.app.core.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Tracks the device's default network rather than every network interface.
 *
 * The previous implementation listened to all INTERNET-capable networks. On dual-SIM,
 * VPN and some OEM devices an inactive/unvalidated interface could emit `false` after
 * the active mobile/Wi-Fi network emitted `true`, which produced a permanent false
 * "offline" banner. The default-network callback avoids that race.
 *
 * We intentionally treat an active network with INTERNET capability as online even
 * before Android marks it VALIDATED. Firebase requests remain the final source of truth.
 */
class NetworkMonitor(context: Context) {
    private val connectivity = context.getSystemService(ConnectivityManager::class.java)

    val online: Flow<Boolean> = callbackFlow {
        fun current(): Boolean {
            val network = connectivity.activeNetwork ?: return false
            val capabilities = connectivity.getNetworkCapabilities(network) ?: return false
            return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)
        }

        fun emitCurrent() {
            trySend(current())
        }

        emitCurrent()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = emitCurrent()
            override fun onLost(network: Network) = emitCurrent()
            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) = emitCurrent()
            override fun onBlockedStatusChanged(network: Network, blocked: Boolean) = emitCurrent()
        }

        val registered = runCatching {
            connectivity.registerDefaultNetworkCallback(callback)
        }.isSuccess

        // If an OEM blocks callbacks, do not show a false offline state forever.
        if (!registered) trySend(true)

        awaitClose {
            if (registered) runCatching { connectivity.unregisterNetworkCallback(callback) }
        }
    }.distinctUntilChanged()
}
