package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.AuthState
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.UserRepository
import com.nexachat.app.core.util.Validation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch


data class ProfileUiState(
    val profile: UserProfile? = null,
    val username: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val bio: String = "",
    val statusText: String = "",
    val editing: Boolean = false,
    val saving: Boolean = false,
    val actionInProgress: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
    val saved: Boolean = false,
)

class ProfileViewModel(
    private val auth: AuthRepository,
    private val users: UserRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(ProfileUiState())
    val ui: StateFlow<ProfileUiState> = _ui.asStateFlow()

    init {
        val profile = (auth.state.value as? AuthState.SignedIn)?.profile
        bind(profile)
        viewModelScope.launch {
            runCatching { auth.refreshProfile() }.onSuccess(::bind)
        }
    }

    fun startEdit() = _ui.update { it.copy(editing = true, saved = false, error = null, notice = null) }
    fun cancelEdit() = bind(_ui.value.profile)
    fun setUsername(value: String) = _ui.update {
        it.copy(
            username = value.removePrefix("@").filter { char -> char.isLetterOrDigit() || char == '_' }.take(32),
            error = null,
            notice = null,
        )
    }
    fun setFirstName(value: String) = _ui.update { it.copy(firstName = value.take(48), error = null, notice = null) }
    fun setLastName(value: String) = _ui.update { it.copy(lastName = value.take(48), error = null, notice = null) }
    fun setBio(value: String) = _ui.update { it.copy(bio = value.take(160), error = null, notice = null) }
    fun setStatus(value: String) = _ui.update { it.copy(statusText = value.take(70), error = null, notice = null) }
    fun clearError() = _ui.update { it.copy(error = null) }
    fun clearNotice() = _ui.update { it.copy(notice = null) }

    fun save() {
        val state = _ui.value
        val profile = state.profile ?: return
        Validation.username(state.username)?.let { error ->
            _ui.update { it.copy(error = error) }
            return
        }
        Validation.displayName(state.firstName, state.lastName)?.let { error ->
            _ui.update { it.copy(error = error) }
            return
        }
        Validation.bio(state.bio)?.let { error ->
            _ui.update { it.copy(error = error) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(saving = true, error = null, notice = null, saved = false) }
            runCatching {
                users.update(
                    profile = profile.copy(
                        firstName = state.firstName.trim(),
                        lastName = state.lastName.trim(),
                        bio = state.bio.trim(),
                        statusText = state.statusText.trim(),
                    ),
                    requestedUsername = state.username,
                )
            }.onSuccess { updated ->
                _ui.update {
                    it.copy(
                        profile = updated,
                        username = updated.username,
                        saving = false,
                        editing = false,
                        saved = true,
                        notice = "Профиль обновлён",
                    )
                }
                auth.refreshProfile()
            }.onFailure { error ->
                _ui.update { it.copy(saving = false, error = error.message ?: "Не удалось сохранить профиль") }
            }
        }
    }

    fun sendPasswordReset() {
        val email = _ui.value.profile?.email.orEmpty()
        if (email.isBlank() || _ui.value.actionInProgress) return
        viewModelScope.launch {
            _ui.update { it.copy(actionInProgress = true, error = null, notice = null) }
            runCatching { auth.resetPassword(email) }
                .onSuccess {
                    _ui.update {
                        it.copy(
                            actionInProgress = false,
                            notice = "Ссылка для смены пароля отправлена на $email",
                        )
                    }
                }
                .onFailure { error ->
                    _ui.update { it.copy(actionInProgress = false, error = error.message ?: "Не удалось отправить письмо") }
                }
        }
    }

    fun sendVerification() {
        if (_ui.value.actionInProgress) return
        viewModelScope.launch {
            _ui.update { it.copy(actionInProgress = true, error = null, notice = null) }
            runCatching { auth.sendVerification() }
                .onSuccess {
                    _ui.update {
                        it.copy(
                            actionInProgress = false,
                            notice = "Письмо для подтверждения адреса отправлено",
                        )
                    }
                }
                .onFailure { error ->
                    _ui.update { it.copy(actionInProgress = false, error = error.message ?: "Не удалось отправить письмо") }
                }
        }
    }

    private fun bind(profile: UserProfile?) {
        _ui.value = ProfileUiState(
            profile = profile,
            username = profile?.username.orEmpty(),
            firstName = profile?.firstName.orEmpty(),
            lastName = profile?.lastName.orEmpty(),
            bio = profile?.bio.orEmpty(),
            statusText = profile?.statusText.orEmpty(),
        )
    }

    class Factory(
        private val auth: AuthRepository,
        private val users: UserRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ProfileViewModel(auth, users) as T
    }
}
