package com.nexachat.app.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nexachat.app.core.model.DeliveryState
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.model.MessageType
import com.nexachat.app.core.util.TimeFormat

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: Message,
    mine: Boolean,
    showSender: Boolean,
    showTime: Boolean,
    onLongClick: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (message.type == MessageType.SYSTEM) {
        Box(modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)) {
                Text(message.text, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 330.dp)
                .combinedClickable(onClick = {}, onLongClick = onLongClick),
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (mine) 18.dp else 5.dp,
                bottomEnd = if (mine) 5.dp else 18.dp,
            ),
            color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
            contentColor = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            tonalElevation = if (mine) 0.dp else 1.dp,
        ) {
            Column(Modifier.padding(horizontal = 13.dp, vertical = 9.dp)) {
                if (showSender && !mine) {
                    Text(
                        message.senderName.ifBlank { message.senderUsername },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                    )
                }
                if (message.replyToId.isNotBlank()) {
                    Surface(
                        color = Color.Black.copy(alpha = if (mine) 0.12f else 0.06f),
                        shape = RoundedCornerShape(9.dp),
                    ) {
                        Column(Modifier.padding(horizontal = 9.dp, vertical = 6.dp)) {
                            Text("Ответ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(message.replyPreview.ifBlank { "Сообщение" }, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    Spacer(Modifier.size(6.dp))
                }
                when {
                    message.isDeleted -> Text("Сообщение удалено", fontStyle = FontStyle.Italic, color = LocalBubbleMuted)
                    message.type == MessageType.IMAGE -> {
                        Text("📷 Фото", fontWeight = FontWeight.SemiBold)
                        if (message.text.isNotBlank()) Text(message.text, Modifier.padding(top = 4.dp))
                    }
                    message.type == MessageType.FILE -> {
                        Text("📎 ${message.attachmentName.ifBlank { "Файл" }}", fontWeight = FontWeight.SemiBold)
                        if (message.text.isNotBlank()) Text(message.text, Modifier.padding(top = 4.dp))
                    }
                    message.type == MessageType.VOICE -> Text("🎙 Голосовое сообщение", fontWeight = FontWeight.SemiBold)
                    else -> Text(message.text, style = MaterialTheme.typography.bodyLarge)
                }
                if (showTime || mine || message.editedAt > 0) Row(
                    Modifier.align(Alignment.End).padding(top = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    if (message.editedAt > 0) Text("изм.", style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
                    if (showTime) Text(TimeFormat.message(message.createdAt), style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
                    if (mine) {
                        when (message.state) {
                            DeliveryState.FAILED -> Icon(Icons.Rounded.Refresh, "Повторить", Modifier.size(15.dp).combinedClickable(onClick = onRetry, onLongClick = onRetry), tint = MaterialTheme.colorScheme.error)
                            DeliveryState.READ -> Icon(Icons.Rounded.DoneAll, "Прочитано", Modifier.size(15.dp), tint = MaterialTheme.colorScheme.secondary)
                            DeliveryState.DELIVERED -> Icon(Icons.Rounded.DoneAll, "Доставлено", Modifier.size(15.dp), tint = LocalBubbleMuted)
                            DeliveryState.QUEUED -> Icon(Icons.Rounded.Schedule, "В очереди", Modifier.size(15.dp), tint = LocalBubbleMuted)
                            DeliveryState.SENDING -> Text("…", style = MaterialTheme.typography.labelMedium, color = LocalBubbleMuted)
                            DeliveryState.SENT -> Icon(Icons.Rounded.Check, "Отправлено", Modifier.size(15.dp), tint = LocalBubbleMuted)
                        }
                    }
                }
                if (message.reactions.isNotEmpty()) {
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        message.reactions.entries.take(5).forEach { (emoji, users) ->
                            Surface(shape = RoundedCornerShape(10.dp), color = Color.Black.copy(alpha = 0.12f)) {
                                Text("$emoji ${users.size}", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

private val LocalBubbleMuted
    @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f)
