package com.nexachat.app.core.push

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.nexachat.app.CallActivity
import com.nexachat.app.MainActivity
import com.nexachat.app.NexaChatApp
import com.nexachat.app.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NexaMessagingService : FirebaseMessagingService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val container get() = (application as NexaChatApp).container

    override fun onNewToken(token: String) {
        scope.launch { runCatching { container.push.registerToken(token) } }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        when (message.data["type"]) {
            "call" -> showCall(message.data)
            "session_revoked" -> handleRevocation(message.data)
            else -> showMessage(message.data)
        }
    }

    @SuppressLint("MissingPermission")
    private fun showMessage(data: Map<String, String>) {
        if (!canPostNotifications()) return
        val chatId = data["chatId"].orEmpty()
        val title = data["title"].orEmpty().ifBlank { "NexaChat" }
        val intent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            this.data = Uri.parse("nexachat://nexachat.app/chat/$chatId")
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pending = PendingIntent.getActivity(
            this,
            chatId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(this, NexaChatApp.CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_nexa)
            .setContentTitle(title)
            .setContentText("Новое защищённое сообщение")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pending)
            .build()
        NotificationManagerCompat.from(this).notify((data["messageId"] ?: chatId).hashCode(), notification)
    }

    @SuppressLint("MissingPermission")
    private fun showCall(data: Map<String, String>) {
        if (!canPostNotifications()) return
        val callId = data["callId"].orEmpty()
        if (callId.isBlank()) return
        val intent = CallActivity.createIntent(
            context = this,
            callId = callId,
            chatId = data["chatId"].orEmpty(),
            peerUid = data["callerId"].orEmpty(),
            video = data["video"]?.toBooleanStrictOrNull() ?: false,
            outgoing = false,
            peerName = data["callerName"].orEmpty(),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pending = PendingIntent.getActivity(
            this,
            callId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val declineIntent = Intent(this, CallActionReceiver::class.java)
            .setAction(CallActionReceiver.ACTION_DECLINE)
            .putExtra(CallActionReceiver.EXTRA_CALL_ID, callId)
        val declinePending = PendingIntent.getBroadcast(
            this,
            callId.hashCode() xor 0x5A5A,
            declineIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(this, NexaChatApp.CHANNEL_CALLS)
            .setSmallIcon(R.drawable.ic_stat_nexa)
            .setContentTitle(data["callerName"].orEmpty().ifBlank { "Входящий звонок" })
            .setContentText(if (data["video"].toBoolean()) "Видеозвонок" else "Аудиозвонок")
            .setAutoCancel(true)
            .setOngoing(true)
            .setTimeoutAfter(90_000)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pending, true)
            .setContentIntent(pending)
            .addAction(R.drawable.ic_stat_nexa, "Отклонить", declinePending)
            .addAction(R.drawable.ic_stat_nexa, "Ответить", pending)
            .build()
        NotificationManagerCompat.from(this).notify(callId.hashCode(), notification)
    }

    private fun canPostNotifications(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun handleRevocation(data: Map<String, String>) {
        val target = data["deviceId"].orEmpty()
        if (target.isNotBlank() && target != container.deviceSessions.currentDeviceId) return
        scope.launch { container.auth.forceLocalSignOut() }
    }
}
