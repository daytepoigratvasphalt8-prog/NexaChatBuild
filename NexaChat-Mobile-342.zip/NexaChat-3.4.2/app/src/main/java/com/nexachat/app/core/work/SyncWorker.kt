package com.nexachat.app.core.work

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nexachat.app.MainActivity
import com.nexachat.app.NexaChatApp
import com.nexachat.app.R
import com.nexachat.app.core.model.AppSettings
import kotlinx.coroutines.flow.first

class SyncWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as NexaChatApp).container
        if (container.sessions.session.value == null) return Result.success()
        val settings = container.settings.settings.first()
        if (!settings.backgroundSync) return Result.success()

        return runCatching {
            val before = container.chats.chats.value.sumOf { it.unreadCount }
            container.chats.retryPendingMessages()
            container.chats.syncChats()
            val after = container.chats.chats.value.sumOf { it.unreadCount }
            if (settings.notificationsEnabled && after > before) {
                notifyNewMessages(after - before, settings)
            }
            Result.success()
        }.getOrElse {
            if (runAttemptCount < 4) Result.retry() else Result.failure()
        }
    }

    @SuppressLint("MissingPermission")
    private fun notifyNewMessages(count: Int, settings: AppSettings) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val openApp = PendingIntent.getActivity(
            applicationContext,
            42,
            Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val channel = if (settings.notificationVibration) {
            NexaChatApp.CHANNEL_MESSAGES
        } else {
            NexaChatApp.CHANNEL_MESSAGES_SILENT
        }
        val text = if (!settings.notificationPreview) {
            "Откройте NexaChat, чтобы посмотреть"
        } else if (count == 1) {
            "Новое сообщение"
        } else {
            "Новых сообщений: $count"
        }
        val notification = Notification.Builder(applicationContext, channel)
            .setSmallIcon(R.drawable.ic_stat_nexa)
            .setContentTitle("NexaChat")
            .setContentText(text)
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .build()
        applicationContext.getSystemService(NotificationManager::class.java).notify(1001, notification)
    }
}
