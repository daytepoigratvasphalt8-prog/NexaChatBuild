# NexaChat 3.2 Clean design

The interface prioritizes conversation content and predictable navigation.

- Neutral system background and solid surfaces.
- No transparency, refraction, wallpaper animation or glass blur imitation.
- Color is reserved for primary actions, unread state and selection.
- The chat list contains no dashboard widgets or duplicate action grids.
- Bottom navigation always displays labels.
- Existing screens keep compatible component APIs, but legacy GlassPanel/LiquidBackground names now render clean solid UI.
