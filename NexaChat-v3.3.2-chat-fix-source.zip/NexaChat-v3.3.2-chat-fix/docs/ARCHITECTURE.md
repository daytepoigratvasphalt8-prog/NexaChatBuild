# Architecture

## Layers

- `core/model`: immutable domain models.
- `core/network`: Firebase Authentication, Realtime Database streaming and Storage REST clients.
- `core/repository`: sessions, users, contacts, chats and offline-safe operations.
- `core/database`: SQLite cache for chats, messages, drafts and hidden-message state.
- `core/media`: attachment cache, upload pipeline, recorder and player.
- `core/settings`: DataStore-backed application preferences.
- `core/work`: WorkManager background synchronization and notifications.
- `ui/viewmodel`: screen state and coroutine orchestration.
- `ui/screens`: Compose screens.
- `ui/components`: shared controls, media and Liquid Glass primitives.

## Message delivery

1. The client creates a deterministic message ID and writes the optimistic message to SQLite.
2. A Firebase `PUT` targets that exact ID.
3. If the response is lost, retry checks the same remote path and verifies the client ID.
4. Retryable failures remain queued locally and are drained when connectivity returns.
5. Chat summary writes are best-effort because accepted message content is authoritative.

## Media

Attachments are selected through Android’s Storage Access Framework, uploaded to the authenticated user’s Firebase Storage directory and referenced from message metadata. Received files are downloaded to an application cache and exposed to external viewers only through FileProvider.

## Liquid Glass

`LiquidBackground` renders animated accent-coloured fields. `GlassPanel` and `GlassPill` combine controlled opacity, gradient layers, fine borders and elevation. Motion and opacity are user-configurable; reduced-motion mode keeps the visual hierarchy while slowing background animation dramatically.
