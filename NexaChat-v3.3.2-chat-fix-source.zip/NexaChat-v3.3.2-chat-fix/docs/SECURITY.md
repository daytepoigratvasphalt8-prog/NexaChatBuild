# Security model

## Implemented controls

- Android Keystore-backed AES-GCM encryption for session tokens.
- No cloud backup of authentication tokens or the local message database.
- HTTPS-only network policy and bounded connection/read timeouts.
- Private `/users` records and public `/publicProfiles` records without email.
- Username claims use Firebase ETags to prevent a check-then-write race.
- Membership checks before reading chats or messages.
- Only a message author or group owner may edit/delete message content.
- Reactions and read receipts can only be written for the authenticated UID.
- Only the account owner can alter mute/archive/pin preferences.
- Server-side atomic increments for unread counters.
- Length/type validation in both the Android client and database rules.
- Release signing secrets are injected only by CI environment variables.

## Threats not solved by this version

NexaChat 3.0 does not claim end-to-end encryption. Firebase and project administrators can access plaintext messages. Adding real E2EE requires audited identity keys, device keys, session establishment, key rotation, multi-device recovery and encrypted attachment handling; a UI-only encryption toggle would be unsafe.

The REST client cannot guarantee an `onDisconnect` presence update, so an abrupt process or network failure can leave a stale online flag until a later lifecycle update. Consumers should treat `lastSeen` as the authoritative fallback.

Periodic local notifications are not instant push notifications. Production push requires Firebase Cloud Messaging token registration and a trusted server/Cloud Function that verifies membership before sending notification metadata.

## Deployment order

1. Back up Realtime Database.
2. Run the public-profile migration.
3. Verify no email exists under `/publicProfiles`.
4. Test rules in Firebase Emulator Suite.
5. Deploy rules.
6. Roll out the app gradually and monitor permission-denied errors.

## Reporting

Do not post service-account files, keystores, refresh tokens, database exports or user messages in public issues. Use a private security channel for vulnerability reports.
