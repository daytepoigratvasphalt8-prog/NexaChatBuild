# Original APK audit

Source artifact: `NexaChat-settings-profile-v1.6.apk`

- SHA-256: `8ea58a251aa3cd4eeca3b62643bd143646d2ef9a714c8289dc90e3cff11cd1c1`
- Package: `com.nexachat.app`
- Version: `1.6.0`
- Minimum Android API: 26
- Approximate archive size: 57 KB
- Structure: one DEX, legacy Java/Android Views, direct Firebase REST access
- Firebase data roots observed: `users`, `usernames`, `chats`, `userChats`, `messages`

The artifact is an early prototype rather than a recoverable source repository. NexaChat 3.0 is therefore a clean-room rewrite based on observed behavior and compatible data fields, not decompiled source copied into a new project.
