# Firebase setup

## Authentication

Enable Email/Password in Firebase Authentication. NexaChat uses the Firebase Identity Toolkit REST API, so the Web API key is required in `NEXA_FIREBASE_API_KEY`.

## Realtime Database

Create a Realtime Database and set `NEXA_DATABASE_URL` to its full regional URL. Deploy `firebase/database.rules.json`.

The 3.0 schema adds:

- `contacts/{ownerUid}/{contactUid}`
- `blocked/{ownerUid}/{blockedUid}`
- `memberRoles`, `description`, `inviteCode`, `pinnedMessageId` and group permissions
- media metadata, voice duration/waveform and forwarding metadata on messages

Run the supplied public-profile migration when upgrading an old v1 database.

## Storage

Create Firebase Storage and set `NEXA_STORAGE_BUCKET`. Deploy `firebase/storage.rules`.

Uploads are stored under:

```text
users/{uid}/profiles/...
users/{uid}/chats/{chatId}/...
users/{uid}/groups/{chatId}/...
```

The rules require authentication and cap each uploaded object at 50 MB. Authenticated NexaChat users may read message media; only the owner of the top-level `users/{uid}` directory may create, update or delete its files.

## Deployment

```bash
npm install -g firebase-tools
firebase login
firebase use YOUR_PROJECT_ID
firebase deploy --only database,storage
```

## Production recommendations

Use Cloud Functions or another trusted backend for push notification fan-out, abuse throttling, invite approval, moderation and privacy rules that depend on contact relationships. Never place service-account credentials inside the Android application.
