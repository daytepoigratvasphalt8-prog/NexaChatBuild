# Crystal Glass design system

The supplied iPhone home-screen reference was used for visual direction rather than copied as an image asset.

The implementation uses:

- large cyan and blue liquid background lenses;
- translucent cards with white specular highlights;
- colored edge refraction;
- rounded-square action icons;
- a floating frosted Dock;
- stronger depth in dark mode and softer milky glass in light mode.

The effect is implemented with Compose gradients, borders, shadows and animated vector drawing. It does not depend on a bundled wallpaper image.
