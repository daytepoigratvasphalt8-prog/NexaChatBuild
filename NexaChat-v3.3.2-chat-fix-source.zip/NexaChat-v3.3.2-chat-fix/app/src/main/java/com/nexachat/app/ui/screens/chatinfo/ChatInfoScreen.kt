package com.nexachat.app.ui.screens.chatinfo

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ExitToApp
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.ChatRole
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.MediaImage
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.ChatInfoViewModel

@Composable
fun ChatInfoScreen(
    viewModel: ChatInfoViewModel,
    loadMedia: suspend (String) -> ByteArray,
    onBack: () -> Unit,
) {
    val chat by viewModel.chat.collectAsStateWithLifecycle()
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) viewModel.uploadAvatar(uri) }
    var leaveDialog by remember { mutableStateOf(false) }
    val current = chat

    LiquidBackground {
        Column(Modifier.fillMaxSize()) {
            NexaTopBar(
                title = if (current?.type == ChatType.GROUP) "Информация о группе" else "Информация",
                onBack = onBack,
                actions = {
                    if (current?.type == ChatType.GROUP && current.roleOf(viewModel.currentUid) in setOf(ChatRole.OWNER, ChatRole.ADMIN)) {
                        IconButton(onClick = { if (ui.editing) viewModel.save() else viewModel.startEdit() }) {
                            Icon(if (ui.editing) Icons.Rounded.Save else Icons.Rounded.Edit, if (ui.editing) "Сохранить" else "Изменить")
                        }
                    }
                },
            )
            if (current == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                return@LiquidBackground
            }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                GlassPanel(Modifier.fillMaxWidth(), radius = 30.dp) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            if (current.avatarUrl.isNotBlank()) {
                                MediaImage(current.avatarUrl, loadMedia, Modifier.size(108.dp).clip(CircleShape))
                            } else NexaAvatar(current.titleFor(viewModel.currentUid), size = 108.dp)
                            if (current.type == ChatType.GROUP && current.roleOf(viewModel.currentUid) in setOf(ChatRole.OWNER, ChatRole.ADMIN)) {
                                IconButton(onClick = { picker.launch("image/*") }, modifier = Modifier.size(40.dp).align(Alignment.BottomEnd)) {
                                    androidx.compose.material3.Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                                        Icon(Icons.Rounded.CameraAlt, "Фото группы", Modifier.padding(9.dp), tint = MaterialTheme.colorScheme.onPrimary)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.size(12.dp))
                        Text(current.titleFor(viewModel.currentUid), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text(if (current.type == ChatType.GROUP) "${current.memberIds.size} участников" else "Личный чат", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (current.description.isNotBlank()) Text(current.description, Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                ErrorBanner(ui.error, viewModel::clearError)
                if (!ui.notice.isNullOrBlank()) GlassPanel(Modifier.fillMaxWidth(), radius = 18.dp) { Text(ui.notice.orEmpty(), Modifier.padding(14.dp), color = MaterialTheme.colorScheme.primary) }

                if (ui.editing && current.type == ChatType.GROUP) {
                    GlassPanel(Modifier.fillMaxWidth(), radius = 24.dp) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(ui.title, viewModel::setTitle, Modifier.fillMaxWidth(), label = { Text("Название") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                            OutlinedTextField(ui.description, viewModel::setDescription, Modifier.fillMaxWidth(), label = { Text("Описание") }, minLines = 3, supportingText = { Text("${ui.description.length}/255") }, shape = RoundedCornerShape(16.dp))
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TextButton(onClick = viewModel::cancelEdit, modifier = Modifier.weight(1f)) { Text("Отмена") }
                        Box(Modifier.weight(2f)) { NexaPrimaryButton("Сохранить", viewModel::save, loading = ui.saving) }
                    }
                }

                if (current.type == ChatType.GROUP) {
                    Section("ССЫЛКА И ПРАВА") {
                        InfoAction(Icons.Rounded.Link, "Ссылка-приглашение", "nexachat://join/${current.inviteCode}") {
                            clipboard.setText(AnnotatedString("https://nexachat.app/join/${current.inviteCode}"))
                        }
                        if (current.roleOf(viewModel.currentUid) in setOf(ChatRole.OWNER, ChatRole.ADMIN)) {
                            SwitchRow("Писать могут только администраторы", current.onlyAdminsCanPost) { viewModel.setOnlyAdmins(it) }
                            SwitchRow("Одобрять новых участников", current.joinApproval) { viewModel.setJoinApproval(it) }
                        }
                    }
                    if (current.roleOf(viewModel.currentUid) in setOf(ChatRole.OWNER, ChatRole.ADMIN)) {
                        Section("ДОБАВИТЬ УЧАСТНИКА") {
                            OutlinedTextField(
                                value = ui.memberSearch,
                                onValueChange = viewModel::setMemberSearch,
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                                label = { Text("Имя или @username") },
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                            )
                            if (ui.searchingMembers) {
                                Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp) }
                            }
                            ui.memberResults.forEach { profile ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { viewModel.addMember(profile) }.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    NexaAvatar(profile.displayName, size = 42.dp, online = profile.online)
                                    Spacer(Modifier.size(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(profile.displayName, fontWeight = FontWeight.SemiBold)
                                        Text("@${profile.username}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                                    }
                                    Icon(Icons.Rounded.PersonAdd, "Добавить", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }

                    Section("УЧАСТНИКИ • ${ui.members.size}") {
                        ui.members.forEach { member ->
                            MemberRow(
                                profile = member,
                                role = current.roleOf(member.uid),
                                canManage = current.ownerId == viewModel.currentUid && member.uid != viewModel.currentUid,
                                onRole = { viewModel.setRole(member, it) },
                                onRemove = { viewModel.remove(member) },
                            )
                        }
                    }
                    GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp, onClick = { leaveDialog = true }) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.ExitToApp, null, tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.size(12.dp))
                            Text("Покинуть группу", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                Spacer(Modifier.size(60.dp))
            }
        }
    }

    if (leaveDialog) {
        AlertDialog(
            onDismissRequest = { leaveDialog = false },
            title = { Text("Покинуть группу?") },
            text = { Text("Группа исчезнет из списка чатов. Вас смогут добавить снова.") },
            confirmButton = { TextButton(onClick = { leaveDialog = false; viewModel.leave(onBack) }) { Text("Покинуть", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { leaveDialog = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        GlassPanel(Modifier.fillMaxWidth(), radius = 24.dp) { Column { content() } }
    }
}

@Composable
private fun InfoAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium) }
        Icon(Icons.Rounded.ContentCopy, "Копировать", tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.AdminPanelSettings, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(12.dp))
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun MemberRow(profile: UserProfile, role: ChatRole, canManage: Boolean, onRole: (ChatRole) -> Unit, onRemove: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        NexaAvatar(profile.displayName, size = 46.dp, online = profile.online)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(profile.displayName, fontWeight = FontWeight.SemiBold)
            Text(when (role) { ChatRole.OWNER -> "Владелец"; ChatRole.ADMIN -> "Администратор"; ChatRole.MEMBER -> "Участник" }, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
        }
        if (canManage) {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.Person, "Управление") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(if (role == ChatRole.ADMIN) "Сделать участником" else "Сделать администратором") }, leadingIcon = { Icon(Icons.Rounded.AdminPanelSettings, null) }, onClick = { menu = false; onRole(if (role == ChatRole.ADMIN) ChatRole.MEMBER else ChatRole.ADMIN) })
                    DropdownMenuItem(text = { Text("Удалить из группы") }, leadingIcon = { Icon(Icons.Rounded.DeleteOutline, null) }, onClick = { menu = false; onRemove() })
                }
            }
        }
    }
}
