package com.nexachat.app.ui.screens.hub

import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Image as ImageIcon
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.LocalNote
import com.nexachat.app.core.model.ScheduledMessageState
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.HubViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HubScreen(
    viewModel: HubViewModel,
    activeWallpaper: String,
    onOpenChat: (String) -> Unit,
) {
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val scheduled by viewModel.scheduled.collectAsStateWithLifecycle()
    val saved by viewModel.saved.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { MediaPlayer() }
    var playing by remember { mutableStateOf<String?>(null) }
    var noteEditor by remember { mutableStateOf<LocalNote?>(null) }
    var newNote by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { viewModel.refresh() }
    DisposableEffect(Unit) { onDispose { runCatching { player.release() } } }

    Column(Modifier.fillMaxSize()) {
        NexaTopBar("Инструменты", subtitle = "Локальные функции без Firebase")
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                val (chatCount, messageCount) = viewModel.tools.localStats()
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Заметки", notes.size.toString(), Icons.Rounded.EditNote, Modifier.weight(1f))
                    StatCard("Отложено", scheduled.count { it.state == ScheduledMessageState.PENDING }.toString(), Icons.Rounded.Schedule, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Сохранено", saved.size.toString(), Icons.Rounded.Bookmark, Modifier.weight(1f))
                    StatCard("Локально", "$chatCount / $messageCount", Icons.Rounded.Storage, Modifier.weight(1f))
                }
            }

            item { SectionHeader("ЗАМЕТКИ", "Создать", Icons.Rounded.Add) { newNote = true } }
            if (notes.isEmpty()) item { EmptyCard("Здесь будут личные заметки. Они хранятся только на этом устройстве.") }
            items(notes.take(6), key = { it.id }) { note ->
                GlassPanel(Modifier.fillMaxWidth(), radius = 18.dp, onClick = { noteEditor = note }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.NoteAdd, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(note.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(note.body.ifBlank { "Пустая заметка" }, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { viewModel.deleteNote(note.id) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                    }
                }
            }

            item { SectionHeader("ОТЛОЖЕННЫЕ СООБЩЕНИЯ") }
            if (scheduled.isEmpty()) item { EmptyCard("Нажмите значок часов рядом с полем ввода в чате, чтобы отправить сообщение позже.") }
            items(scheduled.take(8), key = { it.id }) { item ->
                GlassPanel(Modifier.fillMaxWidth(), radius = 18.dp) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Schedule, null, tint = when (item.state) {
                            ScheduledMessageState.PENDING -> MaterialTheme.colorScheme.primary
                            ScheduledMessageState.SENT -> MaterialTheme.colorScheme.tertiary
                            ScheduledMessageState.CANCELLED, ScheduledMessageState.FAILED -> MaterialTheme.colorScheme.error
                        })
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.chatTitle, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(item.text, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${stateLabel(item.state)} • ${formatTime(item.sendAt)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (item.state == ScheduledMessageState.PENDING) {
                            TextButton(onClick = { viewModel.cancelScheduled(item.id) }) { Text("Отмена") }
                        } else IconButton(onClick = { viewModel.deleteScheduled(item.id) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                    }
                }
            }

            item { SectionHeader("СОХРАНЁННЫЕ СООБЩЕНИЯ") }
            if (saved.isEmpty()) item { EmptyCard("Откройте действия сообщения и нажмите «Сохранить». Оно появится здесь.") }
            items(saved.take(8), key = { it.id }) { item ->
                GlassPanel(Modifier.fillMaxWidth(), radius = 18.dp, onClick = { onOpenChat(item.chatId) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bookmark, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${item.senderName} • ${item.chatTitle}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.text, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { viewModel.deleteSaved(item.id) }) { Icon(Icons.Rounded.Delete, "Удалить") }
                    }
                }
            }

            item { SectionHeader("ОФЛАЙН-ОБОИ", if (activeWallpaper.isBlank()) "Не выбраны" else "Включены") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 2.dp)) {
                    item {
                        WallpaperTile(null, activeWallpaper.isBlank(), onClick = viewModel::clearWallpaper)
                    }
                    items(viewModel.wallpapers, key = { it }) { asset ->
                        WallpaperTile(asset, activeWallpaper == asset) { viewModel.setWallpaper(asset) }
                    }
                }
            }

            item { SectionHeader("ФОНОВЫЕ ЗВУКИ", "12 треков") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(viewModel.sounds, key = { it }) { asset ->
                        val index = asset.substringAfterLast('_').substringBefore('.').toIntOrNull() ?: 0
                        OutlinedButton(onClick = {
                            if (playing == asset) {
                                runCatching { player.stop() }
                                playing = null
                            } else scope.launch {
                                val file = withContext(Dispatchers.IO) { viewModel.tools.copySoundToCache(asset) }
                                runCatching {
                                    player.reset()
                                    player.setDataSource(file.absolutePath)
                                    player.isLooping = true
                                    player.prepare()
                                    player.start()
                                    playing = asset
                                }
                            }
                        }) {
                            Icon(if (playing == asset) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                            Spacer(Modifier.size(6.dp))
                            Text("Трек $index")
                        }
                    }
                }
            }

            item {
                GlassPanel(Modifier.fillMaxWidth(), radius = 18.dp) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Download, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.size(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Power Pack 100", fontWeight = FontWeight.Bold)
                                Text("40 обоев и 12 фоновых треков доступны без интернета", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Button(onClick = {
                            val (_, uri) = viewModel.tools.exportBundle()
                            context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                                type = "application/json"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }, "Экспорт NexaChat"))
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Share, null)
                            Spacer(Modifier.size(8.dp))
                            Text("Экспортировать локальные данные")
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(22.dp)) }
        }
    }

    if (newNote || noteEditor != null) {
        NoteDialog(noteEditor, onDismiss = { newNote = false; noteEditor = null }) { id, title, body ->
            viewModel.saveNote(id, title, body)
            newNote = false
            noteEditor = null
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    GlassPanel(modifier, radius = 18.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String? = null, icon: androidx.compose.ui.graphics.vector.ImageVector? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        if (action != null && onAction != null) TextButton(onClick = onAction) {
            if (icon != null) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.size(4.dp)) }
            Text(action)
        } else if (action != null) Text(action, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyCard(text: String) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(text, Modifier.fillMaxWidth().padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WallpaperTile(asset: String?, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.size(94.dp, 142.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 0.6.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
    ) {
        if (asset == null) Box(contentAlignment = Alignment.Center) { Text("Без\nобоев", textAlign = androidx.compose.ui.text.style.TextAlign.Center) }
        else AssetImage(asset)
    }
}

@Composable
private fun AssetImage(asset: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, asset) {
        value = withContext(Dispatchers.IO) {
            context.assets.open(asset).use { input ->
                BitmapFactory.decodeStream(input, null, BitmapFactory.Options().apply { inSampleSize = 4 })
            }
        }
    }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.ImageIcon, null) }
}

@Composable
private fun NoteDialog(note: LocalNote?, onDismiss: () -> Unit, onSave: (String?, String, String) -> Unit) {
    var title by remember(note?.id) { mutableStateOf(note?.title.orEmpty()) }
    var body by remember(note?.id) { mutableStateOf(note?.body.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (note == null) "Новая заметка" else "Редактировать заметку") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it.take(120) }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(body, { body = it.take(20_000) }, label = { Text("Текст") }, minLines = 6, maxLines = 12)
            }
        },
        confirmButton = { Button(onClick = { onSave(note?.id, title, body) }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

private fun formatTime(time: Long): String = SimpleDateFormat("dd.MM, HH:mm", Locale.getDefault()).format(Date(time))
private fun stateLabel(state: ScheduledMessageState): String = when (state) {
    ScheduledMessageState.PENDING -> "Ожидает"
    ScheduledMessageState.SENT -> "Отправлено"
    ScheduledMessageState.CANCELLED -> "Отменено"
    ScheduledMessageState.FAILED -> "Ошибка"
}
