package com.nexachat.app.ui.screens.profile

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LockReset
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.MediaImage
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.ProfileViewModel

@Composable
fun ProfileScreen(
    viewModel: ProfileViewModel,
    loadMedia: suspend (String) -> ByteArray,
) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val profile = ui.profile
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.uploadAvatar(uri)
    }

    LiquidBackground {
        Column(Modifier.fillMaxSize()) {
            NexaTopBar(
                title = if (ui.editing) "Изменить профиль" else "Профиль",
                actions = {
                    if (profile != null) {
                        if (ui.editing) {
                            TextButton(onClick = viewModel::cancelEdit, enabled = !ui.saving) { Text("Отмена") }
                        } else {
                            IconButton(onClick = viewModel::startEdit) { Icon(Icons.Rounded.Edit, "Изменить") }
                        }
                    }
                },
            )
            if (profile == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                return@LiquidBackground
            }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                GlassPanel(Modifier.fillMaxWidth(), radius = 30.dp) {
                    Column(
                        Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(contentAlignment = Alignment.BottomEnd) {
                            if (profile.avatarUrl.isNotBlank()) {
                                MediaImage(
                                    url = profile.avatarUrl,
                                    loadBytes = loadMedia,
                                    modifier = Modifier.size(112.dp).clip(CircleShape),
                                )
                            } else {
                                NexaAvatar(profile.displayName, size = 112.dp, online = profile.online)
                            }
                            Box(
                                Modifier.size(38.dp).clip(CircleShape).clickable { photoPicker.launch("image/*") },
                                contentAlignment = Alignment.Center,
                            ) {
                                androidx.compose.material3.Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                                    Icon(Icons.Rounded.CameraAlt, "Изменить фото", Modifier.padding(9.dp), tint = MaterialTheme.colorScheme.onPrimary)
                                }
                            }
                        }
                        if (ui.avatarUploading) {
                            Spacer(Modifier.height(10.dp))
                            CircularProgressIndicator(progress = { ui.avatarProgress.coerceIn(0f, 1f) }, modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(profile.displayName, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Text("@${profile.username}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            if (profile.online) "в сети" else profile.statusText.ifBlank { "NexaChat" },
                            color = if (profile.online) Color(0xFF30D158) else MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        if (profile.avatarUrl.isNotBlank()) {
                            TextButton(onClick = viewModel::removeAvatar, enabled = !ui.avatarUploading) {
                                Icon(Icons.Rounded.DeleteOutline, null, Modifier.size(18.dp))
                                Spacer(Modifier.size(6.dp))
                                Text("Удалить фото")
                            }
                        }
                    }
                }

                ErrorBanner(ui.error, viewModel::clearError)
                if (!ui.notice.isNullOrBlank()) {
                    GlassPanel(Modifier.fillMaxWidth(), radius = 18.dp) {
                        Text(ui.notice.orEmpty(), Modifier.padding(14.dp), color = Color(0xFF30D158), style = MaterialTheme.typography.bodyMedium)
                    }
                }

                if (ui.editing) {
                    EditProfileCard(viewModel, ui.username, ui.firstName, ui.lastName, ui.bio, ui.statusText)
                    NexaPrimaryButton("Сохранить изменения", viewModel::save, loading = ui.saving)
                } else {
                    ProfileSection("О себе") {
                        ProfileRow(Icons.Rounded.Info, "Описание", profile.bio.ifBlank { "Не указано" })
                        ProfileRow(Icons.Rounded.Badge, "Статус", profile.statusText.ifBlank { "Не указан" })
                    }
                    ProfileSection("Публичные данные") {
                        ProfileRow(Icons.Rounded.AlternateEmail, "Username", "@${profile.username}") {
                            clipboard.setText(AnnotatedString("@${profile.username}"))
                        }
                        ProfileRow(Icons.Rounded.Link, "Ссылка на профиль", "nexachat://user/${profile.username}") {
                            clipboard.setText(AnnotatedString("https://nexachat.app/u/${profile.username}"))
                        }
                        ProfileActionRow(Icons.Rounded.Share, "Поделиться профилем") {
                            context.startActivity(
                                Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "${profile.displayName} в NexaChat: https://nexachat.app/u/${profile.username}")
                                    },
                                    "Поделиться профилем",
                                ),
                            )
                        }
                    }
                    ProfileSection("Аккаунт") {
                        ProfileRow(Icons.Rounded.Mail, "Электронная почта", profile.email)
                        ProfileActionRow(Icons.Rounded.Badge, "Подтвердить почту", ui.actionInProgress, viewModel::sendVerification)
                        ProfileActionRow(Icons.Rounded.LockReset, "Изменить пароль", ui.actionInProgress, viewModel::sendPasswordReset)
                    }
                }
                Spacer(Modifier.height(120.dp))
            }
        }
    }
}

@Composable
private fun EditProfileCard(
    viewModel: ProfileViewModel,
    username: String,
    firstName: String,
    lastName: String,
    bio: String,
    status: String,
) {
    GlassPanel(Modifier.fillMaxWidth(), radius = 26.dp) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(username, viewModel::setUsername, Modifier.fillMaxWidth(), label = { Text("Username") }, prefix = { Text("@") }, leadingIcon = { Icon(Icons.Rounded.AlternateEmail, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
            OutlinedTextField(firstName, viewModel::setFirstName, Modifier.fillMaxWidth(), label = { Text("Имя") }, leadingIcon = { Icon(Icons.Rounded.Person, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
            OutlinedTextField(lastName, viewModel::setLastName, Modifier.fillMaxWidth(), label = { Text("Фамилия") }, leadingIcon = { Icon(Icons.Rounded.Person, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
            OutlinedTextField(status, viewModel::setStatus, Modifier.fillMaxWidth(), label = { Text("Статус") }, supportingText = { Text("${status.length}/70") }, shape = RoundedCornerShape(16.dp))
            OutlinedTextField(bio, viewModel::setBio, Modifier.fillMaxWidth(), label = { Text("О себе") }, minLines = 3, supportingText = { Text("${bio.length}/160") }, shape = RoundedCornerShape(16.dp))
        }
    }
}

@Composable
private fun ProfileSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title.uppercase(), Modifier.padding(start = 10.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        GlassPanel(Modifier.fillMaxWidth(), radius = 24.dp) { Column { content() } }
    }
}

@Composable
private fun ProfileRow(icon: ImageVector, title: String, value: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(icon, null, Modifier.size(23.dp), tint = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (onClick != null) Icon(Icons.Rounded.ContentCopy, "Копировать", Modifier.size(19.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ProfileActionRow(icon: ImageVector, title: String, loading: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = !loading, onClick = onClick).padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(icon, null, Modifier.size(23.dp), tint = MaterialTheme.colorScheme.primary)
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        if (loading) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp)
    }
}
