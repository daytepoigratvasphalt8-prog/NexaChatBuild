package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.ContactEntry
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.repository.ContactsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ContactsUiState(
    val query: String = "",
    val loading: Boolean = true,
    val error: String? = null,
)

class ContactsViewModel(
    private val contactsRepository: ContactsRepository,
    private val chats: ChatRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(ContactsUiState())
    val ui: StateFlow<ContactsUiState> = _ui.asStateFlow()
    val blockedIds = contactsRepository.blockedIds

    val contacts: StateFlow<List<ContactEntry>> = combine(contactsRepository.contacts, _ui) { entries, state ->
        val query = state.query.trim().lowercase()
        entries.filter { query.isBlank() || it.profile.displayName.lowercase().contains(query) || it.profile.usernameLower.contains(query) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { refresh() }

    fun setQuery(value: String) = _ui.update { it.copy(query = value.take(64)) }
    fun clearError() = _ui.update { it.copy(error = null) }

    fun refresh() = action(loading = true) { contactsRepository.refresh() }
    fun toggleFavorite(entry: ContactEntry) = action { contactsRepository.setFavorite(entry.profile.uid, !entry.favorite) }
    fun remove(entry: ContactEntry) = action { contactsRepository.remove(entry.profile.uid) }
    fun block(entry: ContactEntry) = action { contactsRepository.block(entry.profile.uid) }
    fun unblock(uid: String) = action { contactsRepository.unblock(uid) }

    fun openDirect(profile: UserProfile, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { chats.createDirect(profile) }
                .onSuccess { onCreated(it.id) }
                .onFailure { error -> _ui.update { it.copy(error = error.message ?: "Не удалось открыть чат") } }
        }
    }

    private fun action(loading: Boolean = false, block: suspend () -> Unit) = viewModelScope.launch {
        if (loading) _ui.update { it.copy(loading = true, error = null) }
        runCatching { block() }
            .onFailure { error -> _ui.update { it.copy(error = error.message ?: "Не удалось выполнить действие") } }
        if (loading) _ui.update { it.copy(loading = false) }
    }

    class Factory(
        private val contacts: ContactsRepository,
        private val chats: ChatRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ContactsViewModel(contacts, chats) as T
    }
}
