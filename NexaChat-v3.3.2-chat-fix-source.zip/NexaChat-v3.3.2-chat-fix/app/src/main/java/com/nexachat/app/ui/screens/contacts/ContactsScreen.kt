package com.nexachat.app.ui.screens.contacts

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.ContactEntry
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.ContactsViewModel

@Composable
fun ContactsScreen(
    viewModel: ContactsViewModel,
    onDiscover: () -> Unit,
    onOpenChat: (String) -> Unit,
) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val favorites = contacts.filter { it.favorite }

    LiquidBackground {
        Column(Modifier.fillMaxSize()) {
            NexaTopBar(
                title = "Контакты",
                subtitle = if (contacts.isEmpty()) "Люди, которых вы добавили" else "${contacts.size} контактов",
                actions = {
                    IconButton(onClick = viewModel::refresh) { Icon(Icons.Rounded.Refresh, "Обновить") }
                    IconButton(onClick = onDiscover) { Icon(Icons.Rounded.PersonSearch, "Найти людей") }
                },
            )
            GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), radius = 27.dp) {
                OutlinedTextField(
                    value = ui.query,
                    onValueChange = viewModel::setQuery,
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = {
                        if (ui.query.isNotBlank()) {
                            IconButton(onClick = { viewModel.setQuery("") }) { Icon(Icons.Rounded.Close, "Очистить") }
                        }
                    },
                    placeholder = { Text("Поиск контактов") },
                    singleLine = true,
                    shape = RoundedCornerShape(27.dp),
                )
            }
            ErrorBanner(ui.error, viewModel::clearError)
            if (!ui.loading && contacts.isEmpty()) {
                EmptyState(
                    title = if (ui.query.isBlank()) "Контактов пока нет" else "Ничего не найдено",
                    message = if (ui.query.isBlank()) "Найдите пользователя по username и добавьте его, чтобы быстро начинать диалоги." else "Измените запрос или очистите строку поиска.",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.PersonSearch,
                    actionText = if (ui.query.isBlank()) "Найти людей" else null,
                    onAction = if (ui.query.isBlank()) onDiscover else null,
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 128.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (favorites.isNotEmpty() && ui.query.isBlank()) {
                        item {
                            Text(
                                "ИЗБРАННЫЕ",
                                Modifier.padding(start = 8.dp, bottom = 2.dp),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                items(favorites, key = { it.profile.uid }) { entry ->
                                    FavoriteContact(entry, onClick = { viewModel.openDirect(entry.profile, onOpenChat) })
                                }
                            }
                        }
                        item {
                            Text(
                                "ВСЕ КОНТАКТЫ",
                                Modifier.padding(start = 8.dp, top = 5.dp, bottom = 2.dp),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    items(contacts, key = { it.profile.uid }) { entry ->
                        ContactRow(
                            entry = entry,
                            onChat = { viewModel.openDirect(entry.profile, onOpenChat) },
                            onFavorite = { viewModel.toggleFavorite(entry) },
                            onRemove = { viewModel.remove(entry) },
                            onBlock = { viewModel.block(entry) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FavoriteContact(entry: ContactEntry, onClick: () -> Unit) {
    GlassPanel(modifier = Modifier.size(width = 106.dp, height = 126.dp), radius = 25.dp, elevation = 9.dp, onClick = onClick) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            NexaAvatar(entry.profile.displayName, size = 58.dp, online = entry.profile.online)
            Text(entry.profile.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("@${entry.profile.username}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}

@Composable
private fun ContactRow(
    entry: ContactEntry,
    onChat: () -> Unit,
    onFavorite: () -> Unit,
    onRemove: () -> Unit,
    onBlock: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    GlassPanel(modifier = Modifier.fillMaxWidth(), radius = 24.dp, onClick = onChat) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            NexaAvatar(entry.profile.displayName, size = 54.dp, online = entry.profile.online)
            Column(Modifier.weight(1f)) {
                Text(entry.profile.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("@${entry.profile.username}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                if (entry.profile.statusText.isNotBlank()) {
                    Text(entry.profile.statusText, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium, maxLines = 1)
                }
            }
            IconButton(onClick = onFavorite) {
                Icon(
                    if (entry.favorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    "Избранное",
                    tint = if (entry.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onChat) { Icon(Icons.Rounded.ChatBubble, "Сообщение", tint = MaterialTheme.colorScheme.primary) }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreHoriz, "Меню") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Удалить контакт") }, leadingIcon = { Icon(Icons.Rounded.DeleteOutline, null) }, onClick = { menu = false; onRemove() })
                    DropdownMenuItem(text = { Text("Заблокировать") }, leadingIcon = { Icon(Icons.Rounded.Block, null) }, onClick = { menu = false; onBlock() })
                }
            }
        }
    }
}
