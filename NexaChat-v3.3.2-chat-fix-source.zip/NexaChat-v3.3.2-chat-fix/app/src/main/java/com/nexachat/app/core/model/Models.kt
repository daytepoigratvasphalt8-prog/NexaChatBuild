package com.nexachat.app.core.model

enum class ChatType { DIRECT, GROUP }
enum class ChatRole { OWNER, ADMIN, MEMBER }
enum class MessageType { TEXT, IMAGE, VIDEO, FILE, VOICE, SYSTEM }
enum class DeliveryState { QUEUED, UPLOADING, SENDING, SENT, DELIVERED, READ, FAILED }
enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class AccentTheme { OCEAN, VIOLET, ROSE, MINT, SUNSET }
enum class BubbleStyle { LIQUID_GLASS, SOFT, MINIMAL }
enum class PrivacyMode { EVERYONE, CONTACTS, NOBODY }
enum class WallpaperStyle { CRYSTAL, AURORA, BLOBS, MIDNIGHT, CLEAN }

data class Session(
    val uid: String,
    val email: String,
    val idToken: String,
    val refreshToken: String,
    val expiresAtEpochSeconds: Long,
) {
    fun isValid(nowEpochSeconds: Long = System.currentTimeMillis() / 1000): Boolean =
        idToken.isNotBlank() && expiresAtEpochSeconds > nowEpochSeconds + 90
}

sealed interface AuthState {
    data object Loading : AuthState
    data object SignedOut : AuthState
    data class SignedIn(val session: Session, val profile: UserProfile?) : AuthState
}

data class UserProfile(
    val uid: String,
    val email: String = "",
    val username: String = "",
    val usernameLower: String = username.lowercase(),
    val firstName: String = "",
    val lastName: String = "",
    val bio: String = "",
    val avatarUrl: String = "",
    val statusText: String = "",
    val online: Boolean = false,
    val lastSeen: Long = 0,
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    val verified: Boolean = false,
    val profileColor: Int = 0,
) {
    val displayName: String
        get() = listOf(firstName, lastName).filter(String::isNotBlank).joinToString(" ")
            .ifBlank { username.ifBlank { email.substringBefore('@') } }

    val initials: String
        get() = displayName.split(Regex("\\s+"))
            .filter(String::isNotBlank)
            .take(2)
            .joinToString("") { it.first().uppercase() }
            .ifBlank { "N" }
}

data class ChatSummary(
    val id: String,
    val type: ChatType = ChatType.DIRECT,
    val title: String = "",
    val description: String = "",
    val avatarUrl: String = "",
    val memberIds: Set<String> = emptySet(),
    val memberNames: Map<String, String> = emptyMap(),
    val memberRoles: Map<String, ChatRole> = emptyMap(),
    val ownerId: String = "",
    val inviteCode: String = "",
    val pinnedMessageId: String = "",
    val lastMessage: String = "",
    val lastMessageType: MessageType = MessageType.TEXT,
    val lastSenderId: String = "",
    val updatedAt: Long = 0,
    val unreadCount: Int = 0,
    val muted: Boolean = false,
    val archived: Boolean = false,
    val pinned: Boolean = false,
    val onlyAdminsCanPost: Boolean = false,
    val joinApproval: Boolean = false,
) {
    fun titleFor(currentUid: String): String = when {
        title.isNotBlank() -> title
        type == ChatType.DIRECT -> memberNames.entries.firstOrNull { it.key != currentUid }?.value ?: "Диалог"
        else -> "Группа"
    }

    fun roleOf(uid: String): ChatRole = memberRoles[uid]
        ?: if (uid == ownerId) ChatRole.OWNER else ChatRole.MEMBER
}

data class Message(
    val id: String,
    val chatId: String,
    val clientId: String,
    val senderId: String,
    val senderUsername: String = "",
    val senderName: String = "",
    val type: MessageType = MessageType.TEXT,
    val text: String = "",
    val attachmentUrl: String = "",
    val thumbnailUrl: String = "",
    val attachmentName: String = "",
    val attachmentMime: String = "",
    val attachmentSize: Long = 0,
    val durationMs: Long = 0,
    val waveform: List<Int> = emptyList(),
    val replyToId: String = "",
    val replyPreview: String = "",
    val forwardedFromId: String = "",
    val forwardedFromName: String = "",
    val createdAt: Long,
    val editedAt: Long = 0,
    val deletedAt: Long = 0,
    val reactions: Map<String, Set<String>> = emptyMap(),
    val readBy: Set<String> = emptySet(),
    val state: DeliveryState = DeliveryState.SENT,
    val pinned: Boolean = false,
) {
    val isDeleted: Boolean get() = deletedAt > 0
    val isMedia: Boolean get() = type in setOf(MessageType.IMAGE, MessageType.VIDEO, MessageType.FILE, MessageType.VOICE)
}

data class DraftMessage(
    val text: String,
    val replyTo: Message? = null,
)

data class SearchResult(
    val profile: UserProfile,
    val isAlreadyMember: Boolean = false,
)

data class TypingState(
    val uid: String,
    val username: String,
    val updatedAt: Long,
)

data class ContactEntry(
    val profile: UserProfile,
    val favorite: Boolean = false,
    val addedAt: Long = 0,
)

data class MediaAttachment(
    val uri: String,
    val storagePath: String,
    val downloadUrl: String,
    val name: String,
    val mime: String,
    val size: Long,
    val durationMs: Long = 0,
    val waveform: List<Int> = emptyList(),
)

data class UploadProgress(
    val active: Boolean = false,
    val fileName: String = "",
    val progress: Float = 0f,
    val error: String? = null,
)

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentTheme: AccentTheme = AccentTheme.OCEAN,
    val wallpaperStyle: WallpaperStyle = WallpaperStyle.CLEAN,
    val bubbleStyle: BubbleStyle = BubbleStyle.SOFT,
    val dynamicColors: Boolean = false,
    val glassEnabled: Boolean = false,
    val glassIntensity: Float = 0.74f,
    val glassShine: Float = 0.72f,
    val glassRefraction: Boolean = true,
    val dashboardWidgets: Boolean = false,
    val quickActions: Boolean = false,
    val dockLabels: Boolean = true,
    val compactChats: Boolean = false,
    val largeText: Boolean = false,
    val fontScale: Float = 1f,
    val highContrast: Boolean = false,
    val reduceMotion: Boolean = false,
    val hapticSend: Boolean = true,
    val sendOnEnter: Boolean = false,
    val showOnline: Boolean = true,
    val readReceipts: Boolean = true,
    val typingIndicators: Boolean = true,
    val dataSaver: Boolean = false,
    val autoDownloadPhotos: Boolean = true,
    val autoDownloadVideos: Boolean = false,
    val autoPlayVideo: Boolean = true,
    val saveToGallery: Boolean = false,
    val backgroundSync: Boolean = true,
    val notificationsEnabled: Boolean = true,
    val notificationPreview: Boolean = true,
    val notificationVibration: Boolean = true,
    val groupBadges: Boolean = true,
    val showMessageTime: Boolean = true,
    val showAvatarsInGroups: Boolean = true,
    val linkPreviews: Boolean = true,
    val confirmBeforeDelete: Boolean = true,
    val voicePlaybackSpeed: Float = 1f,
    val lastSeenPrivacy: PrivacyMode = PrivacyMode.EVERYONE,
    val avatarPrivacy: PrivacyMode = PrivacyMode.EVERYONE,
    val groupsPrivacy: PrivacyMode = PrivacyMode.EVERYONE,
    val chatWallpaperAsset: String = "",
    val chatWallpaperDim: Float = 0.50f,
    val chatBubbleRadius: Float = 22f,
    val chatMessageSpacing: Float = 2f,
    val chatTextScale: Float = 1f,
)


enum class ScheduledMessageState { PENDING, SENT, CANCELLED, FAILED }

data class LocalNote(
    val id: String,
    val title: String,
    val body: String,
    val createdAt: Long,
    val updatedAt: Long,
)

data class ScheduledMessage(
    val id: String,
    val chatId: String,
    val chatTitle: String,
    val text: String,
    val sendAt: Long,
    val createdAt: Long,
    val state: ScheduledMessageState = ScheduledMessageState.PENDING,
    val error: String = "",
)

data class SavedMessage(
    val id: String,
    val chatId: String,
    val chatTitle: String,
    val messageId: String,
    val senderName: String,
    val text: String,
    val createdAt: Long,
    val savedAt: Long,
)

data class OfflinePackInfo(
    val wallpaperCount: Int = 40,
    val soundCount: Int = 12,
    val minimumBytes: Long = 100L * 1024L * 1024L,
)

data class OperationResult<out T>(
    val value: T? = null,
    val error: Throwable? = null,
) {
    val isSuccess: Boolean get() = error == null
    fun getOrThrow(): T = value ?: throw error ?: IllegalStateException("Пустой результат")

    companion object {
        fun <T> success(value: T): OperationResult<T> = OperationResult(value = value)
        fun failure(error: Throwable): OperationResult<Nothing> = OperationResult(error = error)
    }
}
