package com.nexachat.app.core.network

import org.json.JSONObject
import java.net.URLEncoder

class FirebaseStorageService(
    bucket: String,
    private val http: HttpEngine,
) {
    private val bucketName = bucket
        .removePrefix("gs://")
        .trim()
        .ifBlank { throw IllegalArgumentException("Firebase Storage bucket is empty") }

    suspend fun upload(
        path: String,
        token: String,
        bytes: ByteArray,
        mime: String,
        onProgress: ((Long, Long) -> Unit)? = null,
    ): StoredObject {
        val encodedPath = encode(path.trim('/'))
        val url = "https://firebasestorage.googleapis.com/v0/b/${encode(bucketName)}/o?uploadType=media&name=$encodedPath"
        val response = http.requestBytes(
            method = "POST",
            url = url,
            body = bytes,
            contentType = mime.ifBlank { "application/octet-stream" },
            headers = mapOf("Authorization" to "Bearer $token"),
            onProgress = onProgress,
        )
        ensureSuccess(response)
        val json = JSONObject(response.text)
        val name = json.optString("name", path)
        val tokenValue = json.optString("downloadTokens")
            .split(',')
            .firstOrNull()
            .orEmpty()
        val downloadUrl = if (tokenValue.isNotBlank()) {
            "https://firebasestorage.googleapis.com/v0/b/${encode(bucketName)}/o/${encode(name)}?alt=media&token=${encode(tokenValue)}"
        } else {
            "storage://$name"
        }
        return StoredObject(name, downloadUrl, mime, bytes.size.toLong())
    }

    suspend fun download(pathOrUrl: String, token: String): ByteArray {
        val url = when {
            pathOrUrl.startsWith("https://") -> pathOrUrl
            pathOrUrl.startsWith("storage://") -> {
                val path = pathOrUrl.removePrefix("storage://")
                "https://firebasestorage.googleapis.com/v0/b/${encode(bucketName)}/o/${encode(path)}?alt=media"
            }
            else -> "https://firebasestorage.googleapis.com/v0/b/${encode(bucketName)}/o/${encode(pathOrUrl)}?alt=media"
        }
        val authenticated = pathOrUrl.startsWith("storage://") || !url.contains("token=")
        val response = http.requestBytes(
            method = "GET",
            url = url,
            headers = if (authenticated) mapOf("Authorization" to "Bearer $token") else emptyMap(),
        )
        ensureSuccess(response)
        return response.body
    }

    suspend fun delete(pathOrUrl: String, token: String) {
        val path = when {
            pathOrUrl.startsWith("storage://") -> pathOrUrl.removePrefix("storage://")
            else -> pathOrUrl
        }
        if (path.startsWith("https://")) return
        val url = "https://firebasestorage.googleapis.com/v0/b/${encode(bucketName)}/o/${encode(path)}"
        val response = http.requestBytes("DELETE", url, headers = mapOf("Authorization" to "Bearer $token"))
        if (response.code != 404) ensureSuccess(response)
    }

    private fun ensureSuccess(response: BinaryHttpResponse) {
        if (response.isSuccessful) return
        val message = when (response.code) {
            401 -> "Сессия загрузки истекла"
            403 -> "Firebase Storage не разрешил загрузку. Опубликуйте storage.rules"
            404 -> "Файл не найден"
            413 -> "Файл слишком большой"
            429 -> "Слишком много загрузок"
            in 500..599 -> "Хранилище временно недоступно"
            else -> "Ошибка хранилища (${response.code})"
        }
        throw NetworkException(message, response.code, response.text)
    }

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name()).replace("+", "%20")
}

data class StoredObject(
    val path: String,
    val downloadUrl: String,
    val mime: String,
    val size: Long,
)
