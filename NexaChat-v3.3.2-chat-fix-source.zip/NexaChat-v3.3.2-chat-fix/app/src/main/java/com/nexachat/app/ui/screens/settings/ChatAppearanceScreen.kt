package com.nexachat.app.ui.screens.settings

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.BubbleStyle
import com.nexachat.app.ui.components.ChatWallpaperBackground
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ChatAppearanceScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        NexaTopBar(
            title = "Оформление чатов",
            subtitle = "Обои и вид сообщений",
            onBack = onBack,
        )
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "ПРЕДПРОСМОТР",
                Modifier.padding(start = 8.dp, top = 8.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
            Surface(
                modifier = Modifier.fillMaxWidth().height(238.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                ChatWallpaperBackground(
                    asset = settings.chatWallpaperAsset,
                    dim = settings.chatWallpaperDim,
                ) {
                    Column(
                        Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                    ) {
                        PreviewBubble(
                            text = "Как тебе новое оформление?",
                            mine = false,
                            radius = settings.chatBubbleRadius,
                            textScale = settings.chatTextScale,
                        )
                        Spacer(Modifier.height((8f + settings.chatMessageSpacing).dp))
                        PreviewBubble(
                            text = "Теперь намного удобнее 👍",
                            mine = true,
                            radius = settings.chatBubbleRadius,
                            textScale = settings.chatTextScale,
                        )
                    }
                }
            }

            SectionCard("ОБОИ") {
                Text(
                    if (settings.chatWallpaperAsset.isBlank()) "Однотонный фон" else "Выбрано: ${settings.chatWallpaperAsset.substringAfterLast('/').substringBeforeLast('.')}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                LazyRow(
                    contentPadding = PaddingValues(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    item {
                        WallpaperTile(
                            asset = "",
                            selected = settings.chatWallpaperAsset.isBlank(),
                            onClick = { viewModel.setChatWallpaper("") },
                        )
                    }
                    items(viewModel.chatWallpapers, key = { it }) { asset ->
                        WallpaperTile(
                            asset = asset,
                            selected = settings.chatWallpaperAsset == asset,
                            onClick = { viewModel.setChatWallpaper(asset) },
                        )
                    }
                }
                LabeledSlider(
                    title = "Затемнение обоев",
                    valueLabel = "${(settings.chatWallpaperDim * 100).toInt()}%",
                    value = settings.chatWallpaperDim,
                    range = 0f..0.85f,
                    onValueChange = viewModel::setChatWallpaperDim,
                )
            }

            SectionCard("СООБЩЕНИЯ") {
                Text("Стиль пузырей", fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceButton(
                        title = "Мягкие",
                        selected = settings.bubbleStyle == BubbleStyle.SOFT,
                        onClick = { viewModel.setBubbleStyle(BubbleStyle.SOFT) },
                        modifier = Modifier.weight(1f),
                    )
                    ChoiceButton(
                        title = "Минимал",
                        selected = settings.bubbleStyle == BubbleStyle.MINIMAL,
                        onClick = { viewModel.setBubbleStyle(BubbleStyle.MINIMAL) },
                        modifier = Modifier.weight(1f),
                    )
                }
                LabeledSlider(
                    title = "Скругление пузырей",
                    valueLabel = "${settings.chatBubbleRadius.toInt()} dp",
                    value = settings.chatBubbleRadius,
                    range = 8f..28f,
                    onValueChange = viewModel::setChatBubbleRadius,
                )
                LabeledSlider(
                    title = "Расстояние между сообщениями",
                    valueLabel = "${settings.chatMessageSpacing.toInt()} dp",
                    value = settings.chatMessageSpacing,
                    range = 0f..8f,
                    onValueChange = viewModel::setChatMessageSpacing,
                )
                LabeledSlider(
                    title = "Размер текста сообщений",
                    valueLabel = "${(settings.chatTextScale * 100).toInt()}%",
                    value = settings.chatTextScale,
                    range = 0.9f..1.25f,
                    onValueChange = viewModel::setChatTextScale,
                )
            }

            SectionCard("ОТОБРАЖЕНИЕ") {
                ChatSwitchRow(
                    title = "Время сообщений",
                    subtitle = "Показывать время отправки в пузыре",
                    checked = settings.showMessageTime,
                    onCheckedChange = viewModel::setShowMessageTime,
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
                ChatSwitchRow(
                    title = "Имена в группах",
                    subtitle = "Показывать имя автора сообщения",
                    checked = settings.showAvatarsInGroups,
                    onCheckedChange = viewModel::setGroupAvatars,
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
                ChatSwitchRow(
                    title = "Предпросмотр ссылок",
                    subtitle = "Показывать карточку ссылки под текстом",
                    checked = settings.linkPreviews,
                    onCheckedChange = viewModel::setLinkPreviews,
                )
            }

            Button(
                onClick = viewModel::resetChatAppearance,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
            ) {
                androidx.compose.material3.Icon(Icons.Rounded.RestartAlt, null)
                Spacer(Modifier.size(8.dp))
                Text("Вернуть стандартное оформление")
            }
            Text(
                "Настройки применяются ко всем личным и групповым чатам сразу.",
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            title,
            Modifier.padding(start = 8.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
        )
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
        }
    }
}

@Composable
private fun PreviewBubble(text: String, mine: Boolean, radius: Float, textScale: Float) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        val mainRadius = radius.dp
        val tail = (radius * 0.32f).coerceIn(5f, 9f).dp
        Surface(
            shape = RoundedCornerShape(
                topStart = mainRadius,
                topEnd = mainRadius,
                bottomStart = if (mine) mainRadius else tail,
                bottomEnd = if (mine) tail else mainRadius,
            ),
            color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (mine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        ) {
            Text(
                text,
                Modifier.padding(horizontal = 13.dp, vertical = 10.dp),
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = MaterialTheme.typography.bodyLarge.fontSize * textScale),
            )
        }
    }
}

@Composable
private fun WallpaperTile(asset: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .width(84.dp)
            .height(116.dp)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(
                width = if (selected) 3.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                shape = shape,
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (asset.isBlank()) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.background))
                Text("Нет", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            }
        } else {
            WallpaperAssetImage(asset, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.10f)))
            Text(asset.substringAfter("wallpaper_").substringBefore('.'), color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun WallpaperAssetImage(asset: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, asset) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                context.assets.open(asset).use { input ->
                    BitmapFactory.decodeStream(input, null, BitmapFactory.Options().apply { inSampleSize = 8 })
                }
            }.getOrNull()
        }
    }
    if (bitmap != null) {
        Image(bitmap!!.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = ContentScale.Crop)
    }
}

@Composable
private fun ChoiceButton(title: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
    ) {
        Text(title, Modifier.padding(vertical = 11.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun LabeledSlider(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text(valueLabel, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onValueChange, valueRange = range)
    }
}

@Composable
private fun ChatSwitchRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
