package com.nexachat.app.core.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class NetworkException(
    message: String,
    val statusCode: Int = -1,
    val responseBody: String = "",
    cause: Throwable? = null,
) : Exception(message, cause)

data class HttpResponse(
    val code: Int,
    val body: String,
    val headers: Map<String, List<String>>,
) {
    val isSuccessful: Boolean get() = code in 200..299
    fun header(name: String): String? = headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value?.firstOrNull()
}

data class BinaryHttpResponse(
    val code: Int,
    val body: ByteArray,
    val headers: Map<String, List<String>>,
) {
    val isSuccessful: Boolean get() = code in 200..299
    val text: String get() = body.toString(Charsets.UTF_8)
    fun header(name: String): String? = headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value?.firstOrNull()
}

class HttpEngine(
    private val connectTimeoutMs: Int = 20_000,
    private val readTimeoutMs: Int = 45_000,
) {
    suspend fun request(
        method: String,
        url: String,
        body: String? = null,
        headers: Map<String, String> = emptyMap(),
    ): HttpResponse = withContext(Dispatchers.IO) {
        val connection = open(method, url, headers)
        try {
            if (body != null) {
                val bytes = body.toByteArray(Charsets.UTF_8)
                connection.doOutput = true
                if (headers.keys.none { it.equals("Content-Type", true) }) {
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                connection.setFixedLengthStreamingMode(bytes.size)
                connection.outputStream.use { it.write(bytes) }
            }
            val code = connection.responseCode
            val stream = if (code >= 400) connection.errorStream else connection.inputStream
            val responseBody = stream?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            HttpResponse(code, responseBody, connection.headerFields.filterKeys { it != null })
        } catch (error: Exception) {
            throw NetworkException("Ошибка сети", cause = error)
        } finally {
            connection.disconnect()
        }
    }

    suspend fun requestBytes(
        method: String,
        url: String,
        body: ByteArray? = null,
        contentType: String = "application/octet-stream",
        headers: Map<String, String> = emptyMap(),
        onProgress: ((sent: Long, total: Long) -> Unit)? = null,
    ): BinaryHttpResponse = withContext(Dispatchers.IO) {
        val connection = open(method, url, headers).apply {
            setRequestProperty("Accept", "*/*")
        }
        try {
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", contentType)
                connection.setFixedLengthStreamingMode(body.size)
                connection.outputStream.use { output ->
                    var offset = 0
                    val chunk = 64 * 1024
                    while (offset < body.size) {
                        val count = minOf(chunk, body.size - offset)
                        output.write(body, offset, count)
                        offset += count
                        onProgress?.invoke(offset.toLong(), body.size.toLong())
                    }
                }
            }
            val code = connection.responseCode
            val stream = if (code >= 400) connection.errorStream else connection.inputStream
            val bytes = stream?.use { input ->
                ByteArrayOutputStream().use { output ->
                    input.copyTo(output)
                    output.toByteArray()
                }
            } ?: ByteArray(0)
            BinaryHttpResponse(code, bytes, connection.headerFields.filterKeys { it != null })
        } catch (error: Exception) {
            throw NetworkException("Ошибка сети", cause = error)
        } finally {
            connection.disconnect()
        }
    }

    private fun open(method: String, url: String, headers: Map<String, String>): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            useCaches = false
            doInput = true
            instanceFollowRedirects = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "NexaChat-Android/3.1")
            headers.forEach(::setRequestProperty)
        }
}
