package com.nexachat.app.core.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.model.DeliveryState
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.model.MessageType
import com.nexachat.app.core.model.LocalNote
import com.nexachat.app.core.model.SavedMessage
import com.nexachat.app.core.model.ScheduledMessage
import com.nexachat.app.core.model.ScheduledMessageState
import com.nexachat.app.core.network.FirebaseMapper
import org.json.JSONObject

class NexaCacheDb(context: Context) : SQLiteOpenHelper(context, NAME, null, VERSION) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        db.enableWriteAheadLogging()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE chats (
                id TEXT PRIMARY KEY NOT NULL,
                payload TEXT NOT NULL,
                updated_at INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX chats_updated_idx ON chats(updated_at DESC)")
        db.execSQL(
            """
            CREATE TABLE messages (
                id TEXT PRIMARY KEY NOT NULL,
                chat_id TEXT NOT NULL,
                client_id TEXT NOT NULL,
                payload TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                state TEXT NOT NULL,
                UNIQUE(chat_id, client_id) ON CONFLICT REPLACE
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX messages_chat_time_idx ON messages(chat_id, created_at DESC)")
        db.execSQL(
            """
            CREATE TABLE drafts (
                chat_id TEXT PRIMARY KEY NOT NULL,
                text TEXT NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        createHiddenMessagesTable(db)
        createLocalToolsTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE chats ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0")
        }
        if (oldVersion < 3) createHiddenMessagesTable(db)
        if (oldVersion < 4) createLocalToolsTables(db)
    }

    @Synchronized
    fun replaceChats(chats: List<ChatSummary>) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("chats", null, null)
            chats.forEach(::upsertChatInternal)
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    @Synchronized
    fun upsertChat(chat: ChatSummary) = upsertChatInternal(chat)

    private fun upsertChatInternal(chat: ChatSummary) {
        writableDatabase.insertWithOnConflict(
            "chats",
            null,
            ContentValues().apply {
                put("id", chat.id)
                put("payload", chatToJson(chat).toString())
                put("updated_at", chat.updatedAt)
            },
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    @Synchronized
    fun chats(): List<ChatSummary> = readableDatabase.query(
        "chats",
        arrayOf("id", "payload"),
        null,
        null,
        null,
        null,
        "updated_at DESC",
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) {
                val id = cursor.getString(0)
                runCatching { FirebaseMapper.chat(id, JSONObject(cursor.getString(1))) }.getOrNull()?.let(::add)
            }
        }
    }

    @Synchronized
    fun upsertMessages(messages: List<Message>) {
        writableDatabase.beginTransaction()
        try {
            messages.forEach(::upsertMessageInternal)
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    @Synchronized
    fun upsertMessage(message: Message) = upsertMessageInternal(message)

    private fun upsertMessageInternal(message: Message) {
        writableDatabase.insertWithOnConflict(
            "messages",
            null,
            ContentValues().apply {
                put("id", message.id)
                put("chat_id", message.chatId)
                put("client_id", message.clientId)
                put("payload", FirebaseMapper.messageJson(message).toString())
                put("created_at", message.createdAt)
                put("state", message.state.name)
            },
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    @Synchronized
    fun messages(chatId: String, limit: Int = 300): List<Message> = readableDatabase.query(
        "messages",
        arrayOf("id", "payload", "state"),
        "chat_id = ? AND NOT EXISTS (SELECT 1 FROM hidden_messages h WHERE h.id = messages.id)",
        arrayOf(chatId),
        null,
        null,
        "created_at DESC",
        limit.coerceIn(1, 1_000).toString(),
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) {
                val id = cursor.getString(0)
                val payload = cursor.getString(1)
                val state = runCatching { DeliveryState.valueOf(cursor.getString(2)) }.getOrDefault(DeliveryState.SENT)
                runCatching { FirebaseMapper.message(id, chatId, JSONObject(payload)).copy(state = state) }
                    .getOrNull()?.let(::add)
            }
        }.sortedBy(Message::createdAt)
    }

    @Synchronized
    fun pendingMessages(limit: Int = 50): List<Message> = readableDatabase.query(
        "messages",
        arrayOf("id", "chat_id", "payload", "state"),
        "state IN (?, ?)",
        arrayOf(DeliveryState.QUEUED.name, DeliveryState.SENDING.name),
        null,
        null,
        "created_at ASC",
        limit.coerceIn(1, 200).toString(),
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) {
                val id = cursor.getString(0)
                val chatId = cursor.getString(1)
                val payload = cursor.getString(2)
                val state = runCatching { DeliveryState.valueOf(cursor.getString(3)) }
                    .getOrDefault(DeliveryState.FAILED)
                runCatching { FirebaseMapper.message(id, chatId, JSONObject(payload)).copy(state = state) }
                    .getOrNull()?.let(::add)
            }
        }
    }

    @Synchronized
    fun deleteMessage(id: String) {
        writableDatabase.delete("messages", "id = ?", arrayOf(id))
    }

    @Synchronized
    fun hideMessage(chatId: String, id: String) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.insertWithOnConflict(
                "hidden_messages",
                null,
                ContentValues().apply {
                    put("id", id)
                    put("chat_id", chatId)
                    put("hidden_at", System.currentTimeMillis())
                },
                SQLiteDatabase.CONFLICT_REPLACE,
            )
            writableDatabase.delete("messages", "id = ?", arrayOf(id))
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    @Synchronized
    fun updateMessageState(clientId: String, state: DeliveryState) {
        writableDatabase.update(
            "messages",
            ContentValues().apply { put("state", state.name) },
            "client_id = ?",
            arrayOf(clientId),
        )
    }

    @Synchronized
    fun saveDraft(chatId: String, text: String) {
        if (text.isBlank()) {
            writableDatabase.delete("drafts", "chat_id = ?", arrayOf(chatId))
            return
        }
        writableDatabase.insertWithOnConflict(
            "drafts",
            null,
            ContentValues().apply {
                put("chat_id", chatId)
                put("text", text)
                put("updated_at", System.currentTimeMillis())
            },
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    @Synchronized
    fun draft(chatId: String): String = readableDatabase.query(
        "drafts",
        arrayOf("text"),
        "chat_id = ?",
        arrayOf(chatId),
        null,
        null,
        null,
        "1",
    ).use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else "" }

    @Synchronized
    fun clear() {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("messages", null, null)
            writableDatabase.delete("chats", null, null)
            writableDatabase.delete("drafts", null, null)
            writableDatabase.delete("hidden_messages", null, null)
            writableDatabase.delete("local_notes", null, null)
            writableDatabase.delete("scheduled_messages", null, null)
            writableDatabase.delete("saved_messages", null, null)
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }


    @Synchronized
    fun notes(): List<LocalNote> = readableDatabase.query(
        "local_notes",
        arrayOf("id", "title", "body", "created_at", "updated_at"),
        null, null, null, null,
        "updated_at DESC",
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) add(
                LocalNote(
                    id = cursor.getString(0),
                    title = cursor.getString(1),
                    body = cursor.getString(2),
                    createdAt = cursor.getLong(3),
                    updatedAt = cursor.getLong(4),
                ),
            )
        }
    }

    @Synchronized
    fun upsertNote(note: LocalNote) {
        writableDatabase.insertWithOnConflict(
            "local_notes", null,
            ContentValues().apply {
                put("id", note.id)
                put("title", note.title)
                put("body", note.body)
                put("created_at", note.createdAt)
                put("updated_at", note.updatedAt)
            },
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    @Synchronized
    fun deleteNote(id: String) {
        writableDatabase.delete("local_notes", "id = ?", arrayOf(id))
    }

    @Synchronized
    fun scheduledMessages(): List<ScheduledMessage> = readableDatabase.query(
        "scheduled_messages",
        arrayOf("id", "chat_id", "chat_title", "text", "send_at", "created_at", "state", "error"),
        null, null, null, null,
        "CASE state WHEN 'PENDING' THEN 0 ELSE 1 END, send_at ASC",
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) add(
                ScheduledMessage(
                    id = cursor.getString(0),
                    chatId = cursor.getString(1),
                    chatTitle = cursor.getString(2),
                    text = cursor.getString(3),
                    sendAt = cursor.getLong(4),
                    createdAt = cursor.getLong(5),
                    state = runCatching { ScheduledMessageState.valueOf(cursor.getString(6)) }.getOrDefault(ScheduledMessageState.FAILED),
                    error = cursor.getString(7).orEmpty(),
                ),
            )
        }
    }

    @Synchronized
    fun scheduledMessage(id: String): ScheduledMessage? = readableDatabase.query(
        "scheduled_messages",
        arrayOf("id", "chat_id", "chat_title", "text", "send_at", "created_at", "state", "error"),
        "id = ?", arrayOf(id), null, null, null, "1",
    ).use { cursor ->
        if (!cursor.moveToFirst()) null else ScheduledMessage(
            id = cursor.getString(0),
            chatId = cursor.getString(1),
            chatTitle = cursor.getString(2),
            text = cursor.getString(3),
            sendAt = cursor.getLong(4),
            createdAt = cursor.getLong(5),
            state = runCatching { ScheduledMessageState.valueOf(cursor.getString(6)) }.getOrDefault(ScheduledMessageState.FAILED),
            error = cursor.getString(7).orEmpty(),
        )
    }

    @Synchronized
    fun upsertScheduledMessage(item: ScheduledMessage) {
        writableDatabase.insertWithOnConflict(
            "scheduled_messages", null,
            ContentValues().apply {
                put("id", item.id)
                put("chat_id", item.chatId)
                put("chat_title", item.chatTitle)
                put("text", item.text)
                put("send_at", item.sendAt)
                put("created_at", item.createdAt)
                put("state", item.state.name)
                put("error", item.error)
            },
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    @Synchronized
    fun updateScheduledMessage(id: String, state: ScheduledMessageState, error: String = "") {
        writableDatabase.update(
            "scheduled_messages",
            ContentValues().apply { put("state", state.name); put("error", error) },
            "id = ?", arrayOf(id),
        )
    }

    @Synchronized
    fun deleteScheduledMessage(id: String) {
        writableDatabase.delete("scheduled_messages", "id = ?", arrayOf(id))
    }

    @Synchronized
    fun savedMessages(): List<SavedMessage> = readableDatabase.query(
        "saved_messages",
        arrayOf("id", "chat_id", "chat_title", "message_id", "sender_name", "text", "created_at", "saved_at"),
        null, null, null, null,
        "saved_at DESC",
    ).use { cursor ->
        buildList {
            while (cursor.moveToNext()) add(
                SavedMessage(
                    id = cursor.getString(0),
                    chatId = cursor.getString(1),
                    chatTitle = cursor.getString(2),
                    messageId = cursor.getString(3),
                    senderName = cursor.getString(4),
                    text = cursor.getString(5),
                    createdAt = cursor.getLong(6),
                    savedAt = cursor.getLong(7),
                ),
            )
        }
    }

    @Synchronized
    fun upsertSavedMessage(item: SavedMessage) {
        writableDatabase.insertWithOnConflict(
            "saved_messages", null,
            ContentValues().apply {
                put("id", item.id)
                put("chat_id", item.chatId)
                put("chat_title", item.chatTitle)
                put("message_id", item.messageId)
                put("sender_name", item.senderName)
                put("text", item.text)
                put("created_at", item.createdAt)
                put("saved_at", item.savedAt)
            },
            SQLiteDatabase.CONFLICT_REPLACE,
        )
    }

    @Synchronized
    fun deleteSavedMessage(id: String) {
        writableDatabase.delete("saved_messages", "id = ?", arrayOf(id))
    }

    @Synchronized
    fun messageCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM messages", null).use { cursor ->
        if (cursor.moveToFirst()) cursor.getInt(0) else 0
    }

    @Synchronized
    fun chatCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM chats", null).use { cursor ->
        if (cursor.moveToFirst()) cursor.getInt(0) else 0
    }

    private fun createLocalToolsTables(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS local_notes (
                id TEXT PRIMARY KEY NOT NULL,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS local_notes_updated_idx ON local_notes(updated_at DESC)")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS scheduled_messages (
                id TEXT PRIMARY KEY NOT NULL,
                chat_id TEXT NOT NULL,
                chat_title TEXT NOT NULL,
                text TEXT NOT NULL,
                send_at INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                state TEXT NOT NULL,
                error TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS scheduled_messages_time_idx ON scheduled_messages(state, send_at)")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS saved_messages (
                id TEXT PRIMARY KEY NOT NULL,
                chat_id TEXT NOT NULL,
                chat_title TEXT NOT NULL,
                message_id TEXT NOT NULL,
                sender_name TEXT NOT NULL,
                text TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                saved_at INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS saved_messages_saved_idx ON saved_messages(saved_at DESC)")
    }

    private fun createHiddenMessagesTable(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS hidden_messages (
                id TEXT PRIMARY KEY NOT NULL,
                chat_id TEXT NOT NULL,
                hidden_at INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS hidden_messages_chat_idx ON hidden_messages(chat_id)")
    }

    private fun chatToJson(chat: ChatSummary): JSONObject = JSONObject()
        .put("type", chat.type.name.lowercase())
        .put("title", chat.title)
        .put("description", chat.description)
        .put("avatarUrl", chat.avatarUrl)
        .put("memberIds", JSONObject().also { values -> chat.memberIds.forEach { values.put(it, true) } })
        .put("members", JSONObject().also { values -> chat.memberIds.forEach { values.put(it, true) } })
        .put("memberNames", JSONObject(chat.memberNames))
        .put("memberRoles", JSONObject().also { roles -> chat.memberRoles.forEach { (uid, role) -> roles.put(uid, role.name.lowercase()) } })
        .put("ownerId", chat.ownerId)
        .put("inviteCode", chat.inviteCode)
        .put("pinnedMessageId", chat.pinnedMessageId)
        .put("onlyAdminsCanPost", chat.onlyAdminsCanPost)
        .put("joinApproval", chat.joinApproval)
        .put("lastMessage", chat.lastMessage)
        .put("lastMessageType", chat.lastMessageType.name.lowercase())
        .put("lastSenderId", chat.lastSenderId)
        .put("updatedAt", chat.updatedAt)
        .put("unreadCount", chat.unreadCount)
        .put("muted", chat.muted)
        .put("archived", chat.archived)
        .put("pinned", chat.pinned)

    private companion object {
        const val NAME = "nexachat-cache.db"
        const val VERSION = 4
    }
}
