package com.nexachat.app.ui.screens.settings

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.DataSaverOn
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.MarkChatRead
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.BuildConfig
import com.nexachat.app.core.model.AccentTheme
import com.nexachat.app.core.model.BubbleStyle
import com.nexachat.app.core.model.PrivacyMode
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.GlassPill
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(viewModel: SettingsViewModel, onOpenChatAppearance: () -> Unit = {}) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var signOutDialog by remember { mutableStateOf(false) }
    var clearDialog by remember { mutableStateOf(false) }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        viewModel.setNotifications(granted)
    }

    LiquidBackground {
        Column(Modifier.fillMaxSize()) {
            NexaTopBar("Настройки", subtitle = "NexaChat 3.3.1 • Power 100")
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                SectionTitle("ОФОРМЛЕНИЕ")
                SettingsGroup {
                    ChoiceRow("Тема", ThemeMode.entries, settings.themeMode, { themeLabel(it) }, viewModel::setTheme)
                    Divider()
                    ChoiceRow("Акцент", AccentTheme.entries, settings.accentTheme, { accentLabel(it) }, viewModel::setAccent)
                    Divider()
                    SettingSwitch(Icons.Rounded.ColorLens, "Цвета Android", "Использовать системную палитру", settings.dynamicColors, viewModel::setDynamicColors, Color(0xFFAF52DE))
                    SettingSwitch(Icons.Rounded.Smartphone, "Компактный список", "Больше чатов помещается на экране", settings.compactChats, viewModel::setCompactChats, Color(0xFF007AFF))
                }

                SectionTitle("ЧАТЫ И СООБЩЕНИЯ")
                SettingsGroup {
                    ActionRow(Icons.Rounded.Palette, "Оформление чатов", "Обои, пузыри, размер текста и интервалы", Color(0xFF5856D6), onClick = onOpenChatAppearance)
                    Divider()
                    SettingSwitch(Icons.Rounded.Send, "Отправка по Enter", "Enter отправляет, перенос — через Shift", settings.sendOnEnter, viewModel::setSendOnEnter, Color(0xFF34C759))
                    SettingSwitch(Icons.Rounded.TouchApp, "Вибрация при отправке", "Короткий тактильный отклик", settings.hapticSend, viewModel::setHaptic, Color(0xFFFF9500))
                    SettingSwitch(Icons.Rounded.ChatBubbleOutline, "Индикатор набора", "Показывать «печатает…»", settings.typingIndicators, viewModel::setTypingIndicators, Color(0xFF30B0C7))
                    SettingSwitch(Icons.Rounded.DeleteOutline, "Подтверждение удаления", "Защищает от случайного удаления", settings.confirmBeforeDelete, viewModel::setConfirmBeforeDelete, Color(0xFFFF453A))
                    ChoiceRow("Скорость голосовых", listOf(0.5f, 1f, 1.5f, 2f), settings.voicePlaybackSpeed, { "${it}×" }, viewModel::setVoiceSpeed)
                }

                SectionTitle("КОНФИДЕНЦИАЛЬНОСТЬ")
                SettingsGroup {
                    SettingSwitch(Icons.Rounded.Visibility, "Показывать статус онлайн", "Другие увидят, когда вы в сети", settings.showOnline, viewModel::setShowOnline, Color(0xFF34C759))
                    SettingSwitch(Icons.Rounded.MarkChatRead, "Отчёты о прочтении", "Разрешить двойные галочки", settings.readReceipts, viewModel::setReadReceipts, Color(0xFF0A84FF))
                }

                SectionTitle("УВЕДОМЛЕНИЯ")
                SettingsGroup {
                    SettingSwitch(
                        Icons.Rounded.Notifications,
                        "Уведомления",
                        "Новые личные и групповые сообщения",
                        settings.notificationsEnabled,
                        { enabled ->
                            if (enabled && Build.VERSION.SDK_INT >= 33) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            else viewModel.setNotifications(enabled)
                        },
                        Color(0xFFFF453A),
                    )
                    SettingSwitch(Icons.Rounded.Visibility, "Предпросмотр текста", "Показывать содержание сообщения", settings.notificationPreview, viewModel::setNotificationPreview, Color(0xFF0A84FF), settings.notificationsEnabled)
                    SettingSwitch(Icons.Rounded.NotificationsActive, "Вибрация", "Вибрировать при новых сообщениях", settings.notificationVibration, viewModel::setNotificationVibration, Color(0xFFFF9500), settings.notificationsEnabled)
                }

                SectionTitle("ДАННЫЕ И МЕДИА")
                SettingsGroup {
                    SettingSwitch(Icons.Rounded.Sync, "Фоновая синхронизация", "Проверять сообщения вне приложения", settings.backgroundSync, viewModel::setBackgroundSync, Color(0xFF34C759))
                    SettingSwitch(Icons.Rounded.DataSaverOn, "Экономия трафика", "Сократить фоновые загрузки", settings.dataSaver, viewModel::setDataSaver, Color(0xFF30B0C7))
                    SettingSwitch(Icons.Rounded.Image, "Автозагрузка фото", "Загружать изображения при открытии чата", settings.autoDownloadPhotos, viewModel::setAutoPhotos, Color(0xFF5856D6))
                    ActionRow(Icons.Rounded.CleaningServices, "Очистить локальный кэш", "Сообщения и медиа снова загрузятся с сервера", Color(0xFF8E8E93)) { clearDialog = true }
                }

                SectionTitle("ДОСТУПНОСТЬ")
                SettingsGroup {
                    SettingSwitch(Icons.Rounded.TextFields, "Крупный текст", "Увеличить основной шрифт", settings.largeText, viewModel::setLargeText, Color(0xFF0A84FF))
                    SliderRow(Icons.Rounded.TextFields, "Размер текста", settings.fontScale, 0.85f..1.35f, viewModel::setFontScale)
                    SettingSwitch(Icons.Rounded.Contrast, "Повышенный контраст", "Сделать границы и текст заметнее", settings.highContrast, viewModel::setHighContrast, Color(0xFF5856D6))
                    SettingSwitch(Icons.Rounded.AccessibilityNew, "Меньше анимации", "Замедлить движение фона и переходов", settings.reduceMotion, viewModel::setReduceMotion, Color(0xFFAF52DE))
                }

                SectionTitle("АККАУНТ")
                SettingsGroup {
                    ActionRow(Icons.Rounded.PrivacyTip, "Безопасность", "Сессия хранится в Android Keystore", Color(0xFF30B0C7)) {}
                    ActionRow(Icons.Rounded.Logout, "Выйти из аккаунта", "Удалить сессию и локальные данные", Color(0xFFFF453A), destructive = true) { signOutDialog = true }
                }

                Text(
                    "NexaChat ${BuildConfig.VERSION_NAME} • ${BuildConfig.FIREBASE_PROJECT_ID}",
                    Modifier.fillMaxWidth().padding(24.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.size(110.dp))
            }
        }
    }

    if (signOutDialog) ConfirmDialog("Выйти из аккаунта?", "Сессия и локальные данные будут удалены с устройства.", "Выйти", true, { signOutDialog = false }) {
        signOutDialog = false
        viewModel.signOut()
    }
    if (clearDialog) ConfirmDialog("Очистить кэш?", "Переписки останутся на сервере и загрузятся заново.", "Очистить", false, { clearDialog = false }) {
        clearDialog = false
        viewModel.clearCache()
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(start = 10.dp, top = 14.dp, bottom = 2.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
}

@Composable
private fun SettingsGroup(content: @Composable () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth(), radius = 24.dp) { Column { content() } }
}

@Composable
private fun Divider() {
    androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.18f))
}

@Composable
private fun SettingSwitch(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit,
    iconColor: Color,
    enabled: Boolean = true,
) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChecked(!checked) }.padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconTile(icon, iconColor)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = if (enabled) 1f else 0.42f))
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.42f))
        }
        Switch(checked = checked, onCheckedChange = onChecked, enabled = enabled)
    }
}

@Composable
private fun SliderRow(icon: ImageVector, title: String, value: Float, range: ClosedFloatingPointRange<Float>, onValue: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon, MaterialTheme.colorScheme.primary)
            Spacer(Modifier.size(12.dp))
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text("${(value * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value, onValueChange = onValue, valueRange = range, modifier = Modifier.padding(start = 42.dp))
    }
}

@Composable
private fun <T> ChoiceRow(title: String, values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, Modifier.padding(horizontal = 14.dp), fontWeight = FontWeight.SemiBold)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            items(values) { value ->
                GlassPill(selected == value, { onSelect(value) }) {
                    Box(Modifier.padding(horizontal = 16.dp, vertical = 9.dp), contentAlignment = Alignment.Center) {
                        Text(label(value), style = MaterialTheme.typography.labelMedium, fontWeight = if (selected == value) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionRow(icon: ImageVector, title: String, subtitle: String, iconColor: Color, destructive: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        IconTile(icon, iconColor)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun IconTile(icon: ImageVector, color: Color) {
    Box(Modifier.size(32.dp), contentAlignment = Alignment.Center) {
        androidx.compose.material3.Surface(shape = RoundedCornerShape(9.dp), color = color) {
            Icon(icon, null, Modifier.padding(7.dp), tint = Color.White)
        }
    }
}

@Composable
private fun ConfirmDialog(title: String, body: String, confirm: String, destructive: Boolean, dismiss: () -> Unit, action: () -> Unit) {
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = { TextButton(onClick = action) { Text(confirm, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } },
    )
}

private fun themeLabel(value: ThemeMode) = when (value) { ThemeMode.SYSTEM -> "Система"; ThemeMode.LIGHT -> "Светлая"; ThemeMode.DARK -> "Тёмная" }
private fun accentLabel(value: AccentTheme) = when (value) { AccentTheme.OCEAN -> "Океан"; AccentTheme.VIOLET -> "Фиолет"; AccentTheme.ROSE -> "Роза"; AccentTheme.MINT -> "Мята"; AccentTheme.SUNSET -> "Закат" }
private fun bubbleLabel(value: BubbleStyle) = when (value) { BubbleStyle.LIQUID_GLASS, BubbleStyle.SOFT -> "Мягкие"; BubbleStyle.MINIMAL -> "Минимал" }
private fun privacyLabel(value: PrivacyMode) = when (value) { PrivacyMode.EVERYONE -> "Все"; PrivacyMode.CONTACTS -> "Контакты"; PrivacyMode.NOBODY -> "Никто" }
