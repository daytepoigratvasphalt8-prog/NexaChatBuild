package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.SearchResult
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.repository.ContactsRepository
import com.nexachat.app.core.repository.SessionManager
import com.nexachat.app.core.repository.UserRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class NewChatUiState(
    val groupMode: Boolean = false,
    val query: String = "",
    val groupTitle: String = "",
    val results: List<SearchResult> = emptyList(),
    val selected: List<UserProfile> = emptyList(),
    val searching: Boolean = false,
    val creating: Boolean = false,
    val created: ChatSummary? = null,
    val error: String? = null,
    val notice: String? = null,
)

class NewChatViewModel(
    private val users: UserRepository,
    private val chats: ChatRepository,
    private val contacts: ContactsRepository,
    private val sessions: SessionManager,
) : ViewModel() {
    private val _ui = MutableStateFlow(NewChatUiState())
    val ui: StateFlow<NewChatUiState> = _ui.asStateFlow()
    private var searchJob: Job? = null

    fun setGroupMode(value: Boolean) = _ui.update { it.copy(groupMode = value, selected = if (value) it.selected else emptyList(), error = null) }
    fun setGroupTitle(value: String) = _ui.update { it.copy(groupTitle = value.take(64), error = null) }
    fun clearCreated() = _ui.update { it.copy(created = null) }
    fun clearError() = _ui.update { it.copy(error = null) }
    fun clearNotice() = _ui.update { it.copy(notice = null) }

    fun setQuery(value: String) {
        _ui.update { it.copy(query = value.take(64), error = null) }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(350)
            val normalized = value.trim().removePrefix("@")
            if (normalized.length < 2) {
                _ui.update { it.copy(results = emptyList(), searching = false) }
                return@launch
            }
            _ui.update { it.copy(searching = true) }
            runCatching { users.search(normalized) }
                .onSuccess { results ->
                    val ownUid = sessions.session.value?.uid
                    val blocked = contacts.blockedIds.value
                    _ui.update { state -> state.copy(searching = false, results = results.filterNot { it.profile.uid == ownUid || it.profile.uid in blocked }) }
                }
                .onFailure { error -> _ui.update { it.copy(searching = false, error = error.message ?: "Поиск временно недоступен") } }
        }
    }

    fun toggle(profile: UserProfile) {
        val state = _ui.value
        if (!state.groupMode) {
            createDirect(profile)
            return
        }
        _ui.update {
            val selected = if (it.selected.any { user -> user.uid == profile.uid }) it.selected.filterNot { user -> user.uid == profile.uid }
            else (it.selected + profile).take(199)
            it.copy(selected = selected)
        }
    }

    fun addContact(profile: UserProfile) {
        viewModelScope.launch {
            runCatching { contacts.add(profile) }
                .onSuccess { _ui.update { it.copy(notice = "${profile.displayName} добавлен(а) в контакты") } }
                .onFailure { error -> _ui.update { it.copy(error = error.message) } }
        }
    }

    fun createGroup() {
        val state = _ui.value
        if (state.creating) return
        viewModelScope.launch {
            _ui.update { it.copy(creating = true, error = null) }
            runCatching { chats.createGroup(state.groupTitle, state.selected) }
                .onSuccess { chat -> _ui.update { it.copy(creating = false, created = chat) } }
                .onFailure { error -> _ui.update { it.copy(creating = false, error = error.message) } }
        }
    }

    private fun createDirect(profile: UserProfile) {
        if (_ui.value.creating) return
        viewModelScope.launch {
            _ui.update { it.copy(creating = true, error = null) }
            runCatching { chats.createDirect(profile) }
                .onSuccess { chat -> _ui.update { it.copy(creating = false, created = chat) } }
                .onFailure { error -> _ui.update { it.copy(creating = false, error = error.message) } }
        }
    }

    class Factory(
        private val users: UserRepository,
        private val chats: ChatRepository,
        private val contacts: ContactsRepository,
        private val sessions: SessionManager,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = NewChatViewModel(users, chats, contacts, sessions) as T
    }
}
