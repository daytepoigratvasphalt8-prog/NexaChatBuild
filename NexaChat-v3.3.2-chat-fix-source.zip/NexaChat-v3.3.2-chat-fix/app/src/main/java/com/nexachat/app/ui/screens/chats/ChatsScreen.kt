package com.nexachat.app.ui.screens.chats

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.util.TimeFormat
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPill
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.viewmodel.ChatFilter
import com.nexachat.app.ui.viewmodel.ChatsViewModel

@Suppress("UNUSED_PARAMETER")
@Composable
fun ChatsScreen(
    viewModel: ChatsViewModel,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    dashboardWidgets: Boolean,
    quickActions: Boolean,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
    onNewGroup: () -> Unit,
    onOpenContacts: () -> Unit,
) {
    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val allChats by viewModel.allChats.collectAsStateWithLifecycle()
    val meta by viewModel.meta.collectAsStateWithLifecycle()
    val unread = allChats.sumOf { it.unreadCount }

    LiquidBackground {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Чаты", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        Text(
                            when {
                                unread > 0 -> "$unread непрочитанных"
                                allChats.any { !it.archived } -> "Все сообщения прочитаны"
                                else -> "Начните новый диалог"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = onOpenContacts) { Icon(Icons.Rounded.Contacts, "Контакты") }
                    IconButton(onClick = viewModel::refresh) { Icon(Icons.Rounded.Refresh, "Обновить") }
                    FilledTonalIconButton(onClick = onNewChat) { Icon(Icons.Rounded.Add, "Новый чат") }
                }
            }

            item {
                OutlinedTextField(
                    value = meta.query,
                    onValueChange = viewModel::setQuery,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Поиск") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = {
                        if (meta.query.isNotBlank()) IconButton(onClick = viewModel::clearSearch) {
                            Icon(Icons.Rounded.Close, "Очистить")
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                )
            }

            item { FilterSelector(meta.filter, viewModel::setFilter) }
            item { ErrorBanner(meta.error, viewModel::clearError) }

            if (chats.isEmpty()) {
                item {
                    EmptyState(
                        title = if (meta.query.isBlank()) emptyTitle(meta.filter) else "Ничего не найдено",
                        message = if (meta.query.isBlank()) emptyMessage(meta.filter) else "Измените запрос или выберите другой раздел.",
                        modifier = Modifier.fillMaxWidth().height(330.dp),
                        icon = if (meta.query.isBlank()) Icons.Rounded.ChatBubbleOutline else Icons.Rounded.Search,
                        actionText = if (meta.query.isBlank() && meta.filter == ChatFilter.ALL) "Новый диалог" else null,
                        onAction = if (meta.query.isBlank() && meta.filter == ChatFilter.ALL) onNewChat else null,
                    )
                }
            } else {
                if (meta.filter == ChatFilter.ALL && chats.any { it.pinned }) item { ListCaption("Закреплённые") }
                items(chats, key = { it.id }) { chat ->
                    if (meta.filter == ChatFilter.ALL && !chat.pinned && chats.any { it.pinned } && chat.id == chats.firstOrNull { !it.pinned }?.id) {
                        ListCaption("Недавние")
                    }
                    ChatRow(
                        chat = chat,
                        currentUid = currentUid,
                        compact = compact,
                        showGroupBadges = showGroupBadges,
                        onClick = { onOpenChat(chat.id) },
                        onPin = { viewModel.togglePin(chat) },
                        onMute = { viewModel.toggleMute(chat) },
                        onArchive = { viewModel.toggleArchive(chat) },
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterSelector(selected: ChatFilter, onClick: (ChatFilter) -> Unit) {
    val values = listOf(
        ChatFilter.ALL to "Все",
        ChatFilter.UNREAD to "Новые",
        ChatFilter.DIRECT to "Личные",
        ChatFilter.GROUPS to "Группы",
        ChatFilter.ARCHIVED to "Архив",
    )
    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 1.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        items(values) { (value, label) ->
            GlassPill(selected == value, { onClick(value) }) {
                Box(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected == value) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun ListCaption(text: String) {
    Text(
        text,
        Modifier.padding(start = 4.dp, top = 6.dp),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
    )
}

@Composable
private fun ChatRow(
    chat: ChatSummary,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    onClick: () -> Unit,
    onPin: () -> Unit,
    onMute: () -> Unit,
    onArchive: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val title = chat.titleFor(currentUid)
    val shape = RoundedCornerShape(18.dp)
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = shape,
        color = if (chat.unreadCount > 0) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(0.6.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = if (compact) 9.dp else 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                NexaAvatar(title, size = if (compact) 46.dp else 52.dp)
                if (chat.type == ChatType.GROUP) {
                    Surface(
                        Modifier.align(Alignment.BottomEnd).border(2.dp, MaterialTheme.colorScheme.surface, CircleShape),
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                    ) { Icon(Icons.Rounded.Group, null, Modifier.padding(4.dp).size(12.dp), tint = MaterialTheme.colorScheme.onPrimary) }
                }
            }
            Spacer(Modifier.size(11.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (chat.pinned) {
                        Icon(Icons.Rounded.PushPin, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.size(4.dp))
                    }
                    Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        TimeFormat.message(chat.updatedAt),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (chat.unreadCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (chat.type == ChatType.GROUP && showGroupBadges) {
                    Text("${chat.memberIds.size} участников", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        chat.lastMessage.ifBlank { "Начало переписки" },
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (chat.muted) Icon(Icons.Rounded.NotificationsOff, null, Modifier.size(15.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (chat.unreadCount > 0) {
                        Spacer(Modifier.size(6.dp))
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                            Text(
                                chat.unreadCount.coerceAtMost(99).toString(),
                                Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreHoriz, "Меню", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(if (chat.pinned) "Открепить" else "Закрепить") }, leadingIcon = { Icon(Icons.Rounded.PushPin, null) }, onClick = { menu = false; onPin() })
                    DropdownMenuItem(text = { Text(if (chat.muted) "Включить уведомления" else "Без звука") }, leadingIcon = { Icon(Icons.Rounded.NotificationsOff, null) }, onClick = { menu = false; onMute() })
                    DropdownMenuItem(text = { Text(if (chat.archived) "Вернуть из архива" else "В архив") }, leadingIcon = { Icon(if (chat.archived) Icons.Rounded.Unarchive else Icons.Rounded.Archive, null) }, onClick = { menu = false; onArchive() })
                }
            }
        }
    }
}

private fun emptyTitle(filter: ChatFilter): String = when (filter) {
    ChatFilter.ALL -> "Пока нет чатов"
    ChatFilter.UNREAD -> "Всё прочитано"
    ChatFilter.DIRECT -> "Нет личных диалогов"
    ChatFilter.GROUPS -> "Нет групп"
    ChatFilter.ARCHIVED -> "Архив пуст"
}

private fun emptyMessage(filter: ChatFilter): String = when (filter) {
    ChatFilter.ALL -> "Найдите человека по username или создайте группу."
    ChatFilter.UNREAD -> "Новые сообщения появятся здесь."
    ChatFilter.DIRECT -> "Создайте личный диалог через кнопку сверху."
    ChatFilter.GROUPS -> "Создайте группу из окна нового диалога."
    ChatFilter.ARCHIVED -> "Скрытые диалоги будут храниться здесь."
}
