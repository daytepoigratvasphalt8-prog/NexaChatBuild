package com.nexachat.app.ui.theme

import androidx.compose.ui.graphics.Color

val IosBlue = Color(0xFF007AFF)
val IosBlueDark = Color(0xFF0A84FF)
val NexaCyan = Color(0xFF32ADE6)
val NexaPink = Color(0xFFFF2D55)
val NexaPurple = Color(0xFFAF52DE)
val NexaMint = Color(0xFF34C759)
val NexaOrange = Color(0xFFFF9500)
val NexaRed = Color(0xFFFF3B30)

val DarkBackground = Color(0xFF000000)
val DarkSurface = Color(0xFF1C1C1E)
val DarkSurfaceHigh = Color(0xFF2C2C2E)
val DarkText = Color(0xFFF5F5F7)
val DarkMuted = Color(0xFFA1A1AA)
val DarkOutline = Color(0xFF3A3A3C)

val LightBackground = Color(0xFFF2F2F7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFE9E9EF)
val LightText = Color(0xFF111114)
val LightMuted = Color(0xFF6E6E73)
val LightOutline = Color(0xFFD1D1D6)
