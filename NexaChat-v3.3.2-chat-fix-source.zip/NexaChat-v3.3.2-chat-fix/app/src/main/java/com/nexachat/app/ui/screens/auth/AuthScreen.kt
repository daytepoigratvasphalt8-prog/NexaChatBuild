package com.nexachat.app.ui.screens.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.GlassPill
import com.nexachat.app.ui.components.LiquidBackground
import com.nexachat.app.ui.components.NexaLogo
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.viewmodel.AuthViewModel

@Composable
fun AuthScreen(viewModel: AuthViewModel) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    var passwordVisible by remember { mutableStateOf(false) }
    LiquidBackground {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(30.dp))
            NexaLogo()
            Spacer(Modifier.height(30.dp))
            Text(
                if (state.register) "Создайте аккаунт" else "С возвращением",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(7.dp))
            Text(
                if (state.register) "Новый профиль, контакты и защищённые переписки" else "Войдите в NexaChat по электронной почте",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))

            GlassPanel(Modifier.fillMaxWidth(), radius = 30.dp, elevation = 18.dp) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassPill(!state.register, { viewModel.setRegister(false) }, Modifier.weight(1f)) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 11.dp), contentAlignment = Alignment.Center) { Text("Вход", fontWeight = FontWeight.Bold) }
                        }
                        GlassPill(state.register, { viewModel.setRegister(true) }, Modifier.weight(1f)) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 11.dp), contentAlignment = Alignment.Center) { Text("Регистрация", fontWeight = FontWeight.Bold) }
                        }
                    }

                    OutlinedTextField(
                        value = state.email,
                        onValueChange = viewModel::setEmail,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Электронная почта") },
                        leadingIcon = { Icon(Icons.Rounded.AlternateEmail, null) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                        shape = RoundedCornerShape(18.dp),
                    )
                    OutlinedTextField(
                        value = state.password,
                        onValueChange = viewModel::setPassword,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Пароль") },
                        supportingText = { if (state.register) Text("Минимум 6 символов") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, if (passwordVisible) "Скрыть пароль" else "Показать пароль")
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = if (state.register) ImeAction.Next else ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                        shape = RoundedCornerShape(18.dp),
                    )
                    AnimatedVisibility(state.register) {
                        OutlinedTextField(
                            value = state.confirmPassword,
                            onValueChange = viewModel::setConfirmPassword,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Повторите пароль") },
                            leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                            singleLine = true,
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                            shape = RoundedCornerShape(18.dp),
                        )
                    }
                    ErrorBanner(state.error, viewModel::clearError)
                    if (!state.notice.isNullOrBlank()) {
                        GlassPanel(Modifier.fillMaxWidth(), radius = 16.dp) {
                            Text(state.notice.orEmpty(), Modifier.padding(12.dp), color = Color(0xFF30D158), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    NexaPrimaryButton(if (state.register) "Создать аккаунт" else "Войти", viewModel::submit, loading = state.loading)
                    if (!state.register) {
                        Text(
                            "Забыли пароль?",
                            Modifier.align(Alignment.CenterHorizontally).clickable(onClick = viewModel::resetPassword).padding(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "Продолжая, вы соглашаетесь с правилами сервиса и политикой конфиденциальности.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
fun ProfileSetupScreen(viewModel: AuthViewModel, email: String) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    LiquidBackground {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            NexaLogo(compact = true)
            Spacer(Modifier.height(8.dp))
            Text("Завершите профиль", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
            Text("Username нужен для поиска, а имя будет видно в чатах.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            GlassPanel(Modifier.fillMaxWidth(), radius = 18.dp) { Text(email, Modifier.fillMaxWidth().padding(14.dp), style = MaterialTheme.typography.bodyMedium) }
            GlassPanel(Modifier.fillMaxWidth(), radius = 28.dp) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(state.username, viewModel::setUsername, Modifier.fillMaxWidth(), label = { Text("Username") }, prefix = { Text("@") }, leadingIcon = { Icon(Icons.Rounded.Badge, null) }, supportingText = { Text("5–32 символа: A–Z, 0–9 и _") }, singleLine = true, shape = RoundedCornerShape(18.dp))
                    OutlinedTextField(state.firstName, viewModel::setFirstName, Modifier.fillMaxWidth(), label = { Text("Имя") }, leadingIcon = { Icon(Icons.Rounded.Person, null) }, singleLine = true, shape = RoundedCornerShape(18.dp))
                    OutlinedTextField(state.lastName, viewModel::setLastName, Modifier.fillMaxWidth(), label = { Text("Фамилия") }, leadingIcon = { Icon(Icons.Rounded.Person, null) }, singleLine = true, shape = RoundedCornerShape(18.dp))
                    OutlinedTextField(state.bio, viewModel::setBio, Modifier.fillMaxWidth(), label = { Text("О себе") }, minLines = 3, supportingText = { Text("${state.bio.length}/160") }, shape = RoundedCornerShape(18.dp))
                }
            }
            ErrorBanner(state.error, viewModel::clearError)
            NexaPrimaryButton("Сохранить и продолжить", viewModel::completeProfile, loading = state.loading)
        }
    }
}
