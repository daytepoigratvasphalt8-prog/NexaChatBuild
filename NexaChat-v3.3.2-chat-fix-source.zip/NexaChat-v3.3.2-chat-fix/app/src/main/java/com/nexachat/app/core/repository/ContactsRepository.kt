package com.nexachat.app.core.repository

import com.nexachat.app.core.model.ContactEntry
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.network.NetworkException
import com.nexachat.app.core.util.keysList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

class ContactsRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
    private val users: UserRepository,
) {
    private val _contacts = MutableStateFlow<List<ContactEntry>>(emptyList())
    val contacts: StateFlow<List<ContactEntry>> = _contacts.asStateFlow()

    private val _blockedIds = MutableStateFlow<Set<String>>(emptySet())
    val blockedIds: StateFlow<Set<String>> = _blockedIds.asStateFlow()

    suspend fun refresh() {
        val uid = sessions.current().uid
        val token = sessions.token()
        val contactsRoot = compatibility { database.getObject("contacts/$uid", token) } ?: JSONObject()
        val blockedRoot = compatibility { database.getObject("blocked/$uid", token) } ?: JSONObject()
        _blockedIds.value = blockedRoot.keysList().toSet()
        _contacts.value = contactsRoot.keysList().mapNotNull { contactUid ->
            val profile = users.get(contactUid) ?: return@mapNotNull null
            val item = contactsRoot.optJSONObject(contactUid)
            ContactEntry(
                profile = profile,
                favorite = item?.optBoolean("favorite", false) == true,
                addedAt = item?.optLong("addedAt", 0) ?: 0,
            )
        }.sortedWith(compareByDescending<ContactEntry> { it.favorite }.thenBy { it.profile.displayName.lowercase() })
    }

    suspend fun add(profile: UserProfile) {
        val uid = sessions.current().uid
        require(profile.uid != uid) { "Нельзя добавить себя" }
        withAuthRetry { token ->
            database.put(
                "contacts/$uid/${profile.uid}",
                token,
                JSONObject().put("addedAt", System.currentTimeMillis()).put("favorite", false),
            )
        }
        refresh()
    }

    suspend fun remove(profileUid: String) {
        val uid = sessions.current().uid
        withAuthRetry { token -> database.delete("contacts/$uid/$profileUid", token) }
        refresh()
    }

    suspend fun setFavorite(profileUid: String, favorite: Boolean) {
        val uid = sessions.current().uid
        withAuthRetry { token -> database.patch("contacts/$uid/$profileUid", token, JSONObject().put("favorite", favorite)) }
        refresh()
    }

    suspend fun block(profileUid: String) {
        val uid = sessions.current().uid
        require(profileUid != uid) { "Нельзя заблокировать себя" }
        withAuthRetry { token ->
            database.put("blocked/$uid/$profileUid", token, JSONObject().put("blockedAt", System.currentTimeMillis()))
            database.delete("contacts/$uid/$profileUid", token)
        }
        refresh()
    }

    suspend fun unblock(profileUid: String) {
        val uid = sessions.current().uid
        withAuthRetry { token -> database.delete("blocked/$uid/$profileUid", token) }
        refresh()
    }

    suspend fun isBlocked(profileUid: String): Boolean {
        val uid = sessions.current().uid
        return compatibility {
            database.get("blocked/$uid/$profileUid", sessions.token()).let { it != "null" && it.isNotBlank() }
        } ?: false
    }

    private suspend fun <T> compatibility(block: suspend () -> T): T? = try {
        block()
    } catch (error: NetworkException) {
        if (error.statusCode == 400 || error.statusCode == 403 || error.statusCode == 404) null else throw error
    }

    private suspend fun <T> withAuthRetry(block: suspend (String) -> T): T = try {
        block(sessions.token())
    } catch (error: NetworkException) {
        if (error.statusCode == 401) block(sessions.token(forceRefresh = true)) else throw error
    }
}
