package com.nexachat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.media.MediaRepository
import com.nexachat.app.core.model.ChatRole
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.repository.SessionManager
import com.nexachat.app.core.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ChatInfoUiState(
    val members: List<UserProfile> = emptyList(),
    val editing: Boolean = false,
    val title: String = "",
    val description: String = "",
    val loading: Boolean = true,
    val saving: Boolean = false,
    val uploadProgress: Float = 0f,
    val memberSearch: String = "",
    val memberResults: List<UserProfile> = emptyList(),
    val searchingMembers: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
)

class ChatInfoViewModel(
    val chatId: String,
    private val chats: ChatRepository,
    private val users: UserRepository,
    private val media: MediaRepository,
    sessions: SessionManager,
) : ViewModel() {
    val currentUid = sessions.session.value?.uid.orEmpty()
    val chat: StateFlow<ChatSummary?> = chats.chats.map { list -> list.firstOrNull { it.id == chatId } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), chats.chats.value.firstOrNull { it.id == chatId })
    private val _ui = MutableStateFlow(ChatInfoUiState())
    val ui: StateFlow<ChatInfoUiState> = _ui.asStateFlow()
    private var memberSearchJob: Job? = null

    init {
        viewModelScope.launch {
            chat.collect { value ->
                if (value != null) {
                    _ui.update { it.copy(title = if (it.editing) it.title else value.title, description = if (it.editing) it.description else value.description) }
                    loadMembers(value)
                }
            }
        }
    }

    fun startEdit() = _ui.update { it.copy(editing = true, error = null, notice = null) }
    fun cancelEdit() = _ui.update { state -> state.copy(editing = false, title = chat.value?.title.orEmpty(), description = chat.value?.description.orEmpty()) }
    fun setTitle(value: String) = _ui.update { it.copy(title = value.take(80)) }
    fun setDescription(value: String) = _ui.update { it.copy(description = value.take(255)) }
    fun clearError() = _ui.update { it.copy(error = null) }

    fun save() = action(saving = true) {
        require(_ui.value.title.trim().length >= 2) { "Название слишком короткое" }
        chats.updateGroup(chatId, title = _ui.value.title, description = _ui.value.description)
        _ui.update { it.copy(editing = false, notice = "Группа обновлена") }
    }

    fun uploadAvatar(uri: Uri) = action(saving = true) {
        val attachment = media.uploadUri(uri, "groups/$chatId/avatar") { progress -> _ui.update { it.copy(uploadProgress = progress) } }
        chats.updateGroup(chatId, avatarUrl = attachment.downloadUrl)
        _ui.update { it.copy(notice = "Фото группы обновлено") }
    }

    fun setRole(profile: UserProfile, role: ChatRole) = action { chats.setMemberRole(chatId, profile.uid, role) }
    fun remove(profile: UserProfile) = action { chats.removeMember(chatId, profile.uid) }
    fun setOnlyAdmins(value: Boolean) = action { chats.updateGroup(chatId, onlyAdminsCanPost = value) }
    fun setJoinApproval(value: Boolean) = action { chats.updateGroup(chatId, joinApproval = value) }

    fun setMemberSearch(value: String) {
        _ui.update { it.copy(memberSearch = value.take(64), error = null) }
        memberSearchJob?.cancel()
        memberSearchJob = viewModelScope.launch {
            delay(300)
            val query = value.trim().removePrefix("@")
            if (query.length < 2) {
                _ui.update { it.copy(memberResults = emptyList(), searchingMembers = false) }
                return@launch
            }
            _ui.update { it.copy(searchingMembers = true) }
            runCatching { users.search(query, 20) }
                .onSuccess { results ->
                    val existing = chat.value?.memberIds.orEmpty()
                    _ui.update { state -> state.copy(
                        searchingMembers = false,
                        memberResults = results.map { it.profile }.filterNot { it.uid in existing },
                    ) }
                }
                .onFailure { error -> _ui.update { it.copy(searchingMembers = false, error = error.message) } }
        }
    }

    fun addMember(profile: UserProfile) = action {
        chats.addMember(chatId, profile)
        _ui.update { it.copy(memberSearch = "", memberResults = emptyList(), notice = "${profile.displayName} добавлен(а)") }
    }

    fun leave(onDone: () -> Unit) = action { chats.leaveChat(chatId); onDone() }

    private suspend fun loadMembers(chat: ChatSummary) {
        val profiles = chat.memberIds.mapNotNull { uid -> runCatching { users.get(uid) }.getOrNull() }
            .sortedWith(compareBy<UserProfile> { chat.roleOf(it.uid).ordinal }.thenBy { it.displayName.lowercase() })
        _ui.update { it.copy(members = profiles, loading = false) }
    }

    private fun action(saving: Boolean = false, block: suspend () -> Unit) = viewModelScope.launch {
        if (saving) _ui.update { it.copy(saving = true, error = null, notice = null) }
        runCatching { block() }.onFailure { error -> _ui.update { it.copy(error = error.message ?: "Не удалось выполнить действие") } }
        if (saving) _ui.update { it.copy(saving = false) }
    }

    class Factory(
        private val chatId: String,
        private val chats: ChatRepository,
        private val users: UserRepository,
        private val media: MediaRepository,
        private val sessions: SessionManager,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ChatInfoViewModel(chatId, chats, users, media, sessions) as T
    }
}
