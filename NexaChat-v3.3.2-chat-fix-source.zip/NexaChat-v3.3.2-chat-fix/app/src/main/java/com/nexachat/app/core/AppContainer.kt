package com.nexachat.app.core

import android.content.Context
import com.nexachat.app.BuildConfig
import com.nexachat.app.core.database.NexaCacheDb
import com.nexachat.app.core.database.ProfileCache
import com.nexachat.app.core.media.MediaRepository
import com.nexachat.app.core.network.FirebaseAuthService
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.network.FirebaseStorageService
import com.nexachat.app.core.network.HttpEngine
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.repository.ContactsRepository
import com.nexachat.app.core.repository.LocalToolsRepository
import com.nexachat.app.core.repository.SessionManager
import com.nexachat.app.core.repository.UserRepository
import com.nexachat.app.core.security.SecureSessionStore
import com.nexachat.app.core.settings.SettingsRepository

class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    private val http = HttpEngine()
    private val authService = FirebaseAuthService(BuildConfig.FIREBASE_API_KEY, http)
    private val database = FirebaseRealtimeService(BuildConfig.DATABASE_URL, http)
    private val storage = FirebaseStorageService(BuildConfig.STORAGE_BUCKET, http)
    private val sessionStore = SecureSessionStore(appContext)
    private val profileCache = ProfileCache(appContext)
    val sessions = SessionManager(sessionStore, authService)
    val settings = SettingsRepository(appContext)
    val users = UserRepository(database, sessions)
    val contacts = ContactsRepository(database, sessions, users)
    val media = MediaRepository(appContext, storage, sessions)
    val cache = NexaCacheDb(appContext)
    val auth = AuthRepository(authService, database, sessions, profileCache)
    val chats = ChatRepository(database, sessions, users, cache, settings)
    val tools = LocalToolsRepository(appContext, cache)
}
