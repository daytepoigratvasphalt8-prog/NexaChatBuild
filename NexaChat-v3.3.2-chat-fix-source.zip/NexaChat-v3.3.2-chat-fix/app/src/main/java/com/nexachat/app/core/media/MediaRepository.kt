package com.nexachat.app.core.media

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.nexachat.app.core.model.MediaAttachment
import com.nexachat.app.core.network.FirebaseStorageService
import com.nexachat.app.core.repository.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.UUID

class MediaRepository(
    private val context: Context,
    private val storage: FirebaseStorageService,
    private val sessions: SessionManager,
) {
    private val resolver: ContentResolver get() = context.contentResolver
    private val mediaCache = File(context.cacheDir, "nexa_media").apply { mkdirs() }

    suspend fun uploadUri(
        uri: Uri,
        scope: String,
        onProgress: (Float) -> Unit = {},
    ): MediaAttachment = withContext(Dispatchers.IO) {
        val info = inspect(uri)
        require(info.size in 1..MAX_UPLOAD_BYTES) { "Файл должен быть не больше 50 МБ" }
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalArgumentException("Не удалось открыть файл")
        val session = sessions.current()
        val extension = extensionFor(info.name, info.mime)
        val path = "users/${session.uid}/$scope/${System.currentTimeMillis()}_${UUID.randomUUID()}$extension"
        val stored = storage.upload(path, sessions.token(), bytes, info.mime) { sent, total ->
            if (total > 0) onProgress((sent.toFloat() / total.toFloat()).coerceIn(0f, 1f))
        }
        MediaAttachment(
            uri = uri.toString(),
            storagePath = stored.path,
            downloadUrl = stored.downloadUrl,
            name = info.name,
            mime = info.mime,
            size = stored.size,
        )
    }

    suspend fun uploadFile(
        file: File,
        mime: String,
        scope: String,
        durationMs: Long = 0,
        waveform: List<Int> = emptyList(),
        onProgress: (Float) -> Unit = {},
    ): MediaAttachment = withContext(Dispatchers.IO) {
        require(file.exists() && file.length() > 0) { "Файл записи пуст" }
        require(file.length() <= MAX_UPLOAD_BYTES) { "Файл должен быть не больше 50 МБ" }
        val session = sessions.current()
        val extension = extensionFor(file.name, mime)
        val path = "users/${session.uid}/$scope/${System.currentTimeMillis()}_${UUID.randomUUID()}$extension"
        val bytes = file.readBytes()
        val stored = storage.upload(path, sessions.token(), bytes, mime) { sent, total ->
            if (total > 0) onProgress((sent.toFloat() / total.toFloat()).coerceIn(0f, 1f))
        }
        MediaAttachment(
            uri = file.toURI().toString(),
            storagePath = stored.path,
            downloadUrl = stored.downloadUrl,
            name = file.name,
            mime = mime,
            size = stored.size,
            durationMs = durationMs,
            waveform = waveform,
        )
    }

    suspend fun cachedFile(url: String, suggestedName: String = "media"): File = withContext(Dispatchers.IO) {
        val extension = extensionFor(suggestedName, "")
        val key = sha256(url)
        val target = File(mediaCache, "$key$extension")
        if (target.exists() && target.length() > 0) return@withContext target
        val bytes = storage.download(url, sessions.token())
        target.writeBytes(bytes)
        target
    }

    suspend fun bytes(url: String): ByteArray = withContext(Dispatchers.IO) {
        if (url.startsWith("file:")) File(Uri.parse(url).path.orEmpty()).readBytes()
        else storage.download(url, sessions.token())
    }

    fun clearCache() {
        mediaCache.listFiles()?.forEach(File::delete)
    }

    fun cacheSize(): Long = mediaCache.walkTopDown().filter(File::isFile).sumOf(File::length)

    fun newVoiceFile(): File = File(mediaCache, "voice_${System.currentTimeMillis()}.m4a")

    private fun inspect(uri: Uri): FileInfo {
        var name = "file_${System.currentTimeMillis()}"
        var size = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex)
            }
        }
        val mime = resolver.getType(uri).orEmpty().ifBlank { guessMime(name) }
        if (size < 0) size = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        return FileInfo(name, mime, size)
    }

    private fun extensionFor(name: String, mime: String): String {
        val existing = name.substringAfterLast('.', "").takeIf { it.length in 1..8 }
        if (existing != null) return ".${existing.lowercase()}"
        return when (mime.lowercase()) {
            "image/jpeg" -> ".jpg"
            "image/png" -> ".png"
            "image/webp" -> ".webp"
            "video/mp4" -> ".mp4"
            "audio/mp4", "audio/aac" -> ".m4a"
            "application/pdf" -> ".pdf"
            else -> ""
        }
    }

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "mp4", "m4v" -> "video/mp4"
        "m4a", "aac" -> "audio/mp4"
        "mp3" -> "audio/mpeg"
        "pdf" -> "application/pdf"
        else -> "application/octet-stream"
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }

    private data class FileInfo(val name: String, val mime: String, val size: Long)

    companion object {
        const val MAX_UPLOAD_BYTES = 50L * 1024L * 1024L
    }
}
