package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.repository.ChatRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ChatFilter { ALL, UNREAD, DIRECT, GROUPS, ARCHIVED }

data class ChatsMetaState(
    val query: String = "",
    val filter: ChatFilter = ChatFilter.ALL,
    val refreshing: Boolean = false,
    val error: String? = null,
)

class ChatsViewModel(private val repository: ChatRepository) : ViewModel() {
    private val _meta = MutableStateFlow(ChatsMetaState())
    val meta: StateFlow<ChatsMetaState> = _meta.asStateFlow()
    val allChats: StateFlow<List<ChatSummary>> = repository.chats

    val chats: StateFlow<List<ChatSummary>> = combine(repository.chats, _meta) { chats, meta ->
        val query = meta.query.trim().lowercase()
        chats.asSequence()
            .filter { chat ->
                val filterMatch = when (meta.filter) {
                    ChatFilter.ALL -> !chat.archived
                    ChatFilter.UNREAD -> !chat.archived && chat.unreadCount > 0
                    ChatFilter.DIRECT -> !chat.archived && chat.type == ChatType.DIRECT
                    ChatFilter.GROUPS -> !chat.archived && chat.type == ChatType.GROUP
                    ChatFilter.ARCHIVED -> chat.archived
                }
                filterMatch && (
                    query.isBlank() ||
                        chat.title.lowercase().contains(query) ||
                        chat.memberNames.values.any { it.lowercase().contains(query) } ||
                        chat.lastMessage.lowercase().contains(query)
                    )
            }
            .sortedWith(
                compareByDescending<ChatSummary> { it.pinned }
                    .thenByDescending { it.unreadCount > 0 }
                    .thenByDescending { it.updatedAt },
            )
            .toList()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { viewModelScope.launch { runCatching { repository.start() }.onFailure(::setError) } }

    fun setQuery(value: String) = _meta.update { it.copy(query = value.take(120)) }
    fun setFilter(value: ChatFilter) = _meta.update { it.copy(filter = value) }
    fun clearSearch() = _meta.update { it.copy(query = "") }
    fun clearError() = _meta.update { it.copy(error = null) }

    fun refresh() {
        viewModelScope.launch {
            _meta.update { it.copy(refreshing = true, error = null) }
            runCatching { repository.syncChats() }
                .onFailure(::setError)
            _meta.update { it.copy(refreshing = false) }
        }
    }

    fun togglePin(chat: ChatSummary) = mutate { repository.updateChatPreference(chat.id, pinned = !chat.pinned) }
    fun toggleMute(chat: ChatSummary) = mutate { repository.updateChatPreference(chat.id, muted = !chat.muted) }
    fun toggleArchive(chat: ChatSummary) = mutate { repository.updateChatPreference(chat.id, archived = !chat.archived) }

    private fun mutate(action: suspend () -> Unit) = viewModelScope.launch {
        runCatching { action() }.onFailure(::setError)
    }

    private fun setError(error: Throwable) = _meta.update { it.copy(error = error.message ?: "Не удалось обновить чаты") }

    override fun onCleared() {
        repository.stop()
        super.onCleared()
    }

    class Factory(private val repository: ChatRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ChatsViewModel(repository) as T
    }
}
