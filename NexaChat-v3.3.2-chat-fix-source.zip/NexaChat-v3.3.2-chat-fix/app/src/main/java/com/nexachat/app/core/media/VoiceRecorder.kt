package com.nexachat.app.core.media

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import kotlin.math.absoluteValue

class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var startedAt: Long = 0L
    private val samples = mutableListOf<Int>()

    @Suppress("DEPRECATION")
    fun start(file: File) {
        stopSafely()
        file.parentFile?.mkdirs()
        val instance = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context) else MediaRecorder()
        instance.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(96_000)
            setAudioSamplingRate(44_100)
            setOutputFile(file.absolutePath)
            prepare()
            this.start()
        }
        recorder = instance
        startedAt = System.currentTimeMillis()
        samples.clear()
    }

    fun sample(): Int {
        val amplitude = runCatching { recorder?.maxAmplitude ?: 0 }.getOrDefault(0)
        val normalized = ((amplitude / 32767f) * 100f).toInt().absoluteValue.coerceIn(4, 100)
        if (samples.size < 90) samples += normalized
        else if (samples.isNotEmpty()) samples[(System.currentTimeMillis() / 160L % samples.size).toInt()] = normalized
        return normalized
    }

    fun stop(): VoiceRecording? {
        val current = recorder ?: return null
        val duration = System.currentTimeMillis() - startedAt
        return try {
            current.stop()
            VoiceRecording(duration.coerceAtLeast(0), samples.toList())
        } finally {
            current.release()
            recorder = null
        }
    }

    fun cancel() = stopSafely()

    private fun stopSafely() {
        recorder?.let { current ->
            runCatching { current.stop() }
            current.release()
        }
        recorder = null
    }
}

data class VoiceRecording(val durationMs: Long, val waveform: List<Int>)

class VoicePlayer {
    private var player: MediaPlayer? = null

    fun play(file: File, speed: Float = 1f, onCompletion: () -> Unit = {}) {
        stop()
        player = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            prepare()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                playbackParams = playbackParams.setSpeed(speed.coerceIn(0.5f, 2f))
            }
            setOnCompletionListener { onCompletion(); stop() }
            start()
        }
    }

    fun stop() {
        player?.let { runCatching { it.stop() }; it.release() }
        player = null
    }
}
