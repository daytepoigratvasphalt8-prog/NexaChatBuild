package com.nexachat.app.core.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nexachat.app.NexaChatApp
import com.nexachat.app.core.model.ScheduledMessageState

class ScheduledMessageWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString(KEY_ID).orEmpty()
        if (id.isBlank()) return Result.failure()
        val app = applicationContext as? NexaChatApp ?: return Result.failure()
        val item = app.container.tools.scheduledById(id) ?: return Result.success()
        if (item.state == ScheduledMessageState.SENT || item.state == ScheduledMessageState.CANCELLED) return Result.success()
        if (item.sendAt > System.currentTimeMillis() + 2_000) return Result.retry()
        return runCatching {
            app.container.chats.sendMessage(item.chatId, item.text)
            app.container.tools.markScheduled(id, ScheduledMessageState.SENT)
            Result.success()
        }.getOrElse { error ->
            if (runAttemptCount < 3) {
                app.container.tools.markScheduled(id, ScheduledMessageState.PENDING, error.message ?: "Повторная попытка")
                Result.retry()
            } else {
                app.container.tools.markScheduled(id, ScheduledMessageState.FAILED, error.message ?: "Не удалось отправить")
                Result.failure()
            }
        }
    }

    companion object {
        const val KEY_ID = "scheduled_id"
    }
}
