package com.nexachat.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.media.MediaRepository
import com.nexachat.app.core.model.AuthState
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.UserRepository
import com.nexachat.app.core.util.Validation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUiState(
    val profile: UserProfile? = null,
    val username: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val bio: String = "",
    val statusText: String = "",
    val editing: Boolean = false,
    val saving: Boolean = false,
    val avatarUploading: Boolean = false,
    val avatarProgress: Float = 0f,
    val actionInProgress: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
    val saved: Boolean = false,
)

class ProfileViewModel(
    private val auth: AuthRepository,
    private val users: UserRepository,
    private val media: MediaRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(ProfileUiState())
    val ui: StateFlow<ProfileUiState> = _ui.asStateFlow()

    init {
        val profile = (auth.state.value as? AuthState.SignedIn)?.profile
        bind(profile)
        viewModelScope.launch { runCatching { auth.refreshProfile() }.onSuccess(::bind) }
    }

    fun startEdit() = _ui.update { it.copy(editing = true, saved = false, error = null, notice = null) }
    fun cancelEdit() = bind(_ui.value.profile)
    fun setUsername(value: String) = _ui.update {
        it.copy(
            username = value.removePrefix("@").filter { char -> char.isLetterOrDigit() || char == '_' }.take(32),
            error = null,
            notice = null,
        )
    }
    fun setFirstName(value: String) = _ui.update { it.copy(firstName = value.take(48), error = null, notice = null) }
    fun setLastName(value: String) = _ui.update { it.copy(lastName = value.take(48), error = null, notice = null) }
    fun setBio(value: String) = _ui.update { it.copy(bio = value.take(160), error = null, notice = null) }
    fun setStatus(value: String) = _ui.update { it.copy(statusText = value.take(70), error = null, notice = null) }
    fun clearError() = _ui.update { it.copy(error = null) }
    fun clearNotice() = _ui.update { it.copy(notice = null) }

    fun uploadAvatar(uri: Uri) {
        val profile = _ui.value.profile ?: return
        if (_ui.value.avatarUploading) return
        viewModelScope.launch {
            _ui.update { it.copy(avatarUploading = true, avatarProgress = 0f, error = null, notice = null) }
            runCatching {
                val attachment = media.uploadUri(uri, scope = "avatars") { progress ->
                    _ui.update { state -> state.copy(avatarProgress = progress) }
                }
                users.update(profile.copy(avatarUrl = attachment.downloadUrl))
            }.onSuccess { updated ->
                _ui.update { it.copy(profile = updated, avatarUploading = false, avatarProgress = 1f, notice = "Фото профиля обновлено") }
                auth.refreshProfile()
            }.onFailure { error ->
                _ui.update { it.copy(avatarUploading = false, error = error.message ?: "Не удалось загрузить фото") }
            }
        }
    }

    fun removeAvatar() {
        val profile = _ui.value.profile ?: return
        viewModelScope.launch {
            _ui.update { it.copy(avatarUploading = true, error = null) }
            runCatching { users.update(profile.copy(avatarUrl = "")) }
                .onSuccess { updated ->
                    _ui.update { it.copy(profile = updated, avatarUploading = false, notice = "Фото удалено") }
                    auth.refreshProfile()
                }
                .onFailure { error -> _ui.update { it.copy(avatarUploading = false, error = error.message) } }
        }
    }

    fun save() {
        val state = _ui.value
        val profile = state.profile ?: return
        Validation.username(state.username)?.let { error -> _ui.update { it.copy(error = error) }; return }
        Validation.displayName(state.firstName, state.lastName)?.let { error -> _ui.update { it.copy(error = error) }; return }
        Validation.bio(state.bio)?.let { error -> _ui.update { it.copy(error = error) }; return }
        viewModelScope.launch {
            _ui.update { it.copy(saving = true, error = null, notice = null, saved = false) }
            runCatching {
                users.update(
                    profile = profile.copy(
                        firstName = state.firstName.trim(),
                        lastName = state.lastName.trim(),
                        bio = state.bio.trim(),
                        statusText = state.statusText.trim(),
                    ),
                    requestedUsername = state.username,
                )
            }.onSuccess { updated ->
                _ui.update {
                    it.copy(
                        profile = updated,
                        username = updated.username,
                        saving = false,
                        editing = false,
                        saved = true,
                        notice = "Профиль обновлён",
                    )
                }
                auth.refreshProfile()
            }.onFailure { error ->
                _ui.update { it.copy(saving = false, error = error.message ?: "Не удалось сохранить профиль") }
            }
        }
    }

    fun sendPasswordReset() = accountAction("Ссылка для смены пароля отправлена") {
        val email = _ui.value.profile?.email.orEmpty()
        require(email.isNotBlank()) { "Email не указан" }
        auth.resetPassword(email)
    }

    fun sendVerification() = accountAction("Письмо для подтверждения адреса отправлено") { auth.sendVerification() }

    private fun accountAction(notice: String, block: suspend () -> Unit) {
        if (_ui.value.actionInProgress) return
        viewModelScope.launch {
            _ui.update { it.copy(actionInProgress = true, error = null, notice = null) }
            runCatching { block() }
                .onSuccess { _ui.update { it.copy(actionInProgress = false, notice = notice) } }
                .onFailure { error -> _ui.update { it.copy(actionInProgress = false, error = error.message ?: "Не удалось выполнить действие") } }
        }
    }

    private fun bind(profile: UserProfile?) {
        _ui.value = ProfileUiState(
            profile = profile,
            username = profile?.username.orEmpty(),
            firstName = profile?.firstName.orEmpty(),
            lastName = profile?.lastName.orEmpty(),
            bio = profile?.bio.orEmpty(),
            statusText = profile?.statusText.orEmpty(),
        )
    }

    class Factory(
        private val auth: AuthRepository,
        private val users: UserRepository,
        private val media: MediaRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ProfileViewModel(auth, users, media) as T
    }
}
