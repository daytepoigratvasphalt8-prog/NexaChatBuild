package com.nexachat.app.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelsTest {
    @Test
    fun profileBuildsReadableDisplayNameAndInitials() {
        val profile = UserProfile(uid = "1", firstName = "Noah", lastName = "Flores")
        assertEquals("Noah Flores", profile.displayName)
        assertEquals("NF", profile.initials)
    }

    @Test
    fun directChatUsesOtherMembersName() {
        val chat = ChatSummary(
            id = "direct",
            type = ChatType.DIRECT,
            memberIds = setOf("me", "other"),
            memberNames = mapOf("me" to "Me", "other" to "Alex"),
        )
        assertEquals("Alex", chat.titleFor("me"))
    }

    @Test
    fun sessionValidityIncludesRefreshSafetyWindow() {
        val now = 1_000L
        assertTrue(Session("u", "e", "token", "refresh", now + 100).isValid(now))
        assertFalse(Session("u", "e", "token", "refresh", now + 50).isValid(now))
    }

    @Test
    fun groupRolesFallBackSafely() {
        val chat = ChatSummary(
            id = "g",
            type = ChatType.GROUP,
            memberIds = setOf("owner", "member"),
            ownerId = "owner",
            memberRoles = mapOf("member" to ChatRole.ADMIN),
        )
        assertEquals(ChatRole.OWNER, chat.roleOf("owner"))
        assertEquals(ChatRole.ADMIN, chat.roleOf("member"))
        assertEquals(ChatRole.MEMBER, chat.roleOf("unknown"))
    }

    @Test
    fun mediaMessageClassificationIncludesAllAttachmentTypes() {
        fun message(type: MessageType) = Message(
            id = type.name,
            chatId = "chat",
            clientId = "client",
            senderId = "sender",
            type = type,
            createdAt = 1,
        )
        assertTrue(message(MessageType.IMAGE).isMedia)
        assertTrue(message(MessageType.VIDEO).isMedia)
        assertTrue(message(MessageType.FILE).isMedia)
        assertTrue(message(MessageType.VOICE).isMedia)
        assertFalse(message(MessageType.TEXT).isMedia)
    }
}
