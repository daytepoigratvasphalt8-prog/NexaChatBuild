-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keep class com.nexachat.app.core.model.** { *; }
-dontwarn org.json.**

-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.nexachat.app.core.push.NexaMessagingService { *; }
-keep class com.nexachat.app.core.push.CallActionReceiver { *; }
