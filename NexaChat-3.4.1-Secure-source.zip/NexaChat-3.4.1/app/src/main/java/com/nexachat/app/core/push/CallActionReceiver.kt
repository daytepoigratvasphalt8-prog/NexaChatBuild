package com.nexachat.app.core.push

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat
import com.nexachat.app.NexaChatApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_DECLINE) return
        val callId = intent.getStringExtra(EXTRA_CALL_ID).orEmpty()
        if (callId.isBlank()) return
        val pending = goAsync()
        val app = context.applicationContext as NexaChatApp
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                runCatching { app.container.calls.end(callId, declined = true) }
                NotificationManagerCompat.from(context).cancel(callId.hashCode())
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        const val ACTION_DECLINE = "com.nexachat.app.action.DECLINE_CALL"
        const val EXTRA_CALL_ID = "call_id"
    }
}
