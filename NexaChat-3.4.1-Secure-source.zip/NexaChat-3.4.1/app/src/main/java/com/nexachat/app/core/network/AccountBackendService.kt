package com.nexachat.app.core.network

import org.json.JSONObject

class AccountBackendService(
    baseUrl: String,
    private val http: HttpEngine,
) {
    private val root = baseUrl.trimEnd('/')

    suspend fun deleteAccount(idToken: String) = post("deleteAccount", idToken, JSONObject())

    suspend fun revokeAllSessions(idToken: String, keepDeviceId: String? = null) = post(
        "revokeAllSessions",
        idToken,
        JSONObject().apply { if (!keepDeviceId.isNullOrBlank()) put("keepDeviceId", keepDeviceId) },
    )

    private suspend fun post(name: String, token: String, body: JSONObject) {
        require(root.startsWith("https://")) { "Адрес Cloud Functions не настроен" }
        val response = http.request(
            method = "POST",
            url = "$root/$name",
            body = body.toString(),
            headers = mapOf("Authorization" to "Bearer $token"),
        )
        if (!response.isSuccessful) {
            val detail = runCatching { JSONObject(response.body).optString("error") }.getOrDefault("")
            throw NetworkException(detail.ifBlank { "Сервер не выполнил операцию" }, response.code, response.body)
        }
    }
}
