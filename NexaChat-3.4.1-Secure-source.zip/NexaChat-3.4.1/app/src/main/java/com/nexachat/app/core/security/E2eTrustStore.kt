package com.nexachat.app.core.security

import android.content.Context
import java.security.MessageDigest

class E2eTrustStore(context: Context) {
    private val preferences = context.getSharedPreferences("nexachat_e2e_trust_v1", Context.MODE_PRIVATE)

    fun verifyOrPin(uid: String, deviceId: String, publicKey: String) {
        require(uid.isNotBlank() && deviceId.isNotBlank() && publicKey.isNotBlank()) { "Некорректный ключ устройства" }
        val preferenceKey = "${uid.take(80)}:${deviceId.take(100)}"
        val fingerprint = fingerprint(publicKey)
        val pinned = preferences.getString(preferenceKey, null)
        when {
            pinned == null -> preferences.edit().putString(preferenceKey, fingerprint).apply()
            pinned != fingerprint -> throw SecurityException("Ключ безопасности устройства изменился. Проверьте устройства собеседника")
        }
    }

    fun fingerprint(publicKey: String): String = MessageDigest.getInstance("SHA-256")
        .digest(publicKey.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02X".format(it) }
        .chunked(4)
        .joinToString(" ")
}
