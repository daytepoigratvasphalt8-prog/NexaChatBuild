package com.nexachat.app.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource

class E2eKeyStore {
    fun publicKey(uid: String, deviceId: String): String {
        val alias = alias(uid, deviceId)
        val store = keyStore()
        if (!store.containsAlias(alias)) generate(alias)
        val certificate = keyStore().getCertificate(alias)
            ?: throw IllegalStateException("Не удалось получить ключ шифрования")
        return Base64.encodeToString(certificate.publicKey.encoded, Base64.NO_WRAP)
    }

    fun wrap(publicKeyBase64: String, keyBytes: ByteArray): String {
        val publicKey = decodePublicKey(publicKeyBase64)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, publicKey, OAEP_SPEC)
        return Base64.encodeToString(cipher.doFinal(keyBytes), Base64.NO_WRAP)
    }

    fun delete(uid: String, deviceId: String) {
        val store = keyStore()
        if (store.containsAlias(alias(uid, deviceId))) store.deleteEntry(alias(uid, deviceId))
    }

    fun unwrap(uid: String, deviceId: String, wrappedBase64: String): ByteArray {
        val privateKey = keyStore().getKey(alias(uid, deviceId), null) as? PrivateKey
            ?: throw IllegalStateException("Ключ этого устройства недоступен")
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, privateKey, OAEP_SPEC)
        return cipher.doFinal(Base64.decode(wrappedBase64, Base64.NO_WRAP))
    }

    private fun generate(alias: String) {
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
        generator.initialize(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setKeySize(3072)
                .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(false)
                .build(),
        )
        generator.generateKeyPair()
    }

    private fun decodePublicKey(base64: String): PublicKey = KeyFactory.getInstance("RSA")
        .generatePublic(X509EncodedKeySpec(Base64.decode(base64, Base64.NO_WRAP)))

    private fun keyStore(): KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private fun alias(uid: String, deviceId: String) = "nexachat_e2e_${uid.take(40)}_${deviceId.take(48)}"

    private companion object {
        const val TRANSFORMATION = "RSA/ECB/OAEPWithSHA-256AndMGF1Padding"
        val OAEP_SPEC = OAEPParameterSpec(
            "SHA-256",
            "MGF1",
            MGF1ParameterSpec.SHA1,
            PSource.PSpecified.DEFAULT,
        )
    }
}
