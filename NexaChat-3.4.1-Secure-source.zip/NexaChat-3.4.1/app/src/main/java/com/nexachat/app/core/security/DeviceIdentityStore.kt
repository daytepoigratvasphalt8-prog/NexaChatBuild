package com.nexachat.app.core.security

import android.content.Context
import android.os.Build
import java.util.UUID

class DeviceIdentityStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexachat_device_identity", Context.MODE_PRIVATE)

    val deviceId: String
        get() = prefs.getString(KEY_DEVICE_ID, null)?.takeIf { it.isNotBlank() }
            ?: UUID.randomUUID().toString().also { prefs.edit().putString(KEY_DEVICE_ID, it).apply() }

    val deviceName: String
        get() = buildString {
            append(Build.MANUFACTURER.orEmpty().replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() })
            if (Build.MODEL.isNotBlank()) append(" ${Build.MODEL}")
        }.trim().ifBlank { "Android" }

    val deviceModel: String
        get() = listOf(Build.BRAND, Build.MODEL, "Android ${Build.VERSION.RELEASE}")
            .filter { it.isNotBlank() }
            .joinToString(" • ")

    private companion object {
        const val KEY_DEVICE_ID = "device_id"
    }
}
