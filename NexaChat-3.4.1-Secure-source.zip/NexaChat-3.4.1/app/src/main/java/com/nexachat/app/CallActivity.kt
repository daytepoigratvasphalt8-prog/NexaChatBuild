package com.nexachat.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.CallStatus
import com.nexachat.app.ui.theme.NexaChatTheme
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class CallActivity : ComponentActivity() {
    private val container get() = (application as NexaChatApp).container
    private val callId by lazy { intent.getStringExtra(EXTRA_CALL_ID).orEmpty() }
    private val chatId by lazy { intent.getStringExtra(EXTRA_CHAT_ID).orEmpty() }
    private val peerUid by lazy { intent.getStringExtra(EXTRA_PEER_UID).orEmpty() }
    private val peerName by lazy { intent.getStringExtra(EXTRA_PEER_NAME).orEmpty() }
    private val video by lazy { intent.getBooleanExtra(EXTRA_VIDEO, false) }
    private val outgoing by lazy { intent.getBooleanExtra(EXTRA_OUTGOING, false) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationManagerCompat.from(this).cancel(callId.hashCode())
        setContent {
            val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            NexaChatTheme(settings) {
                CallExperience()
            }
        }
    }

    @Composable
    private fun CallExperience() {
        var accepted by remember { mutableStateOf(outgoing) }
        var answering by remember { mutableStateOf(false) }

        LaunchedEffect(callId) {
            container.calls.observeCall(callId).collect { call ->
                if (call == null || call.status in TERMINAL_STATUSES) finish()
            }
        }

        if (!accepted) {
            IncomingCallScreen(
                caller = peerName.ifBlank { "Пользователь NexaChat" },
                video = video,
                busy = answering,
                onAccept = {
                    if (!answering) {
                        answering = true
                        lifecycleScope.launch {
                            runCatching { container.calls.answer(callId) }
                                .onSuccess { accepted = true }
                                .onFailure { finish() }
                            answering = false
                        }
                    }
                },
                onDecline = {
                    lifecycleScope.launch {
                        runCatching { container.calls.end(callId, declined = true) }
                        finish()
                    }
                },
            )
        } else {
            PermissionGate(video) {
                WebRtcCall(callId, peerUid, video, outgoing)
            }
        }
    }

    @Composable
    private fun IncomingCallScreen(
        caller: String,
        video: Boolean,
        busy: Boolean,
        onAccept: () -> Unit,
        onDecline: () -> Unit,
    ) {
        Box(
            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(28.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    modifier = Modifier.size(112.dp),
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(caller.take(1).uppercase(), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(28.dp))
                Text(caller, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (video) "Входящий видеозвонок" else "Входящий аудиозвонок",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(42.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Button(
                        onClick = onDecline,
                        enabled = !busy,
                        modifier = Modifier.weight(1f).height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    ) { Text("Отклонить") }
                    Button(
                        onClick = onAccept,
                        enabled = !busy,
                        modifier = Modifier.weight(1f).height(54.dp),
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        else Text("Ответить")
                    }
                }
            }
        }
    }

    @Composable
    private fun PermissionGate(video: Boolean, content: @Composable () -> Unit) {
        val permissions = remember(video) {
            buildList {
                add(Manifest.permission.RECORD_AUDIO)
                if (video) add(Manifest.permission.CAMERA)
            }.toTypedArray()
        }
        var granted by remember {
            mutableStateOf(permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED })
        }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            granted = permissions.all { result[it] == true || ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
            if (!granted) finish()
        }
        LaunchedEffect(Unit) { if (!granted) launcher.launch(permissions) }
        if (granted) content()
        else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    private fun WebRtcCall(callId: String, peerUid: String, video: Boolean, outgoing: Boolean) {
        var webView by remember { mutableStateOf<WebView?>(null) }
        val bridge = remember(callId, peerUid) { CallBridge(callId, peerUid, video, outgoing) }

        LaunchedEffect(callId, peerUid, webView) {
            val view = webView ?: return@LaunchedEffect
            container.calls.observeSignals(callId, peerUid).collect { signal ->
                val js = "window.nexaSignal(${JSONObject.quote(signal.kind)}, ${JSONObject.quote(signal.payload)});"
                view.post { view.evaluateJavascript(js, null) }
            }
        }
        DisposableEffect(Unit) {
            onDispose {
                webView?.apply {
                    stopLoading()
                    removeJavascriptInterface("NexaBridge")
                    destroy()
                }
                lifecycleScope.launch { runCatching { container.calls.end(callId) } }
            }
        }

        AndroidView(
            modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.domStorageEnabled = true
                    webViewClient = WebViewClient()
                    webChromeClient = object : WebChromeClient() {
                        override fun onPermissionRequest(request: PermissionRequest) {
                            val allowed = request.resources.filter {
                                it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE
                            }.toTypedArray()
                            runOnUiThread {
                                if (allowed.isEmpty()) request.deny() else request.grant(allowed)
                            }
                        }
                    }
                    addJavascriptInterface(bridge, "NexaBridge")
                    loadUrl("file:///android_asset/call/webrtc.html")
                    webView = this
                }
            },
        )
    }

    private inner class CallBridge(
        private val callId: String,
        private val peerUid: String,
        private val video: Boolean,
        private val outgoing: Boolean,
    ) {
        @JavascriptInterface
        fun config(): String {
            val ice = JSONArray().put(JSONObject().put("urls", JSONArray().put("stun:stun.l.google.com:19302")))
            if (BuildConfig.TURN_URL.isNotBlank()) {
                ice.put(
                    JSONObject()
                        .put("urls", JSONArray().put(BuildConfig.TURN_URL))
                        .put("username", BuildConfig.TURN_USERNAME)
                        .put("credential", BuildConfig.TURN_CREDENTIAL),
                )
            }
            return JSONObject()
                .put("uid", container.sessions.session.value?.uid.orEmpty())
                .put("peerUid", peerUid)
                .put("callId", callId)
                .put("video", video)
                .put("outgoing", outgoing)
                .put("iceServers", ice)
                .toString()
        }

        @JavascriptInterface
        fun sendSignal(kind: String, payload: String) {
            lifecycleScope.launch { runCatching { container.calls.sendSignal(callId, kind, payload) } }
        }

        @JavascriptInterface
        fun connected() {
            lifecycleScope.launch { runCatching { container.calls.active(callId) } }
        }

        @JavascriptInterface
        fun endCall() {
            lifecycleScope.launch {
                runCatching { container.calls.end(callId) }
                finish()
            }
        }
    }

    companion object {
        private const val EXTRA_CALL_ID = "call_id"
        private const val EXTRA_CHAT_ID = "chat_id"
        private const val EXTRA_PEER_UID = "peer_uid"
        private const val EXTRA_PEER_NAME = "peer_name"
        private const val EXTRA_VIDEO = "video"
        private const val EXTRA_OUTGOING = "outgoing"
        private val TERMINAL_STATUSES = setOf(CallStatus.ENDED, CallStatus.DECLINED, CallStatus.MISSED, CallStatus.FAILED)

        fun createIntent(
            context: Context,
            callId: String,
            chatId: String,
            peerUid: String,
            video: Boolean,
            outgoing: Boolean,
            peerName: String = "",
        ) = Intent(context, CallActivity::class.java)
            .putExtra(EXTRA_CALL_ID, callId)
            .putExtra(EXTRA_CHAT_ID, chatId)
            .putExtra(EXTRA_PEER_UID, peerUid)
            .putExtra(EXTRA_PEER_NAME, peerName)
            .putExtra(EXTRA_VIDEO, video)
            .putExtra(EXTRA_OUTGOING, outgoing)
    }
}
