package com.nexachat.app.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.DeviceSession
import com.nexachat.app.core.util.TimeFormat
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.GlassPanel
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.SecurityViewModel

@Composable
fun SecurityScreen(viewModel: SecurityViewModel, onBack: () -> Unit) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    var revokeTarget by remember { mutableStateOf<DeviceSession?>(null) }
    var deleteDialog by remember { mutableStateOf(false) }
    var revokeOthersDialog by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        NexaTopBar("Безопасность", subtitle = "Устройства и шифрование", onBack = onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ErrorBanner(ui.error, viewModel::clearError)
            GlassPanel(Modifier.fillMaxWidth(), radius = 22.dp) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Security, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.size(12.dp))
                    Column {
                        Text("Сквозное шифрование включено", fontWeight = FontWeight.Bold)
                        Text(
                            "Ключи сообщений создаются на устройствах и не передаются серверу в открытом виде.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Text("АКТИВНЫЕ УСТРОЙСТВА", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            if (ui.loading) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
            ui.devices.forEachIndexed { index, device ->
                DeviceCard(device) { revokeTarget = device }
            }

            Button(onClick = { revokeOthersDialog = true }, modifier = Modifier.fillMaxWidth(), enabled = !ui.busy) {
                Icon(Icons.Rounded.Logout, null)
                Spacer(Modifier.size(8.dp))
                Text("Завершить остальные сессии")
            }

            Surface(
                modifier = Modifier.fillMaxWidth().clickable(enabled = !ui.busy) { deleteDialog = true },
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.errorContainer,
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.DeleteForever, null, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.size(12.dp))
                    Column {
                        Text("Удалить аккаунт", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        Text("Профиль, ключи, сессии и загруженные файлы будут удалены.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Spacer(Modifier.size(32.dp))
        }
    }

    revokeTarget?.let { device ->
        ConfirmSecurityDialog(
            title = if (device.current) "Завершить текущую сессию?" else "Отключить устройство?",
            body = device.deviceName,
            confirm = "Завершить",
            destructive = true,
            dismiss = { revokeTarget = null },
        ) { revokeTarget = null; viewModel.revoke(device) }
    }
    if (revokeOthersDialog) ConfirmSecurityDialog(
        "Завершить остальные сессии?",
        "Другие устройства получат команду выхода. Текущий телефон останется подключён.",
        "Завершить",
        true,
        { revokeOthersDialog = false },
    ) { revokeOthersDialog = false; viewModel.revokeOthers() }
    if (deleteDialog) ConfirmSecurityDialog(
        "Удалить аккаунт навсегда?",
        "Это действие нельзя отменить. История на устройствах станет недоступна после удаления ключей.",
        "Удалить",
        true,
        { deleteDialog = false },
    ) { deleteDialog = false; viewModel.deleteAccount() }
}

@Composable
private fun DeviceCard(device: DeviceSession, onRevoke: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth(), radius = 20.dp) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Devices, null, tint = if (device.current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(device.deviceName + if (device.current) " • это устройство" else "", fontWeight = FontWeight.SemiBold)
                Text(device.deviceModel, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("NexaChat ${device.appVersion} • активность ${TimeFormat.message(device.lastActiveAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onRevoke) { Text(if (device.current) "Выйти" else "Отключить", color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun ConfirmSecurityDialog(title: String, body: String, confirm: String, destructive: Boolean, dismiss: () -> Unit, action: () -> Unit) {
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = { TextButton(onClick = action) { Text(confirm, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Отмена") } },
    )
}
