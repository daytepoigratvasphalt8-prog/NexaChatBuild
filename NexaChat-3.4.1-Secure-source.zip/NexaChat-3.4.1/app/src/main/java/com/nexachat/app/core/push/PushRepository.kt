package com.nexachat.app.core.push

import android.os.Build
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.nexachat.app.BuildConfig
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.repository.SessionManager
import com.nexachat.app.core.security.DeviceIdentityStore
import kotlin.coroutines.suspendCoroutine
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class PushRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
    private val identity: DeviceIdentityStore,
) {
    suspend fun sync(enabled: Boolean) {
        if (!enabled) {
            unregisterCurrent()
            return
        }
        if (runCatching { FirebaseApp.getApps(com.nexachat.app.NexaChatApp.instance).isEmpty() }.getOrDefault(true)) return
        registerToken(fetchToken())
    }

    suspend fun registerToken(token: String) {
        if (token.isBlank() || sessions.session.value == null) return
        val session = sessions.current()
        database.patch(
            "pushTokens/${session.uid}/${identity.deviceId}",
            session.idToken,
            JSONObject()
                .put("token", token)
                .put("deviceId", identity.deviceId)
                .put("platform", "android")
                .put("deviceName", identity.deviceName)
                .put("sdk", Build.VERSION.SDK_INT)
                .put("appVersion", BuildConfig.VERSION_NAME)
                .put("updatedAt", System.currentTimeMillis()),
        )
    }

    suspend fun unregisterCurrent() {
        val session = sessions.session.value ?: return
        runCatching { database.delete("pushTokens/${session.uid}/${identity.deviceId}", sessions.token()) }
        if (runCatching { FirebaseApp.getApps(com.nexachat.app.NexaChatApp.instance).isNotEmpty() }.getOrDefault(false)) runCatching { FirebaseMessaging.getInstance().deleteToken() }
    }

    private suspend fun fetchToken(): String = suspendCoroutine { continuation ->
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            when {
                task.isSuccessful -> continuation.resume(task.result.orEmpty())
                else -> continuation.resumeWithException(task.exception ?: IllegalStateException("FCM token unavailable"))
            }
        }
    }

}
