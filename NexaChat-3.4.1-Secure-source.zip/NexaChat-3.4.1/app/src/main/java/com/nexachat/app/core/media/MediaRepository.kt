package com.nexachat.app.core.media

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.nexachat.app.core.model.MediaAttachment
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.network.FirebaseStorageService
import com.nexachat.app.core.repository.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import java.util.UUID

class MediaRepository(
    private val context: Context,
    private val storage: FirebaseStorageService,
    private val sessions: SessionManager,
) {
    private val resolver: ContentResolver get() = context.contentResolver
    private val mediaCache = File(context.cacheDir, "nexa_media").apply { mkdirs() }

    suspend fun uploadUri(
        uri: Uri,
        scope: String,
        onProgress: (Float) -> Unit = {},
    ): MediaAttachment = withContext(Dispatchers.IO) {
        val info = inspect(uri)
        require(info.size in 1..MAX_UPLOAD_BYTES) { "Файл должен быть не больше 50 МБ" }
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalArgumentException("Не удалось открыть файл")
        val session = sessions.current()
        val chatAttachment = scope.startsWith("chats/")
        val encrypted = if (chatAttachment) encrypt(bytes) else null
        val extension = if (chatAttachment) ".nexa" else extensionFor(info.name, info.mime)
        val path = "users/${session.uid}/$scope/${System.currentTimeMillis()}_${UUID.randomUUID()}$extension"
        val stored = storage.upload(
            path = path,
            token = sessions.token(),
            bytes = encrypted?.bytes ?: bytes,
            mime = if (chatAttachment) "application/octet-stream" else info.mime,
        ) { sent, total ->
            if (total > 0) onProgress((sent.toFloat() / total.toFloat()).coerceIn(0f, 1f))
        }
        MediaAttachment(
            uri = uri.toString(),
            storagePath = stored.path,
            downloadUrl = stored.downloadUrl,
            name = info.name,
            mime = info.mime,
            size = bytes.size.toLong(),
            mediaEncrypted = encrypted != null,
            mediaKey = encrypted?.key.orEmpty(),
            mediaIv = encrypted?.iv.orEmpty(),
        )
    }

    suspend fun uploadFile(
        file: File,
        mime: String,
        scope: String,
        durationMs: Long = 0,
        waveform: List<Int> = emptyList(),
        onProgress: (Float) -> Unit = {},
    ): MediaAttachment = withContext(Dispatchers.IO) {
        require(file.exists() && file.length() > 0) { "Файл записи пуст" }
        require(file.length() <= MAX_UPLOAD_BYTES) { "Файл должен быть не больше 50 МБ" }
        val session = sessions.current()
        val bytes = file.readBytes()
        val encrypted = encrypt(bytes)
        val path = "users/${session.uid}/$scope/${System.currentTimeMillis()}_${UUID.randomUUID()}.nexa"
        val stored = storage.upload(path, sessions.token(), encrypted.bytes, "application/octet-stream") { sent, total ->
            if (total > 0) onProgress((sent.toFloat() / total.toFloat()).coerceIn(0f, 1f))
        }
        MediaAttachment(
            uri = file.toURI().toString(),
            storagePath = stored.path,
            downloadUrl = stored.downloadUrl,
            name = file.name,
            mime = mime,
            size = bytes.size.toLong(),
            durationMs = durationMs,
            waveform = waveform,
            mediaEncrypted = true,
            mediaKey = encrypted.key,
            mediaIv = encrypted.iv,
        )
    }

    suspend fun cachedFile(url: String, suggestedName: String = "media"): File = withContext(Dispatchers.IO) {
        val extension = extensionFor(suggestedName, "")
        val key = sha256(url)
        val target = File(mediaCache, "$key$extension")
        if (target.exists() && target.length() > 0) return@withContext target
        val bytes = storage.download(url, sessions.token())
        target.writeBytes(bytes)
        target
    }

    suspend fun bytes(url: String): ByteArray = withContext(Dispatchers.IO) {
        if (url.startsWith("file:")) File(Uri.parse(url).path.orEmpty()).readBytes()
        else storage.download(url, sessions.token())
    }

    suspend fun cachedFile(message: Message): File = withContext(Dispatchers.IO) {
        val extension = extensionFor(message.attachmentName.ifBlank { "media" }, message.attachmentMime)
        val key = sha256(message.attachmentUrl + message.mediaIv)
        val target = File(mediaCache, "$key$extension")
        if (target.exists() && target.length() > 0) return@withContext target
        target.writeBytes(bytes(message))
        target
    }

    suspend fun bytes(message: Message): ByteArray = withContext(Dispatchers.IO) {
        val stored = if (message.attachmentUrl.startsWith("file:")) {
            File(Uri.parse(message.attachmentUrl).path.orEmpty()).readBytes()
        } else storage.download(message.attachmentUrl, sessions.token())
        if (!message.mediaEncrypted) stored else decrypt(stored, message.mediaKey, message.mediaIv)
    }

    fun clearCache() {
        mediaCache.listFiles()?.forEach(File::delete)
    }

    fun cacheSize(): Long = mediaCache.walkTopDown().filter(File::isFile).sumOf(File::length)

    fun newVoiceFile(): File = File(mediaCache, "voice_${System.currentTimeMillis()}.m4a")

    private fun encrypt(bytes: ByteArray): EncryptedBytes {
        val key = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        val iv = ByteArray(12).also(SecureRandom()::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return EncryptedBytes(
            bytes = cipher.doFinal(bytes),
            key = Base64.encodeToString(key.encoded, Base64.NO_WRAP),
            iv = Base64.encodeToString(iv, Base64.NO_WRAP),
        )
    }

    private fun decrypt(bytes: ByteArray, key: String, iv: String): ByteArray {
        require(key.isNotBlank() && iv.isNotBlank()) { "Ключ медиафайла отсутствует" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(Base64.decode(key, Base64.NO_WRAP), "AES"),
            GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)),
        )
        return cipher.doFinal(bytes)
    }

    private fun inspect(uri: Uri): FileInfo {
        var name = "file_${System.currentTimeMillis()}"
        var size = -1L
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex)
            }
        }
        val mime = resolver.getType(uri).orEmpty().ifBlank { guessMime(name) }
        if (size < 0) size = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        return FileInfo(name, mime, size)
    }

    private fun extensionFor(name: String, mime: String): String {
        val existing = name.substringAfterLast('.', "").takeIf { it.length in 1..8 }
        if (existing != null) return ".${existing.lowercase()}"
        return when (mime.lowercase()) {
            "image/jpeg" -> ".jpg"
            "image/png" -> ".png"
            "image/webp" -> ".webp"
            "video/mp4" -> ".mp4"
            "audio/mp4", "audio/aac" -> ".m4a"
            "application/pdf" -> ".pdf"
            else -> ""
        }
    }

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "mp4", "m4v" -> "video/mp4"
        "m4a", "aac" -> "audio/mp4"
        "mp3" -> "audio/mpeg"
        "pdf" -> "application/pdf"
        else -> "application/octet-stream"
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }

    private data class FileInfo(val name: String, val mime: String, val size: Long)
    private data class EncryptedBytes(val bytes: ByteArray, val key: String, val iv: String)

    companion object {
        const val MAX_UPLOAD_BYTES = 50L * 1024L * 1024L
    }
}
