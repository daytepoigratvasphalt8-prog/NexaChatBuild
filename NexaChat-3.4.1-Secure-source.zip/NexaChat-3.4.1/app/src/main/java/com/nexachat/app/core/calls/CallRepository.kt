package com.nexachat.app.core.calls

import com.nexachat.app.core.model.CallSession
import com.nexachat.app.core.model.CallStatus
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.repository.SessionManager
import com.nexachat.app.core.repository.UserRepository
import com.nexachat.app.core.util.keysList
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

class CallRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
    private val users: UserRepository,
) {
    suspend fun create(chat: ChatSummary, video: Boolean): CallSession {
        require(chat.type == ChatType.DIRECT) { "Звонки пока доступны только в личных чатах" }
        val session = sessions.current()
        val callee = chat.memberIds.firstOrNull { it != session.uid }
            ?: throw IllegalStateException("Собеседник не найден")
        val me = runCatching { users.get(session.uid) }.getOrNull()
        val call = CallSession(
            id = UUID.randomUUID().toString(),
            chatId = chat.id,
            callerId = session.uid,
            calleeId = callee,
            video = video,
            status = CallStatus.RINGING,
            createdAt = System.currentTimeMillis(),
        )
        database.put(
            "calls/${call.id}",
            session.idToken,
            JSONObject()
                .put("id", call.id)
                .put("chatId", call.chatId)
                .put("callerId", call.callerId)
                .put("callerName", me?.displayName.orEmpty())
                .put("calleeId", call.calleeId)
                .put("video", call.video)
                .put("status", call.status.name.lowercase())
                .put("createdAt", call.createdAt),
        )
        return call
    }

    suspend fun get(callId: String): CallSession? {
        val json = database.getObject("calls/$callId", sessions.token())
        if (json.length() == 0) return null
        return parse(json)
    }

    suspend fun answer(callId: String) = updateStatus(callId, CallStatus.CONNECTING, "answeredAt")
    suspend fun active(callId: String) = updateStatus(callId, CallStatus.ACTIVE, "answeredAt")
    suspend fun end(callId: String, declined: Boolean = false) = updateStatus(
        callId,
        if (declined) CallStatus.DECLINED else CallStatus.ENDED,
        "endedAt",
    )

    suspend fun sendSignal(callId: String, kind: String, payload: String) {
        val uid = sessions.current().uid
        database.post(
            "callSignals/$callId/$uid",
            sessions.token(),
            JSONObject()
                .put("kind", kind.take(40))
                .put("payload", payload.take(500_000))
                .put("createdAt", System.currentTimeMillis()),
        )
    }

    fun observeSignals(callId: String, peerUid: String): Flow<CallSignal> = channelFlow {
        val seen = HashSet<String>()
        suspend fun refresh() {
            val root = database.getObject("callSignals/$callId/$peerUid", sessions.token())
            root.keysList().sorted().forEach { id ->
                if (seen.add(id)) {
                    root.optJSONObject(id)?.let { json ->
                        send(CallSignal(id, json.optString("kind"), json.optString("payload")))
                    }
                }
            }
        }
        launch {
            runCatching { refresh() }
            database.stream("callSignals/$callId/$peerUid") { sessions.token() }.collectLatest { event ->
                if (event.error == null) runCatching { refresh() }
            }
        }
    }

    fun observeCall(callId: String): Flow<CallSession?> = channelFlow {
        suspend fun refresh() { send(get(callId)) }
        launch {
            runCatching { refresh() }
            database.stream("calls/$callId") { sessions.token() }.collectLatest { event ->
                if (event.error == null) {
                    delay(80)
                    runCatching { refresh() }
                }
            }
        }
    }

    private suspend fun updateStatus(callId: String, status: CallStatus, timestampField: String) {
        database.patch(
            "calls/$callId",
            sessions.token(),
            JSONObject().put("status", status.name.lowercase()).put(timestampField, System.currentTimeMillis()),
        )
    }

    private fun parse(json: JSONObject) = CallSession(
        id = json.optString("id"),
        chatId = json.optString("chatId"),
        callerId = json.optString("callerId"),
        calleeId = json.optString("calleeId"),
        video = json.optBoolean("video"),
        status = CallStatus.entries.firstOrNull { it.name.equals(json.optString("status"), true) } ?: CallStatus.RINGING,
        createdAt = json.optLong("createdAt"),
        answeredAt = json.optLong("answeredAt"),
        endedAt = json.optLong("endedAt"),
    )
}

data class CallSignal(val id: String, val kind: String, val payload: String)
