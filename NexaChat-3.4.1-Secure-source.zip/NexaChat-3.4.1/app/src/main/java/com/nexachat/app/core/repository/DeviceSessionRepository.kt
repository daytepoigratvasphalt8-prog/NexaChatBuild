package com.nexachat.app.core.repository

import com.nexachat.app.BuildConfig
import com.nexachat.app.core.model.DeviceSession
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.security.DeviceIdentityStore
import com.nexachat.app.core.util.keysList
import org.json.JSONObject

class DeviceSessionRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
    private val identity: DeviceIdentityStore,
) {
    val currentDeviceId: String get() = identity.deviceId

    suspend fun registerCurrent(pushEnabled: Boolean = true) {
        val session = sessions.current()
        val path = "deviceSessions/${session.uid}/${identity.deviceId}"
        val existing = runCatching { database.getObject(path, session.idToken) }.getOrDefault(JSONObject())
        val now = System.currentTimeMillis()
        database.put(
            path,
            session.idToken,
            JSONObject()
                .put("id", identity.deviceId)
                .put("deviceName", identity.deviceName)
                .put("deviceModel", identity.deviceModel)
                .put("appVersion", BuildConfig.VERSION_NAME)
                .put("createdAt", existing.optLong("createdAt").takeIf { it > 0 } ?: now)
                .put("lastActiveAt", now)
                .put("revokedAt", 0)
                .put("pushEnabled", pushEnabled),
        )
    }

    suspend fun touch() {
        val session = sessions.session.value ?: return
        runCatching {
            database.patch(
                "deviceSessions/${session.uid}/${identity.deviceId}",
                sessions.token(),
                JSONObject().put("lastActiveAt", System.currentTimeMillis()).put("appVersion", BuildConfig.VERSION_NAME),
            )
        }
    }

    suspend fun list(): List<DeviceSession> {
        val session = sessions.current()
        val root = database.getObject("deviceSessions/${session.uid}", session.idToken)
        return root.keysList().mapNotNull { id ->
            root.optJSONObject(id)?.let { json ->
                DeviceSession(
                    id = id,
                    deviceName = json.optString("deviceName", "Android"),
                    deviceModel = json.optString("deviceModel"),
                    appVersion = json.optString("appVersion"),
                    createdAt = json.optLong("createdAt"),
                    lastActiveAt = json.optLong("lastActiveAt"),
                    revokedAt = json.optLong("revokedAt"),
                    pushEnabled = json.optBoolean("pushEnabled"),
                    current = id == identity.deviceId,
                )
            }
        }.sortedWith(compareByDescending<DeviceSession> { it.current }.thenByDescending { it.lastActiveAt })
    }

    suspend fun revoke(deviceId: String) {
        val session = sessions.current()
        database.patch(
            "deviceSessions/${session.uid}/$deviceId",
            session.idToken,
            JSONObject().put("revokedAt", System.currentTimeMillis()),
        )
    }

    suspend fun isCurrentActive(): Boolean {
        val session = sessions.session.value ?: return false
        val json = database.getObject(
            "deviceSessions/${session.uid}/${identity.deviceId}",
            sessions.token(),
        )
        return json.length() == 0 || json.optLong("revokedAt") == 0L
    }
}
