package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.DeviceSession
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.DeviceSessionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SecurityUiState(
    val loading: Boolean = true,
    val devices: List<DeviceSession> = emptyList(),
    val error: String? = null,
    val busy: Boolean = false,
)

class SecurityViewModel(
    private val auth: AuthRepository,
    private val devices: DeviceSessionRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(SecurityUiState())
    val ui: StateFlow<SecurityUiState> = _ui.asStateFlow()

    init { refresh() }

    fun refresh() = action {
        _ui.update { it.copy(devices = devices.list(), loading = false) }
    }

    fun revoke(device: DeviceSession) = action {
        devices.revoke(device.id)
        if (device.current) auth.forceLocalSignOut() else _ui.update { it.copy(devices = devices.list()) }
    }

    fun revokeOthers() = action {
        auth.revokeOtherSessions()
        _ui.update { it.copy(devices = devices.list()) }
    }

    fun deleteAccount() = action { auth.deleteAccount() }

    fun clearError() = _ui.update { it.copy(error = null) }

    private fun action(block: suspend () -> Unit) = viewModelScope.launch {
        _ui.update { it.copy(busy = true, error = null) }
        runCatching { block() }
            .onFailure { error -> _ui.update { it.copy(error = error.message ?: "Операция не выполнена") } }
        _ui.update { it.copy(busy = false, loading = false) }
    }

    class Factory(
        private val auth: AuthRepository,
        private val devices: DeviceSessionRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = SecurityViewModel(auth, devices) as T
    }
}
