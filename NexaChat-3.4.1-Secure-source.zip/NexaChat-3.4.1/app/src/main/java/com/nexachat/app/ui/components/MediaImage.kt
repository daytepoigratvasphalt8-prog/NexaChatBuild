package com.nexachat.app.ui.components

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MediaImage(
    url: String,
    loadBytes: suspend (String) -> ByteArray,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
) {
    var state by remember(url) { mutableStateOf<ImageState>(ImageState.Loading) }
    LaunchedEffect(url) {
        state = ImageState.Loading
        state = runCatching {
            val bitmap = withContext(Dispatchers.Default) {
                val bytes = loadBytes(url)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalStateException("Формат изображения не поддерживается")
            }
            ImageState.Ready(bitmap.asImageBitmap())
        }.getOrElse { ImageState.Error }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        when (val value = state) {
            ImageState.Loading -> CircularProgressIndicator()
            ImageState.Error -> Icon(Icons.Rounded.BrokenImage, "Не удалось загрузить", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            is ImageState.Ready -> Image(value.bitmap, null, Modifier.fillMaxSize(), contentScale = contentScale)
        }
    }
}

private sealed interface ImageState {
    data object Loading : ImageState
    data object Error : ImageState
    data class Ready(val bitmap: androidx.compose.ui.graphics.ImageBitmap) : ImageState
}

@Composable
fun MediaImage(
    message: com.nexachat.app.core.model.Message,
    loadBytes: suspend (com.nexachat.app.core.model.Message) -> ByteArray,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
) {
    var state by remember(message.id, message.mediaIv) { mutableStateOf<ImageState>(ImageState.Loading) }
    LaunchedEffect(message.id, message.mediaIv) {
        state = ImageState.Loading
        state = runCatching {
            val bitmap = withContext(Dispatchers.Default) {
                val bytes = loadBytes(message)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalStateException("Формат изображения не поддерживается")
            }
            ImageState.Ready(bitmap.asImageBitmap())
        }.getOrElse { ImageState.Error }
    }
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
        when (val value = state) {
            ImageState.Loading -> CircularProgressIndicator()
            ImageState.Error -> Icon(Icons.Rounded.BrokenImage, "Не удалось загрузить", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            is ImageState.Ready -> Image(value.bitmap, null, Modifier.fillMaxSize(), contentScale = contentScale)
        }
    }
}
