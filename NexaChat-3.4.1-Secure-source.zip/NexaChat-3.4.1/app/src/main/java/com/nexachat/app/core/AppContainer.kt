package com.nexachat.app.core

import android.content.Context
import com.nexachat.app.BuildConfig
import com.nexachat.app.core.calls.CallRepository
import com.nexachat.app.core.database.NexaCacheDb
import com.nexachat.app.core.database.ProfileCache
import com.nexachat.app.core.media.MediaRepository
import com.nexachat.app.core.network.AccountBackendService
import com.nexachat.app.core.network.FirebaseAuthService
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.network.FirebaseStorageService
import com.nexachat.app.core.network.HttpEngine
import com.nexachat.app.core.push.PushRepository
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.repository.ContactsRepository
import com.nexachat.app.core.repository.DeviceSessionRepository
import com.nexachat.app.core.repository.LocalToolsRepository
import com.nexachat.app.core.repository.SessionManager
import com.nexachat.app.core.repository.UserRepository
import com.nexachat.app.core.security.DeviceIdentityStore
import com.nexachat.app.core.security.E2eKeyStore
import com.nexachat.app.core.security.E2eRepository
import com.nexachat.app.core.security.E2eTrustStore
import com.nexachat.app.core.security.SecureSessionStore
import com.nexachat.app.core.settings.SettingsRepository

class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    private val http = HttpEngine()
    private val authService = FirebaseAuthService(BuildConfig.FIREBASE_API_KEY, http)
    private val database = FirebaseRealtimeService(BuildConfig.DATABASE_URL, http)
    private val storage = FirebaseStorageService(BuildConfig.STORAGE_BUCKET, http)
    private val sessionStore = SecureSessionStore(appContext)
    private val profileCache = ProfileCache(appContext)
    private val identity = DeviceIdentityStore(appContext)
    private val e2eKeyStore = E2eKeyStore()
    private val e2eTrustStore = E2eTrustStore(appContext)
    private val accountBackend = AccountBackendService(BuildConfig.FUNCTIONS_BASE_URL, http)

    val sessions = SessionManager(sessionStore, authService)
    val settings = SettingsRepository(appContext)
    val users = UserRepository(database, sessions)
    val contacts = ContactsRepository(database, sessions, users)
    val media = MediaRepository(appContext, storage, sessions)
    val cache = NexaCacheDb(appContext)
    val deviceSessions = DeviceSessionRepository(database, sessions, identity)
    val push = PushRepository(database, sessions, identity)
    val e2e = E2eRepository(database, sessions, identity, e2eKeyStore, e2eTrustStore)
    val auth = AuthRepository(
        authService,
        database,
        sessions,
        profileCache,
        deviceSessions,
        push,
        e2e,
        accountBackend,
    )
    val chats = ChatRepository(database, sessions, users, cache, settings, e2e)
    val calls = CallRepository(database, sessions, users)
    val tools = LocalToolsRepository(appContext, cache)
}
