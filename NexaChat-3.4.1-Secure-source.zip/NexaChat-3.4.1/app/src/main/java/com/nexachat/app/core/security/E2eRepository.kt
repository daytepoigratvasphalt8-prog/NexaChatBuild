package com.nexachat.app.core.security

import android.util.Base64
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.DevicePublicKey
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.repository.SessionManager
import com.nexachat.app.core.util.keysList
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class E2eRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
    private val identity: DeviceIdentityStore,
    private val keyStore: E2eKeyStore,
    private val trustStore: E2eTrustStore,
) {
    suspend fun ensureCurrentKey() {
        val session = sessions.current()
        val publicKey = keyStore.publicKey(session.uid, identity.deviceId)
        trustStore.verifyOrPin(session.uid, identity.deviceId, publicKey)
        database.patch(
            "deviceKeys/${session.uid}/${identity.deviceId}",
            session.idToken,
            JSONObject()
                .put("uid", session.uid)
                .put("deviceId", identity.deviceId)
                .put("publicKey", publicKey)
                .put("algorithm", "RSA-OAEP-3072")
                .put("createdAt", System.currentTimeMillis())
                .put("revokedAt", 0),
        )
    }

    suspend fun encrypt(chat: ChatSummary, message: Message): Message {
        if (message.type.name == "SYSTEM") return message
        ensureCurrentKey()
        val recipientKeys = loadKeys(chat.memberIds.ifEmpty { setOf(message.senderId) })
        val missing = chat.memberIds.filter { uid -> recipientKeys.none { it.uid == uid && it.active } }
        require(missing.isEmpty()) {
            "Не все участники обновили NexaChat для сквозного шифрования"
        }

        val contentKey = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        val iv = ByteArray(12).also(SecureRandom()::nextBytes)
        val payload = payload(message).toString().toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, contentKey, GCMParameterSpec(128, iv))
        val ciphertext = cipher.doFinal(payload)
        val wrapped = recipientKeys.filter(DevicePublicKey::active).associate { key ->
            recipientKeyId(key.uid, key.deviceId) to keyStore.wrap(key.publicKey, contentKey.encoded)
        }
        return message.copy(
            text = "",
            attachmentUrl = "",
            thumbnailUrl = "",
            attachmentName = "",
            attachmentMime = "",
            attachmentSize = 0,
            durationMs = 0,
            waveform = emptyList(),
            replyPreview = "",
            forwardedFromName = "",
            encryptionVersion = VERSION,
            cipherText = Base64.encodeToString(ciphertext, Base64.NO_WRAP),
            cipherIv = Base64.encodeToString(iv, Base64.NO_WRAP),
            wrappedKeys = wrapped,
            senderDeviceId = identity.deviceId,
            mediaEncrypted = false,
            mediaKey = "",
            mediaIv = "",
        )
    }

    fun decrypt(message: Message): Message {
        if (message.encryptionVersion == 0 || message.cipherText.isBlank()) return message
        return runCatching {
            val uid = sessions.session.value?.uid ?: throw IllegalStateException("Требуется вход")
            val wrapped = message.wrappedKeys[recipientKeyId(uid, identity.deviceId)]
                ?: throw IllegalStateException("Сообщение отправлено до добавления этого устройства")
            val keyBytes = keyStore.unwrap(uid, identity.deviceId, wrapped)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(keyBytes, "AES"),
                GCMParameterSpec(128, Base64.decode(message.cipherIv, Base64.NO_WRAP)),
            )
            val json = JSONObject(String(cipher.doFinal(Base64.decode(message.cipherText, Base64.NO_WRAP)), Charsets.UTF_8))
            applyPayload(message, json)
        }.getOrElse {
            message.copy(text = "🔒 Не удалось расшифровать сообщение")
        }
    }

    fun deleteLocalKey(uid: String) {
        keyStore.delete(uid, identity.deviceId)
    }

    suspend fun revokeCurrentKey() {
        val session = sessions.current()
        runCatching {
            database.patch(
                "deviceKeys/${session.uid}/${identity.deviceId}",
                session.idToken,
                JSONObject().put("revokedAt", System.currentTimeMillis()),
            )
        }
    }

    private suspend fun loadKeys(memberIds: Set<String>): List<DevicePublicKey> {
        val token = sessions.token()
        return memberIds.flatMap { uid ->
            val root = database.getObject("deviceKeys/$uid", token)
            root.keysList().mapNotNull { deviceId ->
                root.optJSONObject(deviceId)?.let { json ->
                    val key = DevicePublicKey(
                        uid = uid,
                        deviceId = deviceId,
                        publicKey = json.optString("publicKey"),
                        algorithm = json.optString("algorithm", "RSA-OAEP-3072"),
                        createdAt = json.optLong("createdAt"),
                        revokedAt = json.optLong("revokedAt"),
                    )
                    if (key.active) trustStore.verifyOrPin(uid, deviceId, key.publicKey)
                    key
                }
            }
        }
    }

    private fun payload(message: Message): JSONObject = JSONObject()
        .put("text", message.text)
        .put("attachmentUrl", message.attachmentUrl)
        .put("thumbnailUrl", message.thumbnailUrl)
        .put("attachmentName", message.attachmentName)
        .put("attachmentMime", message.attachmentMime)
        .put("attachmentSize", message.attachmentSize)
        .put("durationMs", message.durationMs)
        .put("waveform", JSONArray(message.waveform))
        .put("replyPreview", message.replyPreview)
        .put("forwardedFromName", message.forwardedFromName)
        .put("mediaEncrypted", message.mediaEncrypted)
        .put("mediaKey", message.mediaKey)
        .put("mediaIv", message.mediaIv)

    private fun applyPayload(message: Message, json: JSONObject): Message = message.copy(
        text = json.optString("text"),
        attachmentUrl = json.optString("attachmentUrl"),
        thumbnailUrl = json.optString("thumbnailUrl"),
        attachmentName = json.optString("attachmentName"),
        attachmentMime = json.optString("attachmentMime"),
        attachmentSize = json.optLong("attachmentSize"),
        durationMs = json.optLong("durationMs"),
        waveform = json.optJSONArray("waveform")?.let { array -> List(array.length()) { array.optInt(it) } }.orEmpty(),
        replyPreview = json.optString("replyPreview"),
        forwardedFromName = json.optString("forwardedFromName"),
        mediaEncrypted = json.optBoolean("mediaEncrypted"),
        mediaKey = json.optString("mediaKey"),
        mediaIv = json.optString("mediaIv"),
    )

    private fun recipientKeyId(uid: String, deviceId: String) = "$uid:$deviceId"

    companion object {
        const val VERSION = 1
    }
}
