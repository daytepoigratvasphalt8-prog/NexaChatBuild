# NexaChat 3.4.1 Secure setup

The Android release and Firebase backend are deployed by the included GitHub Actions workflow. The source archive intentionally excludes generated HD wallpapers and stickers; the workflow creates them before Gradle builds the signed release.

## Required GitHub Actions secrets

Create these repository secrets before running the workflow:

| Secret | Value |
|---|---|
| `NEXA_FIREBASE_API_KEY` | Firebase Web API key |
| `NEXA_DATABASE_URL` | Full Realtime Database URL |
| `NEXA_PROJECT_ID` | Firebase project ID |
| `NEXA_STORAGE_BUCKET` | Firebase Storage bucket, usually `project-id.appspot.com` |
| `NEXA_FIREBASE_APP_ID` | Android Firebase app ID, for example `1:123:android:abc` |
| `NEXA_FIREBASE_SENDER_ID` | Firebase project number / FCM sender ID |
| `FIREBASE_SERVICE_ACCOUNT_BASE64` | Base64-encoded service-account JSON allowed to deploy Functions, Database rules and Storage rules |
| `NEXA_KEYSTORE_BASE64` | Base64-encoded Android release keystore |
| `NEXA_STORE_PASSWORD` | Keystore password |
| `NEXA_KEY_ALIAS` | Release key alias |
| `NEXA_KEY_PASSWORD` | Release key password |

For reliable WebRTC calls across mobile networks, also set:

| Secret | Value |
|---|---|
| `NEXA_TURN_URL` | TURN URL, for example `turn:turn.example.com:3478` |
| `NEXA_TURN_USERNAME` | TURN username |
| `NEXA_TURN_CREDENTIAL` | TURN credential |

`NEXA_FUNCTIONS_BASE_URL` is optional. When omitted, the app uses `https://asia-southeast1-PROJECT_ID.cloudfunctions.net`.

## One-time Firebase requirements

1. Add an Android app with package name `com.nexachat.app` in Firebase.
2. Enable Email/Password authentication, Realtime Database, Storage and Cloud Messaging.
3. Upgrade the Firebase project to the Blaze plan before deploying Cloud Functions.
4. Run the workflow with **Deploy Firebase backend** enabled.
5. Keep the same Android release keystore for every future update.

## Security design

- Each Android installation has a non-exportable RSA-3072 private key in Android Keystore.
- Every message uses a fresh AES-256-GCM key.
- That message key is wrapped separately for every active device of every participant with RSA-OAEP.
- Message text, attachment URLs, attachment names, reply previews and encrypted-media keys are inside the encrypted payload.
- Chat media bytes are encrypted before upload. Profile and group avatars stay unencrypted so they can be displayed as profile metadata.
- Previously seen public-device keys are pinned locally using a SHA-256 fingerprint; unexpected key changes are rejected.

This is an application-level E2E implementation and has not undergone an independent cryptographic audit. It should not be represented as audited or equivalent to the Signal protocol.

## Calls

WebRTC uses Firebase Realtime Database only for signaling. Audio and video flow through the WebRTC peer connection. STUN is configured by default; TURN credentials are needed for networks where a direct peer connection cannot be established.
