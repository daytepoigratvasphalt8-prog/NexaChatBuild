const { onValueCreated } = require("firebase-functions/v2/database");
const { onRequest } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { logger } = require("firebase-functions");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getDatabase } = require("firebase-admin/database");
const { getMessaging } = require("firebase-admin/messaging");
const { getStorage } = require("firebase-admin/storage");

initializeApp();
const REGION = "asia-southeast1";

async function verifiedUid(req) {
  const authorization = String(req.headers.authorization || "");
  if (!authorization.startsWith("Bearer ")) throw new Error("unauthorized");
  const decoded = await getAuth().verifyIdToken(authorization.slice(7), true);
  return decoded.uid;
}

function json(res, status, payload) {
  res.status(status).set("Cache-Control", "no-store").json(payload);
}

async function tokensForUsers(uids, excludedUid = "") {
  const db = getDatabase();
  const records = [];
  for (const uid of uids) {
    if (!uid || uid === excludedUid) continue;
    const snap = await db.ref(`pushTokens/${uid}`).get();
    const value = snap.val() || {};
    for (const [deviceId, record] of Object.entries(value)) {
      if (record && typeof record.token === "string" && record.token) {
        records.push({ uid, deviceId, token: record.token });
      }
    }
  }
  return records;
}

async function sendData(records, data, androidPriority = "high") {
  if (!records.length) return;
  const chunks = [];
  for (let i = 0; i < records.length; i += 500) chunks.push(records.slice(i, i + 500));
  for (const chunk of chunks) {
    const response = await getMessaging().sendEachForMulticast({
      tokens: chunk.map((item) => item.token),
      data: Object.fromEntries(Object.entries(data).map(([key, value]) => [key, String(value)])),
      android: { priority: androidPriority, ttl: 60 * 60 * 1000 },
    });
    const updates = {};
    response.responses.forEach((result, index) => {
      const code = result.error?.code || "";
      if (code.includes("registration-token-not-registered") || code.includes("invalid-registration-token")) {
        const item = chunk[index];
        updates[`pushTokens/${item.uid}/${item.deviceId}`] = null;
      }
    });
    if (Object.keys(updates).length) await getDatabase().ref().update(updates);
  }
}

exports.messagePush = onValueCreated(
  { ref: "/messages/{chatId}/{messageId}", region: REGION, retry: false },
  async (event) => {
    const message = event.data.val() || {};
    if (message.type === "system") return;
    const { chatId, messageId } = event.params;
    const chatSnap = await getDatabase().ref(`chats/${chatId}`).get();
    const chat = chatSnap.val() || {};
    const memberIds = Object.keys(chat.memberIds || {});
    const records = await tokensForUsers(memberIds, message.senderId);
    await sendData(records, {
      type: "message",
      chatId,
      messageId,
      senderId: message.senderId || "",
      title: message.senderName || "NexaChat",
      encrypted: "true"
    });
  },
);

exports.callPush = onValueCreated(
  { ref: "/calls/{callId}", region: REGION, retry: false },
  async (event) => {
    const call = event.data.val() || {};
    const records = await tokensForUsers([call.calleeId]);
    await sendData(records, {
      type: "call",
      callId: event.params.callId,
      chatId: call.chatId || "",
      callerId: call.callerId || "",
      callerName: call.callerName || "Входящий звонок",
      video: String(Boolean(call.video)),
    });
  },
);


exports.expireCalls = onSchedule(
  { schedule: "every 1 minutes", region: REGION, timeZone: "UTC" },
  async () => {
    const cutoff = Date.now() - 90_000;
    const snapshot = await getDatabase().ref("calls").orderByChild("createdAt").endAt(cutoff).get();
    const updates = {};
    snapshot.forEach((child) => {
      const call = child.val() || {};
      if (call.status === "ringing" || call.status === "connecting") {
        updates[`calls/${child.key}/status`] = "missed";
        updates[`calls/${child.key}/endedAt`] = Date.now();
      }
    });
    if (Object.keys(updates).length) await getDatabase().ref().update(updates);
  },
);

exports.revokeAllSessions = onRequest({ region: REGION, cors: false }, async (req, res) => {
  if (req.method !== "POST") return json(res, 405, { error: "method_not_allowed" });
  try {
    const uid = await verifiedUid(req);
    const keepDeviceId = String(req.body?.keepDeviceId || "");
    const db = getDatabase();
    const sessionsSnap = await db.ref(`deviceSessions/${uid}`).get();
    const sessions = sessionsSnap.val() || {};
    const revokedAt = Date.now();
    const updates = {};
    const revokedDevices = [];
    for (const deviceId of Object.keys(sessions)) {
      if (keepDeviceId && deviceId === keepDeviceId) continue;
      updates[`deviceSessions/${uid}/${deviceId}/revokedAt`] = revokedAt;
      revokedDevices.push(deviceId);
    }
    if (Object.keys(updates).length) await db.ref().update(updates);
    const tokenSnap = await db.ref(`pushTokens/${uid}`).get();
    const tokenMap = tokenSnap.val() || {};
    const records = revokedDevices
      .map((deviceId) => ({ uid, deviceId, token: tokenMap[deviceId]?.token }))
      .filter((item) => item.token);
    await sendData(records, { type: "session_revoked", deviceId: "" });
    for (const deviceId of revokedDevices) updates[`pushTokens/${uid}/${deviceId}`] = null;
    if (Object.keys(updates).length) await db.ref().update(updates);
    if (!keepDeviceId) await getAuth().revokeRefreshTokens(uid);
    return json(res, 200, { ok: true, revoked: revokedDevices.length });
  } catch (error) {
    logger.error("revokeAllSessions", error);
    return json(res, error.message === "unauthorized" ? 401 : 500, { error: error.message || "server_error" });
  }
});

exports.deleteAccount = onRequest({ region: REGION, cors: false, timeoutSeconds: 300 }, async (req, res) => {
  if (req.method !== "POST") return json(res, 405, { error: "method_not_allowed" });
  try {
    const uid = await verifiedUid(req);
    const db = getDatabase();
    const userSnap = await db.ref(`users/${uid}`).get();
    const user = userSnap.val() || {};
    const chatsSnap = await db.ref(`userChats/${uid}`).get();
    const chatIds = Object.keys(chatsSnap.val() || {});
    const updates = {
      [`users/${uid}`]: null,
      [`publicProfiles/${uid}`]: null,
      [`userChats/${uid}`]: null,
      [`contacts/${uid}`]: null,
      [`blocked/${uid}`]: null,
      [`pushTokens/${uid}`]: null,
      [`deviceSessions/${uid}`]: null,
      [`deviceKeys/${uid}`]: null,
      [`presence/${uid}`]: null,
    };
    if (user.usernameLower) updates[`usernames/${user.usernameLower}`] = null;

    const contactsRoot = (await db.ref("contacts").get()).val() || {};
    for (const ownerUid of Object.keys(contactsRoot)) updates[`contacts/${ownerUid}/${uid}`] = null;

    for (const chatId of chatIds) {
      updates[`chats/${chatId}/memberNames/${uid}`] = "Удалённый аккаунт";
      updates[`chats/${chatId}/memberRoles/${uid}`] = null;
      updates[`chats/${chatId}/memberIds/${uid}`] = null;
      const messageSnap = await db.ref(`messages/${chatId}`).orderByChild("senderId").equalTo(uid).get();
      messageSnap.forEach((child) => {
        updates[`messages/${chatId}/${child.key}/senderName`] = "Удалённый аккаунт";
        updates[`messages/${chatId}/${child.key}/senderUsername`] = "";
      });
    }
    await db.ref().update(updates);
    await getStorage().bucket().deleteFiles({ prefix: `users/${uid}/`, force: true }).catch((error) => logger.warn("deleteFiles", error));
    await getAuth().deleteUser(uid);
    return json(res, 200, { ok: true });
  } catch (error) {
    logger.error("deleteAccount", error);
    return json(res, error.message === "unauthorized" ? 401 : 500, { error: error.message || "server_error" });
  }
});
