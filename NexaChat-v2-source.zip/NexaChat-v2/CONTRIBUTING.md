# Contributing to NexaChat

Use a short-lived branch and keep each pull request focused. Before opening a PR, run:

```bash
python3 -m json.tool firebase/database.rules.json >/dev/null
node --check tools/migration/migrate-public-profiles.mjs
./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
```

Never commit `local.properties`, `.firebaserc`, service-account credentials, release keystores, passwords, or production database exports. Schema and rules changes must include migration/rollback notes. Messaging changes must preserve idempotent delivery and compatibility with v1.6 records.
