import { applicationDefault, initializeApp } from "firebase-admin/app";
import { getDatabase } from "firebase-admin/database";

const databaseURL = process.env.NEXA_DATABASE_URL;
if (!databaseURL) {
  throw new Error("Set NEXA_DATABASE_URL before running the migration.");
}

initializeApp({ credential: applicationDefault(), databaseURL });
const db = getDatabase();
const snapshot = await db.ref("users").once("value");
const updates = {};
let count = 0;

snapshot.forEach((child) => {
  const source = child.val() ?? {};
  const uid = child.key;
  if (!uid) return;
  const firstName = String(source.firstName ?? source.first_name ?? "");
  const lastName = String(source.lastName ?? source.last_name ?? "");
  const fallbackName = String(source.username ?? "");
  const displayNameLower = `${firstName} ${lastName}`.trim().toLowerCase() || fallbackName.toLowerCase();
  updates[`publicProfiles/${uid}`] = {
    uid,
    username: String(source.username ?? ""),
    usernameLower: String(source.usernameLower ?? source.username ?? "").toLowerCase(),
    displayNameLower,
    firstName,
    lastName,
    bio: String(source.bio ?? ""),
    avatarUrl: String(source.avatarUrl ?? ""),
    statusText: String(source.statusText ?? source.status ?? ""),
    online: Boolean(source.online),
    lastSeen: Number(source.lastSeen ?? 0),
    createdAt: Number(source.createdAt ?? 0),
    updatedAt: Number(source.updatedAt ?? Date.now()),
  };
  count += 1;
});

if (count === 0) {
  console.log("No users found; nothing to migrate.");
  process.exit(0);
}

await db.ref().update(updates);
console.log(`Migrated ${count} public profiles without copying email addresses.`);
