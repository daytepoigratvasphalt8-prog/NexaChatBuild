#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

python3 -m json.tool firebase/database.rules.json >/dev/null
node --check tools/migration/migrate-public-profiles.mjs
sh -n gradlew

python3 - <<'PY'
from pathlib import Path
from xml.etree import ElementTree

for path in Path('app/src/main').rglob('*.xml'):
    ElementTree.parse(path)

for path in Path('.').rglob('*'):
    if not path.is_file() or path.as_posix() == 'tools/verify-static.sh' or any(part in {'.git', 'build', '.gradle'} for part in path.parts):
        continue
    raw = path.read_bytes()
    if b'-----BEGIN PRIVATE KEY-----' in raw or b'"private_key"' in raw:
        raise SystemExit(f'Potential private credential in {path}')
PY

printf 'Static verification passed.\n'
