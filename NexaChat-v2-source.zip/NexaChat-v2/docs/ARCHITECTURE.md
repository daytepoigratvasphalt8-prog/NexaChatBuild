# Architecture

## Layers

### UI

Jetpack Compose screens consume immutable `StateFlow` state exposed by ViewModels. Navigation has a single authenticated graph with direct deep links to chats.

### Domain and repositories

`AuthRepository`, `UserRepository` and `ChatRepository` own app behavior. ViewModels never access Firebase or SQLite directly. `SessionManager` refreshes expired ID tokens under a mutex so concurrent requests cannot trigger a refresh storm.

### Remote data

The project intentionally uses Firebase REST rather than the Firebase Android SDK to remain compatible with the original APK configuration. JSON requests use bounded timeouts. Realtime updates use Server-Sent Events with exponential reconnect backoff. Authentication failures are retried once after a token refresh.

### Local data

`NexaCacheDb` stores chat summaries, messages and drafts in SQLite with write-ahead logging. Sending is optimistic: a local message appears immediately, receives a server ID after upload, and becomes retryable if the request fails.

### Security

Refresh tokens and ID tokens are encrypted with an AES-GCM key generated inside Android Keystore. Public searchable profiles are separated from private account records. Database rules enforce membership, ownership, message authorship and per-user preferences.

## Data model

- `/users/{uid}` — private account profile, readable and writable only by that user.
- `/publicProfiles/{uid}` — searchable profile without email.
- `/usernames/{normalized}` — unique username reservation.
- `/chats/{chatId}` — canonical chat metadata and membership.
- `/userChats/{uid}/{chatId}` — per-user chat index and preferences.
- `/messages/{chatId}/{messageId}` — message history.
- `/typing/{chatId}/{uid}` — ephemeral typing state.
- `/presence/{uid}` — online/last-seen state.

## Consistency model

Chat creation is intentionally two-phase: canonical membership is written first, then each member index is created. This lets security rules verify membership without granting root-level writes. Message creation and summary updates are separate operations; a later sync repairs stale list previews from canonical data if necessary.

## Extension points

The models already reserve message types for image, file and voice attachments. Production media delivery should use a dedicated object-storage service, signed upload URLs, malware scanning and strict MIME/size validation rather than embedding binary data in Realtime Database.
