# Release procedure

1. Update `versionCode`, `versionName` and `CHANGELOG.md`.
2. Run `./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug`.
3. Test login, registration, profile migration, direct/group chats and offline retry on physical devices.
4. Create a release keystore backup and store it outside the repository.
5. Configure the GitHub Actions secrets listed in `README.md`.
6. Push an annotated tag: `git tag -a v2.0.0 -m "NexaChat 2.0.0" && git push origin v2.0.0`.
7. Verify the GitHub Release contains a signed APK, AAB and `SHA256SUMS.txt`.
8. Verify the APK certificate and checksum before distribution.

A release build with no signing environment variables is intentionally left unsigned. CI fails earlier if release secrets are missing because the keystore restore step requires them.
