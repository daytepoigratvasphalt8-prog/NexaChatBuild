# Testing strategy

## Required on every pull request

- Pure JVM unit tests for validation and model behavior.
- Android lint for the debug variant.
- Debug APK assembly from a clean checkout.
- JSON parse validation for Firebase Rules.
- JavaScript syntax validation for migration tooling.

## Manual release matrix

Test Android 8.0, 10, 13, and the current target SDK on at least one small phone and one large screen. Cover fresh registration, legacy-user sign-in, offline cold start, queued send followed by reconnect, ambiguous network timeout without duplicate delivery, direct-chat creation races, group membership changes, profile search by username/name, local-only deletion, read receipts disabled/enabled, notification permission denial, process death, token refresh, and rules-denied operations.

## Backend checks

Use the Firebase Emulator Suite before deploying rules. Run allow/deny tests for private profile reads, public profile search, username claiming, chat membership, message authorship, reactions, read receipts, unread increments, typing, and group-owner operations. Deploy migration first, rules second, and retain a rollback export.
