# Migration from NexaChat 1.6

## Compatibility

The app keeps the original package name, Firebase project, authentication accounts and legacy field aliases (`first_name`, `last_name`, `message`, `timestamp`, `members`, `chatType`). Existing users do not need to register again.

## Before rollout

1. Export a full Realtime Database backup.
2. Preserve the original signing key. Android will only install v2 as an update when the application ID and signing certificate match v1.6.
3. Run the public-profile migration tool using a narrowly stored service-account credential.
4. Compare counts under `/users` and `/publicProfiles`.
5. Confirm that no `email` property exists under `/publicProfiles`.
6. Test authentication, search, direct chat, group creation, send/edit/delete, reaction and read receipt against Firebase Emulator Suite.
7. Deploy `firebase/database.rules.json`.

## Gradual release

Start with internal testing, then a small closed cohort. Watch Firebase denied-request logs, crash-free sessions, login completion, message send success and sync latency before expanding.

## Rollback

Rolling back the APK does not delete v2 data. The old client ignores unknown fields. If hardened rules block the legacy client, restore the previous rules temporarily while keeping the database backup. Do not delete `/publicProfiles`; it contains only derived public data and can be regenerated.

## Signing caveat

The uploaded APK alone does not reveal the private signing key. Without the original keystore, v2 must be distributed as a separate application or the old app must be uninstalled before installing a differently signed build, which removes local app data.
