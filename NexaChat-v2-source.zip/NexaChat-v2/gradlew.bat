@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "APP_HOME=%~dp0"
set "WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"
set "WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v9.4.1/gradle/wrapper/gradle-wrapper.jar"
set "WRAPPER_SHA256=55243ef57851f12b070ad14f7f5bb8302daceeebc5bce5ece5fa6edb23e1145c"

if not exist "%WRAPPER_JAR%" goto download
for /f "skip=1 tokens=*" %%H in ('certutil -hashfile "%WRAPPER_JAR%" SHA256 ^| findstr /R /V "hash CertUtil"') do if not defined ACTUAL_HASH set "ACTUAL_HASH=%%H"
set "ACTUAL_HASH=%ACTUAL_HASH: =%"
if /I "%ACTUAL_HASH%"=="%WRAPPER_SHA256%" goto run

del /Q "%WRAPPER_JAR%" 2>nul
:download
if not exist "%APP_HOME%gradle\wrapper" mkdir "%APP_HOME%gradle\wrapper"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%WRAPPER_URL%' -OutFile '%WRAPPER_JAR%.tmp'"
if errorlevel 1 exit /b 1
set "ACTUAL_HASH="
for /f "skip=1 tokens=*" %%H in ('certutil -hashfile "%WRAPPER_JAR%.tmp" SHA256 ^| findstr /R /V "hash CertUtil"') do if not defined ACTUAL_HASH set "ACTUAL_HASH=%%H"
set "ACTUAL_HASH=%ACTUAL_HASH: =%"
if /I not "%ACTUAL_HASH%"=="%WRAPPER_SHA256%" (
  del /Q "%WRAPPER_JAR%.tmp" 2>nul
  echo Gradle wrapper checksum mismatch. 1>&2
  exit /b 1
)
move /Y "%WRAPPER_JAR%.tmp" "%WRAPPER_JAR%" >nul

:run
if defined JAVA_HOME (
  set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
) else (
  set "JAVA_EXE=java.exe"
)
"%JAVA_EXE%" %JAVA_OPTS% %GRADLE_OPTS% -Dorg.gradle.appname=gradlew -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
