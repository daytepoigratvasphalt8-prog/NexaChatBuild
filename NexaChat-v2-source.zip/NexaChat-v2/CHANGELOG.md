# Changelog

## 2.0.0

- Rewritten in Kotlin and Jetpack Compose.
- Added offline-first cache, drafts and optimistic message retry.
- Added realtime streaming with reconnect and automatic token refresh.
- Added direct/group chats, reactions, replies, edit/delete and read receipts.
- Added public profile index that excludes email.
- Added encrypted session storage through Android Keystore.
- Added themes, accessibility options, profile/settings screens and deep links.
- Added background sync, notifications, hardened Firebase rules and migration tooling.
- Added automated tests, lint, debug CI and signed APK/AAB release workflow.
