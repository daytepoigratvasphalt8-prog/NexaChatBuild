# Security policy

Do not disclose vulnerabilities through a public issue. Report them privately through GitHub Security Advisories for this repository and include affected versions, reproduction steps, impact, and any suggested mitigation.

NexaChat 2.0 protects local session tokens with Android Keystore-backed AES-GCM and enforces Firebase access through Authentication and Realtime Database Rules. It does **not** claim end-to-end encryption; messages are plaintext to the Firebase project and its administrators. See `docs/SECURITY.md` for the threat model and release checklist.
