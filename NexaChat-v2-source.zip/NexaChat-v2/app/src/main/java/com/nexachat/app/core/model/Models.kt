package com.nexachat.app.core.model

enum class ChatType { DIRECT, GROUP }
enum class MessageType { TEXT, IMAGE, FILE, VOICE, SYSTEM }
enum class DeliveryState { QUEUED, SENDING, SENT, DELIVERED, READ, FAILED }
enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class Session(
    val uid: String,
    val email: String,
    val idToken: String,
    val refreshToken: String,
    val expiresAtEpochSeconds: Long,
) {
    fun isValid(nowEpochSeconds: Long = System.currentTimeMillis() / 1000): Boolean =
        idToken.isNotBlank() && expiresAtEpochSeconds > nowEpochSeconds + 90
}

sealed interface AuthState {
    data object Loading : AuthState
    data object SignedOut : AuthState
    data class SignedIn(val session: Session, val profile: UserProfile?) : AuthState
}

data class UserProfile(
    val uid: String,
    val email: String = "",
    val username: String = "",
    val usernameLower: String = username.lowercase(),
    val firstName: String = "",
    val lastName: String = "",
    val bio: String = "",
    val avatarUrl: String = "",
    val statusText: String = "",
    val online: Boolean = false,
    val lastSeen: Long = 0,
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
) {
    val displayName: String
        get() = listOf(firstName, lastName).filter(String::isNotBlank).joinToString(" ")
            .ifBlank { username.ifBlank { email.substringBefore('@') } }

    val initials: String
        get() = displayName.split(Regex("\\s+"))
            .filter(String::isNotBlank)
            .take(2)
            .joinToString("") { it.first().uppercase() }
            .ifBlank { "N" }
}

data class ChatSummary(
    val id: String,
    val type: ChatType = ChatType.DIRECT,
    val title: String = "",
    val avatarUrl: String = "",
    val memberIds: Set<String> = emptySet(),
    val memberNames: Map<String, String> = emptyMap(),
    val ownerId: String = "",
    val lastMessage: String = "",
    val lastMessageType: MessageType = MessageType.TEXT,
    val lastSenderId: String = "",
    val updatedAt: Long = 0,
    val unreadCount: Int = 0,
    val muted: Boolean = false,
    val archived: Boolean = false,
    val pinned: Boolean = false,
) {
    fun titleFor(currentUid: String): String = when {
        title.isNotBlank() -> title
        type == ChatType.DIRECT -> memberNames.entries.firstOrNull { it.key != currentUid }?.value ?: "Диалог"
        else -> "Группа"
    }
}

data class Message(
    val id: String,
    val chatId: String,
    val clientId: String,
    val senderId: String,
    val senderUsername: String = "",
    val senderName: String = "",
    val type: MessageType = MessageType.TEXT,
    val text: String = "",
    val attachmentUrl: String = "",
    val attachmentName: String = "",
    val attachmentMime: String = "",
    val attachmentSize: Long = 0,
    val replyToId: String = "",
    val replyPreview: String = "",
    val createdAt: Long,
    val editedAt: Long = 0,
    val deletedAt: Long = 0,
    val reactions: Map<String, Set<String>> = emptyMap(),
    val readBy: Set<String> = emptySet(),
    val state: DeliveryState = DeliveryState.SENT,
) {
    val isDeleted: Boolean get() = deletedAt > 0
}

data class DraftMessage(
    val text: String,
    val replyTo: Message? = null,
)

data class SearchResult(
    val profile: UserProfile,
    val isAlreadyMember: Boolean = false,
)

data class TypingState(
    val uid: String,
    val username: String,
    val updatedAt: Long,
)

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColors: Boolean = true,
    val compactChats: Boolean = false,
    val largeText: Boolean = false,
    val highContrast: Boolean = false,
    val hapticSend: Boolean = true,
    val showOnline: Boolean = true,
    val readReceipts: Boolean = true,
    val dataSaver: Boolean = false,
    val notificationsEnabled: Boolean = true,
    val groupBadges: Boolean = true,
)

data class OperationResult<out T>(
    val value: T? = null,
    val error: Throwable? = null,
) {
    val isSuccess: Boolean get() = error == null
    fun getOrThrow(): T = value ?: throw error ?: IllegalStateException("Пустой результат")

    companion object {
        fun <T> success(value: T): OperationResult<T> = OperationResult(value = value)
        fun failure(error: Throwable): OperationResult<Nothing> = OperationResult(error = error)
    }
}
