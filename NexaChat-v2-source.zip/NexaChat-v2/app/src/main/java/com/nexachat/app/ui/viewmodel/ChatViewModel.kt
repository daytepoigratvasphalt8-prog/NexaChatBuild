package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.repository.SessionManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val input: String = "",
    val replyTo: Message? = null,
    val selected: Message? = null,
    val loading: Boolean = true,
    val sending: Boolean = false,
    val error: String? = null,
)

class ChatViewModel(
    val chatId: String,
    private val repository: ChatRepository,
    sessions: SessionManager,
) : ViewModel() {
    val messages: StateFlow<List<Message>> = repository.messages(chatId)
    val typing = repository.typing(chatId)
    val currentUid: String = sessions.session.value?.uid.orEmpty()
    private val _ui = MutableStateFlow(ChatUiState(input = repository.draft(chatId)))
    val ui: StateFlow<ChatUiState> = _ui.asStateFlow()
    private var typingJob: Job? = null

    init {
        viewModelScope.launch {
            runCatching { repository.observeMessages(chatId) }
                .onSuccess { _ui.update { it.copy(loading = false) } }
                .onFailure { error -> _ui.update { it.copy(loading = false, error = error.message) } }
        }
    }

    fun setInput(value: String) {
        _ui.update { it.copy(input = value.take(8_000)) }
        repository.saveDraft(chatId, value)
        typingJob?.cancel()
        typingJob = viewModelScope.launch {
            delay(300)
            if (value.isNotBlank()) {
                runCatching { repository.setTyping(chatId, true) }
                delay(2_500)
            }
            runCatching { repository.setTyping(chatId, false) }
        }
    }

    fun setReply(message: Message?) = _ui.update { it.copy(replyTo = message, selected = null) }
    fun select(message: Message?) = _ui.update { it.copy(selected = message) }
    fun clearError() = _ui.update { it.copy(error = null) }

    fun send() {
        val text = _ui.value.input
        if (text.isBlank() || _ui.value.sending) return
        val reply = _ui.value.replyTo
        _ui.update { it.copy(input = "", replyTo = null, sending = true, error = null) }
        repository.saveDraft(chatId, "")
        viewModelScope.launch {
            runCatching { repository.sendMessage(chatId, text, reply) }
                .onFailure { error ->
                    _ui.update { it.copy(error = error.message ?: "Не удалось отправить сообщение") }
                }
            _ui.update { it.copy(sending = false) }
            runCatching { repository.setTyping(chatId, false) }
        }
    }

    fun retry(message: Message) = action { repository.retry(message) }
    fun edit(message: Message, text: String) = action { repository.editMessage(message, text) }
    fun delete(message: Message, everyone: Boolean) = action { repository.deleteMessage(message, everyone) }
    fun react(message: Message, emoji: String) = action { repository.toggleReaction(message, emoji) }
    fun markRead() = action { repository.markRead(chatId, messages.value) }

    private fun action(block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }.onFailure { error -> _ui.update { it.copy(error = error.message) } }
    }

    override fun onCleared() {
        repository.saveDraft(chatId, _ui.value.input)
        repository.stopObservingMessages(chatId)
        repository.clearTypingAsync(chatId)
        super.onCleared()
    }

    class Factory(
        private val chatId: String,
        private val repository: ChatRepository,
        private val sessions: SessionManager,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ChatViewModel(chatId, repository, sessions) as T
    }
}
