package com.nexachat.app.core.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class NetworkException(
    message: String,
    val statusCode: Int = -1,
    val responseBody: String = "",
    cause: Throwable? = null,
) : Exception(message, cause)

data class HttpResponse(
    val code: Int,
    val body: String,
    val headers: Map<String, List<String>>,
) {
    val isSuccessful: Boolean get() = code in 200..299
    fun header(name: String): String? = headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value?.firstOrNull()
}

class HttpEngine(
    private val connectTimeoutMs: Int = 15_000,
    private val readTimeoutMs: Int = 25_000,
) {
    suspend fun request(
        method: String,
        url: String,
        body: String? = null,
        headers: Map<String, String> = emptyMap(),
    ): HttpResponse = withContext(Dispatchers.IO) {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = connectTimeoutMs
            readTimeout = readTimeoutMs
            useCaches = false
            doInput = true
            instanceFollowRedirects = true
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Accept-Encoding", "identity")
            setRequestProperty("User-Agent", "NexaChat-Android/2.0")
            headers.forEach(::setRequestProperty)
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                body.toByteArray(Charsets.UTF_8).let { bytes ->
                    setFixedLengthStreamingMode(bytes.size)
                    outputStream.use { it.write(bytes) }
                }
            }
        }

        try {
            val code = connection.responseCode
            val stream = if (code >= 400) connection.errorStream else connection.inputStream
            val responseBody = stream?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader -> reader.readText() }
            }.orEmpty()
            HttpResponse(code, responseBody, connection.headerFields.filterKeys { it != null })
        } catch (error: Exception) {
            throw NetworkException("Ошибка сети", cause = error)
        } finally {
            connection.disconnect()
        }
    }
}
