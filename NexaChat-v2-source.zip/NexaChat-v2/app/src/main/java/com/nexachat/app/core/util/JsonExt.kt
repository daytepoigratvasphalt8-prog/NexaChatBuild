package com.nexachat.app.core.util

import org.json.JSONArray
import org.json.JSONObject

fun JSONObject.string(name: String): String = optString(name, "")
fun JSONObject.long(name: String): Long = when (val value = opt(name)) {
    is Number -> value.toLong()
    is String -> value.toLongOrNull() ?: 0L
    else -> 0L
}
fun JSONObject.int(name: String): Int = when (val value = opt(name)) {
    is Number -> value.toInt()
    is String -> value.toIntOrNull() ?: 0
    else -> 0
}
fun JSONObject.bool(name: String): Boolean = when (val value = opt(name)) {
    is Boolean -> value
    is Number -> value.toInt() != 0
    is String -> value.equals("true", true) || value == "1"
    else -> false
}

fun JSONObject.keysList(): List<String> = buildList {
    val iterator = keys()
    while (iterator.hasNext()) add(iterator.next())
}

fun JSONObject.stringMap(name: String): Map<String, String> =
    optJSONObject(name)?.let { objectValue ->
        objectValue.keysList().associateWith { objectValue.optString(it, "") }
    } ?: emptyMap()

fun JSONObject.stringSet(name: String): Set<String> {
    val value = opt(name)
    return when (value) {
        is JSONObject -> value.keysList().filterTo(linkedSetOf()) { value.optBoolean(it, true) }
        is JSONArray -> buildSet { for (i in 0 until value.length()) value.optString(i).takeIf(String::isNotBlank)?.let(::add) }
        else -> emptySet()
    }
}

fun Map<String, *>.toJsonObject(): JSONObject = JSONObject().also { objectValue ->
    forEach { (key, value) ->
        objectValue.put(key, when (value) {
            is Set<*> -> JSONObject().also { nested -> value.filterNotNull().forEach { nested.put(it.toString(), true) } }
            is Map<*, *> -> JSONObject(value)
            else -> value
        })
    }
}
