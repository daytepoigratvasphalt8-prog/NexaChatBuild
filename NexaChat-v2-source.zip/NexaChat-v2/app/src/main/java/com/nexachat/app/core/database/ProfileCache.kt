package com.nexachat.app.core.database

import android.content.Context
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.network.FirebaseMapper
import org.json.JSONObject

/**
 * Small local cache for the signed-in user's public profile.
 * Authentication tokens remain in [com.nexachat.app.core.security.SecureSessionStore].
 */
class ProfileCache(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun read(uid: String): UserProfile? = runCatching {
        val raw = prefs.getString(KEY_PROFILE, null) ?: return null
        val json = JSONObject(raw)
        FirebaseMapper.profile(uid, json).takeIf { it.uid == uid }
    }.getOrNull()

    @Synchronized
    fun write(profile: UserProfile) {
        prefs.edit().putString(KEY_PROFILE, FirebaseMapper.publicProfileJson(profile).toString()).apply()
    }

    @Synchronized
    fun clear() {
        prefs.edit().clear().apply()
    }

    private companion object {
        const val PREFS = "profile_cache_v2"
        const val KEY_PROFILE = "profile"
    }
}
