package com.nexachat.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navDeepLink
import com.nexachat.app.core.AppContainer
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.AuthState
import com.nexachat.app.core.network.NetworkMonitor
import com.nexachat.app.ui.components.LoadingScreen
import com.nexachat.app.ui.components.OfflineBanner
import com.nexachat.app.ui.screens.auth.AuthScreen
import com.nexachat.app.ui.screens.auth.ProfileSetupScreen
import com.nexachat.app.ui.screens.chat.ChatScreen
import com.nexachat.app.ui.screens.chats.ChatsScreen
import com.nexachat.app.ui.screens.newchat.NewConversationScreen
import com.nexachat.app.ui.screens.profile.ProfileScreen
import com.nexachat.app.ui.screens.settings.SettingsScreen
import com.nexachat.app.ui.theme.NexaChatTheme
import com.nexachat.app.ui.viewmodel.AuthViewModel
import com.nexachat.app.ui.viewmodel.ChatViewModel
import com.nexachat.app.ui.viewmodel.ChatsViewModel
import com.nexachat.app.ui.viewmodel.NewChatViewModel
import com.nexachat.app.ui.viewmodel.ProfileViewModel
import com.nexachat.app.ui.viewmodel.SettingsViewModel

private object Routes {
    const val CHATS = "chats"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"
    const val NEW_CHAT = "new_chat"
    const val CHAT = "chat/{chatId}"
    fun chat(id: String) = "chat/$id"
}

@Composable
fun NexaChatRoot(container: AppContainer) {
    val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
    val authState by container.auth.state.collectAsStateWithLifecycle()
    NexaChatTheme(settings) {
        when (val state = authState) {
            AuthState.Loading -> LoadingScreen("Запускаем NexaChat…")
            AuthState.SignedOut -> {
                val vm: AuthViewModel = viewModel(factory = AuthViewModel.Factory(container.auth))
                AuthScreen(vm)
            }
            is AuthState.SignedIn -> {
                if (state.profile != null && state.profile.username.isBlank()) {
                    val vm: AuthViewModel = viewModel(factory = AuthViewModel.Factory(container.auth))
                    ProfileSetupScreen(vm, state.session.email)
                } else {
                    MainArea(container, settings, state)
                }
            }
        }
    }
}

@Composable
private fun MainArea(container: AppContainer, settings: AppSettings, authState: AuthState.SignedIn) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val monitor = remember(context) { NetworkMonitor(context.applicationContext) }
    val online by monitor.online.collectAsStateWithLifecycle(initialValue = true)
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBottom = route in setOf(Routes.CHATS, Routes.PROFILE, Routes.SETTINGS)

    LaunchedEffect(online, authState.session.uid) {
        if (online) {
            runCatching { container.chats.retryPendingMessages() }
            runCatching { container.chats.syncChats() }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = { if (showBottom) MainNavigation(nav, route) },
    ) { outerPadding ->
        Column(Modifier.fillMaxSize().padding(outerPadding)) {
            OfflineBanner(online)
            NavHost(
                navController = nav,
                startDestination = Routes.CHATS,
                modifier = Modifier.weight(1f),
            ) {
                composable(Routes.CHATS) {
                    val vm: ChatsViewModel = viewModel(factory = ChatsViewModel.Factory(container.chats))
                    ChatsScreen(
                        viewModel = vm,
                        currentUid = authState.session.uid,
                        compact = settings.compactChats,
                        showGroupBadges = settings.groupBadges,
                        onOpenChat = { nav.navigate(Routes.chat(it)) },
                        onNewChat = { nav.navigate(Routes.NEW_CHAT) },
                    )
                }
                composable(Routes.PROFILE) {
                    val vm: ProfileViewModel = viewModel(factory = ProfileViewModel.Factory(container.auth, container.users))
                    ProfileScreen(vm)
                }
                composable(Routes.SETTINGS) {
                    val vm: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory(container.settings, container.auth, container.chats))
                    SettingsScreen(vm)
                }
                composable(Routes.NEW_CHAT) {
                    val vm: NewChatViewModel = viewModel(factory = NewChatViewModel.Factory(container.users, container.chats, container.sessions))
                    NewConversationScreen(
                        viewModel = vm,
                        onBack = nav::popBackStack,
                        onCreated = { chatId ->
                            nav.navigate(Routes.chat(chatId)) {
                                popUpTo(Routes.NEW_CHAT) { inclusive = true }
                            }
                        },
                    )
                }
                composable(
                    route = Routes.CHAT,
                    deepLinks = listOf(
                        navDeepLink { uriPattern = "nexachat://chat/{chatId}" },
                        navDeepLink { uriPattern = "https://nexachat.app/chat/{chatId}" },
                    ),
                ) { backStackEntry ->
                    val chatId = backStackEntry.arguments?.getString("chatId").orEmpty()
                    val chats by container.chats.chats.collectAsStateWithLifecycle()
                    val vm: ChatViewModel = viewModel(
                        key = "chat-$chatId",
                        factory = ChatViewModel.Factory(chatId, container.chats, container.sessions),
                    )
                    ChatScreen(
                        viewModel = vm,
                        chat = chats.firstOrNull { it.id == chatId },
                        hapticEnabled = settings.hapticSend,
                        readReceiptsEnabled = settings.readReceipts,
                        showGroupBadges = settings.groupBadges,
                        onBack = nav::popBackStack,
                    )
                }
            }
        }
    }
}

@Composable
private fun MainNavigation(nav: NavHostController, currentRoute: String?) {
    val destinations = listOf(
        Triple(Routes.CHATS, "Чаты", Icons.Rounded.Chat),
        Triple(Routes.PROFILE, "Профиль", Icons.Rounded.Person),
        Triple(Routes.SETTINGS, "Настройки", Icons.Rounded.Settings),
    )
    NavigationBar {
        destinations.forEach { (route, label, icon) ->
            NavigationBarItem(
                selected = currentRoute == route,
                onClick = {
                    nav.navigate(route) {
                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(icon, label) },
                label = { Text(label) },
            )
        }
    }
}
