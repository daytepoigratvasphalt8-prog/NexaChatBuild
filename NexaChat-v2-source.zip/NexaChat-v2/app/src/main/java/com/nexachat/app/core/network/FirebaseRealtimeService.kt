package com.nexachat.app.core.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class FirebaseRealtimeService(
    databaseUrl: String,
    private val http: HttpEngine,
) {
    private val baseUrl = databaseUrl.trimEnd('/')

    suspend fun get(path: String, token: String, query: Map<String, String> = emptyMap()): String {
        val response = http.request("GET", url(path, token, query))
        ensureSuccess(response)
        return response.body
    }

    suspend fun getObject(path: String, token: String, query: Map<String, String> = emptyMap()): JSONObject =
        get(path, token, query).takeUnless { it == "null" || it.isBlank() }?.let(::JSONObject) ?: JSONObject()

    suspend fun put(path: String, token: String, value: Any?): String {
        val body = when (value) {
            is JSONObject -> value.toString()
            is org.json.JSONArray -> value.toString()
            is String -> JSONObject.quote(value)
            is Number, is Boolean -> value.toString()
            null -> "null"
            else -> JSONObject.wrap(value).toString()
        }
        val response = http.request("PUT", url(path, token), body)
        ensureSuccess(response)
        return response.body
    }

    suspend fun patch(path: String, token: String, value: JSONObject) {
        val response = http.request("PATCH", url(path, token), value.toString())
        ensureSuccess(response)
    }

    suspend fun post(path: String, token: String, value: JSONObject): String {
        val response = http.request("POST", url(path, token), value.toString())
        ensureSuccess(response)
        return JSONObject(response.body).optString("name").ifBlank {
            throw NetworkException("Сервис не вернул идентификатор", response.code, response.body)
        }
    }

    suspend fun delete(path: String, token: String) {
        val response = http.request("DELETE", url(path, token))
        ensureSuccess(response)
    }

    suspend fun compareAndSet(
        path: String,
        token: String,
        transform: (current: String) -> String?,
        attempts: Int = 4,
    ): Boolean {
        repeat(attempts) { attempt ->
            val current = http.request(
                "GET",
                url(path, token),
                headers = mapOf("X-Firebase-ETag" to "true"),
            )
            ensureSuccess(current)
            val replacement = transform(current.body) ?: return false
            val etag = current.header("ETag") ?: "null_etag"
            val update = http.request(
                "PUT",
                url(path, token),
                replacement,
                headers = mapOf("if-match" to etag),
            )
            when (update.code) {
                in 200..299 -> return true
                412 -> delay(100L * (attempt + 1))
                else -> ensureSuccess(update)
            }
        }
        return false
    }

    /**
     * Firebase REST streaming using Server-Sent Events. Reconnects automatically with backoff.
     * Each emission contains Firebase's event payload: {"path":"/...","data":...}.
     */
    fun stream(path: String, tokenProvider: suspend () -> String): Flow<DatabaseEvent> = channelFlow {
        launch(Dispatchers.IO) {
            var backoff = 500L
            while (currentCoroutineContext().isActive) {
                var connection: HttpURLConnection? = null
                try {
                    val token = tokenProvider()
                    connection = (URL(url(path, token)).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 15_000
                        readTimeout = 70_000
                        useCaches = false
                        setRequestProperty("Accept", "text/event-stream")
                        setRequestProperty("Cache-Control", "no-cache")
                        setRequestProperty("User-Agent", "NexaChat-Android/2.0")
                    }
                    if (connection.responseCode !in 200..299) {
                        val error = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                        throw NetworkException("Не удалось подключиться к обновлениям", connection.responseCode, error)
                    }
                    backoff = 500L
                    BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { reader ->
                        var eventName = "put"
                        val data = StringBuilder()
                        while (currentCoroutineContext().isActive) {
                            val line = reader.readLine() ?: break
                            when {
                                line.startsWith("event:") -> eventName = line.substringAfter(':').trim()
                                line.startsWith("data:") -> data.append(line.substringAfter(':').trim())
                                line.isBlank() && data.isNotEmpty() -> {
                                    val raw = data.toString()
                                    data.clear()
                                    if (eventName == "put" || eventName == "patch") {
                                        val payload = runCatching { JSONObject(raw) }.getOrNull()
                                        if (payload != null) send(
                                            DatabaseEvent(
                                                event = eventName,
                                                path = payload.optString("path", "/"),
                                                data = payload.opt("data"),
                                            ),
                                        )
                                    } else if (eventName == "cancel" || eventName == "auth_revoked") {
                                        throw NetworkException("Доступ к обновлениям отозван")
                                    }
                                    eventName = "put"
                                }
                            }
                        }
                    }
                } catch (error: Throwable) {
                    if (!currentCoroutineContext().isActive) break
                    send(DatabaseEvent("error", "/", null, error))
                    delay(backoff)
                    backoff = (backoff * 2).coerceAtMost(12_000L)
                } finally {
                    connection?.disconnect()
                }
            }
        }
    }

    private fun url(path: String, token: String, query: Map<String, String> = emptyMap()): String {
        val cleanPath = path.trim('/').let { if (it.isBlank()) "" else "/$it" }
        val parameters = buildList {
            add("auth=${encode(token)}")
            query.forEach { (key, value) -> add("${encode(key)}=${encode(value)}") }
        }.joinToString("&")
        return "$baseUrl$cleanPath.json?$parameters"
    }

    private fun encode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun ensureSuccess(response: HttpResponse) {
        if (response.isSuccessful) return
        val message = when (response.code) {
            401 -> "Сессия истекла"
            403 -> "Нет доступа к данным"
            404 -> "Данные не найдены"
            429 -> "Слишком много запросов"
            in 500..599 -> "Сервис временно недоступен"
            else -> "Ошибка сервера (${response.code})"
        }
        throw NetworkException(message, response.code, response.body)
    }
}

data class DatabaseEvent(
    val event: String,
    val path: String,
    val data: Any?,
    val error: Throwable? = null,
)
