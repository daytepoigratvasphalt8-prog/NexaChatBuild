package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val register: Boolean = false,
    val email: String = "",
    val password: String = "",
    val confirmPassword: String = "",
    val username: String = "",
    val firstName: String = "",
    val lastName: String = "",
    val bio: String = "",
    val loading: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
)

class AuthViewModel(private val repository: AuthRepository) : ViewModel() {
    private val _ui = MutableStateFlow(AuthUiState())
    val ui: StateFlow<AuthUiState> = _ui.asStateFlow()

    fun setRegister(value: Boolean) = _ui.update { it.copy(register = value, error = null, notice = null) }
    fun setEmail(value: String) = _ui.update { it.copy(email = value, error = null) }
    fun setPassword(value: String) = _ui.update { it.copy(password = value, error = null) }
    fun setConfirmPassword(value: String) = _ui.update { it.copy(confirmPassword = value, error = null) }
    fun setUsername(value: String) = _ui.update { it.copy(username = value.filter { char -> char.isLetterOrDigit() || char == '_' }.take(32), error = null) }
    fun setFirstName(value: String) = _ui.update { it.copy(firstName = value.take(48), error = null) }
    fun setLastName(value: String) = _ui.update { it.copy(lastName = value.take(48), error = null) }
    fun setBio(value: String) = _ui.update { it.copy(bio = value.take(160), error = null) }
    fun clearError() = _ui.update { it.copy(error = null) }

    fun submit() {
        val state = _ui.value
        if (state.register && state.password != state.confirmPassword) {
            _ui.update { it.copy(error = "Пароли не совпадают") }
            return
        }
        runAction {
            if (state.register) repository.signUp(state.email, state.password)
            else repository.signIn(state.email, state.password)
        }
    }

    fun completeProfile() = runAction {
        val state = _ui.value
        repository.completeProfile(state.username, state.firstName, state.lastName, state.bio)
    }

    fun resetPassword() {
        val email = _ui.value.email
        runAction(success = "Письмо для сброса пароля отправлено") { repository.resetPassword(email) }
    }

    private fun runAction(success: String? = null, action: suspend () -> Unit) {
        if (_ui.value.loading) return
        viewModelScope.launch {
            _ui.update { it.copy(loading = true, error = null, notice = null) }
            runCatching { action() }
                .onSuccess { _ui.update { it.copy(loading = false, notice = success) } }
                .onFailure { error -> _ui.update { it.copy(loading = false, error = error.message ?: "Неизвестная ошибка") } }
        }
    }

    class Factory(private val repository: AuthRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = AuthViewModel(repository) as T
    }
}
