package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.AuthState
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.UserRepository
import com.nexachat.app.core.util.Validation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUiState(
    val profile: UserProfile? = null,
    val firstName: String = "",
    val lastName: String = "",
    val bio: String = "",
    val statusText: String = "",
    val editing: Boolean = false,
    val saving: Boolean = false,
    val error: String? = null,
    val saved: Boolean = false,
)

class ProfileViewModel(
    private val auth: AuthRepository,
    private val users: UserRepository,
) : ViewModel() {
    private val _ui = MutableStateFlow(ProfileUiState())
    val ui: StateFlow<ProfileUiState> = _ui.asStateFlow()

    init {
        val profile = (auth.state.value as? AuthState.SignedIn)?.profile
        bind(profile)
        viewModelScope.launch {
            runCatching { auth.refreshProfile() }.onSuccess(::bind)
        }
    }

    fun startEdit() = _ui.update { it.copy(editing = true, saved = false, error = null) }
    fun cancelEdit() = bind(_ui.value.profile)
    fun setFirstName(value: String) = _ui.update { it.copy(firstName = value.take(48), error = null) }
    fun setLastName(value: String) = _ui.update { it.copy(lastName = value.take(48), error = null) }
    fun setBio(value: String) = _ui.update { it.copy(bio = value.take(160), error = null) }
    fun setStatus(value: String) = _ui.update { it.copy(statusText = value.take(70), error = null) }
    fun clearError() = _ui.update { it.copy(error = null) }

    fun save() {
        val state = _ui.value
        val profile = state.profile ?: return
        Validation.displayName(state.firstName, state.lastName)?.let { error ->
            _ui.update { it.copy(error = error) }
            return
        }
        Validation.bio(state.bio)?.let { error ->
            _ui.update { it.copy(error = error) }
            return
        }
        viewModelScope.launch {
            _ui.update { it.copy(saving = true, error = null, saved = false) }
            runCatching {
                users.update(
                    profile.copy(
                        firstName = state.firstName.trim(),
                        lastName = state.lastName.trim(),
                        bio = state.bio.trim(),
                        statusText = state.statusText.trim(),
                    ),
                )
            }.onSuccess { updated ->
                _ui.update {
                    it.copy(profile = updated, saving = false, editing = false, saved = true)
                }
                auth.refreshProfile()
            }.onFailure { error -> _ui.update { it.copy(saving = false, error = error.message) } }
        }
    }

    private fun bind(profile: UserProfile?) {
        _ui.value = ProfileUiState(
            profile = profile,
            firstName = profile?.firstName.orEmpty(),
            lastName = profile?.lastName.orEmpty(),
            bio = profile?.bio.orEmpty(),
            statusText = profile?.statusText.orEmpty(),
        )
    }

    class Factory(
        private val auth: AuthRepository,
        private val users: UserRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = ProfileViewModel(auth, users) as T
    }
}
