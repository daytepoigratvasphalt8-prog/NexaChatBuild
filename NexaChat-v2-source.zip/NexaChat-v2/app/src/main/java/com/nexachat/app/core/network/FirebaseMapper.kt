package com.nexachat.app.core.network

import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.model.DeliveryState
import com.nexachat.app.core.model.Message
import com.nexachat.app.core.model.MessageType
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.util.bool
import com.nexachat.app.core.util.int
import com.nexachat.app.core.util.keysList
import com.nexachat.app.core.util.long
import com.nexachat.app.core.util.string
import com.nexachat.app.core.util.stringMap
import com.nexachat.app.core.util.stringSet
import org.json.JSONObject

object FirebaseMapper {
    fun profile(uid: String, json: JSONObject): UserProfile = UserProfile(
        uid = uid.ifBlank { json.string("uid") },
        email = json.string("email"),
        username = json.string("username"),
        usernameLower = json.string("usernameLower").ifBlank { json.string("username").lowercase() },
        firstName = json.string("firstName").ifBlank { json.string("first_name") },
        lastName = json.string("lastName").ifBlank { json.string("last_name") },
        bio = json.string("bio"),
        avatarUrl = json.string("avatarUrl"),
        statusText = json.string("statusText").ifBlank { json.string("status") },
        online = json.bool("online"),
        lastSeen = json.long("lastSeen"),
        createdAt = json.long("createdAt"),
        updatedAt = json.long("updatedAt"),
    )

    fun chat(id: String, json: JSONObject): ChatSummary {
        val memberIds = when {
            json.has("memberIds") -> json.stringSet("memberIds")
            json.has("members") -> json.stringSet("members")
            else -> buildSet {
                json.string("userA").takeIf(String::isNotBlank)?.let(::add)
                json.string("userB").takeIf(String::isNotBlank)?.let(::add)
            }
        }
        val names = json.stringMap("memberNames").ifEmpty {
            buildMap {
                json.string("userA").takeIf(String::isNotBlank)?.let { put(it, json.string("usernameA")) }
                json.string("userB").takeIf(String::isNotBlank)?.let { put(it, json.string("usernameB")) }
            }
        }
        return ChatSummary(
            id = id,
            type = if (json.string("type").equals("group", true) || json.string("chatType").equals("group", true)) ChatType.GROUP else ChatType.DIRECT,
            title = json.string("title"),
            avatarUrl = json.string("avatarUrl"),
            memberIds = memberIds,
            memberNames = names,
            ownerId = json.string("ownerId"),
            lastMessage = json.string("lastMessage"),
            lastMessageType = enumValueOrDefault(json.string("lastMessageType"), MessageType.TEXT),
            lastSenderId = json.string("lastSenderId"),
            updatedAt = json.long("updatedAt"),
            unreadCount = json.int("unreadCount"),
            muted = json.bool("muted"),
            archived = json.bool("archived"),
            pinned = json.bool("pinned"),
        )
    }

    fun message(id: String, chatId: String, json: JSONObject): Message {
        val reactions = json.optJSONObject("reactions")?.let { reactionObject ->
            reactionObject.keysList().associateWith { emoji -> reactionObject.stringSet(emoji) }
        }.orEmpty()
        return Message(
            id = id,
            chatId = chatId,
            clientId = json.string("clientId").ifBlank { id },
            senderId = json.string("senderId"),
            senderUsername = json.string("senderUsername"),
            senderName = json.string("senderName"),
            type = enumValueOrDefault(json.string("type"), MessageType.TEXT),
            text = json.string("text").ifBlank { json.string("message") },
            attachmentUrl = json.string("attachmentUrl"),
            attachmentName = json.string("attachmentName"),
            attachmentMime = json.string("attachmentMime"),
            attachmentSize = json.long("attachmentSize"),
            replyToId = json.string("replyToId"),
            replyPreview = json.string("replyPreview"),
            createdAt = json.long("createdAt").takeIf { it > 0 } ?: json.long("timestamp"),
            editedAt = json.long("editedAt"),
            deletedAt = json.long("deletedAt"),
            reactions = reactions,
            readBy = json.stringSet("readBy"),
            state = DeliveryState.SENT,
        )
    }

    fun profileJson(profile: UserProfile): JSONObject = JSONObject()
        .put("uid", profile.uid)
        .put("email", profile.email)
        .put("username", profile.username)
        .put("usernameLower", profile.usernameLower)
        .put("displayNameLower", searchableName(profile))
        .put("firstName", profile.firstName)
        .put("lastName", profile.lastName)
        .put("bio", profile.bio)
        .put("avatarUrl", profile.avatarUrl)
        .put("statusText", profile.statusText)
        .put("online", profile.online)
        .put("lastSeen", profile.lastSeen)
        .put("createdAt", profile.createdAt)
        .put("updatedAt", profile.updatedAt)

    /** Public, searchable profile. Deliberately excludes email and other private account data. */
    fun publicProfileJson(profile: UserProfile): JSONObject = JSONObject()
        .put("uid", profile.uid)
        .put("username", profile.username)
        .put("usernameLower", profile.usernameLower)
        .put("displayNameLower", searchableName(profile))
        .put("firstName", profile.firstName)
        .put("lastName", profile.lastName)
        .put("bio", profile.bio)
        .put("avatarUrl", profile.avatarUrl)
        .put("statusText", profile.statusText)
        .put("online", profile.online)
        .put("lastSeen", profile.lastSeen)
        .put("createdAt", profile.createdAt)
        .put("updatedAt", profile.updatedAt)

    fun messageJson(message: Message): JSONObject = JSONObject()
        .put("clientId", message.clientId)
        .put("senderId", message.senderId)
        .put("senderUsername", message.senderUsername)
        .put("senderName", message.senderName)
        .put("type", message.type.name.lowercase())
        .put("text", message.text)
        .put("message", message.text) // legacy clients
        .put("attachmentUrl", message.attachmentUrl)
        .put("attachmentName", message.attachmentName)
        .put("attachmentMime", message.attachmentMime)
        .put("attachmentSize", message.attachmentSize)
        .put("replyToId", message.replyToId)
        .put("replyPreview", message.replyPreview)
        .put("createdAt", message.createdAt)
        .put("timestamp", message.createdAt) // legacy clients
        .put("editedAt", message.editedAt)
        .put("deletedAt", message.deletedAt)
        .put("readBy", JSONObject().also { objectValue -> message.readBy.forEach { objectValue.put(it, true) } })

    private fun searchableName(profile: UserProfile): String =
        listOf(profile.firstName, profile.lastName)
            .filter(String::isNotBlank)
            .joinToString(" ")
            .ifBlank { profile.username }
            .lowercase()

    private inline fun <reified T : Enum<T>> enumValueOrDefault(value: String, default: T): T =
        enumValues<T>().firstOrNull { it.name.equals(value, true) } ?: default
}
