package com.nexachat.app.core.util

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object TimeFormat {
    private val time = DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault())
    private val date = DateTimeFormatter.ofPattern("d MMM", Locale.getDefault())
    private val fullDate = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())

    fun message(epochMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        if (epochMillis <= 0) return ""
        val zone = ZoneId.systemDefault()
        val value = Instant.ofEpochMilli(epochMillis).atZone(zone)
        val today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
        return when (value.toLocalDate()) {
            today -> time.format(value)
            today.minusDays(1) -> "вчера"
            else -> if (value.year == today.year) date.format(value) else fullDate.format(value)
        }
    }

    fun presence(epochMillis: Long, online: Boolean): String {
        if (online) return "В сети"
        if (epochMillis <= 0) return "Не в сети"
        val zone = ZoneId.systemDefault()
        val value = Instant.ofEpochMilli(epochMillis).atZone(zone)
        val today = LocalDate.now(zone)
        return when (value.toLocalDate()) {
            today -> "был(а) сегодня в ${time.format(value)}"
            today.minusDays(1) -> "был(а) вчера в ${time.format(value)}"
            else -> "был(а) ${date.format(value)}"
        }
    }
}
