package com.nexachat.app.ui.screens.auth

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.NexaLogo
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.theme.NexaCyan
import com.nexachat.app.ui.theme.NexaPink
import com.nexachat.app.ui.theme.NexaPurple
import com.nexachat.app.ui.viewmodel.AuthViewModel

@Composable
fun AuthScreen(viewModel: AuthViewModel) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    var passwordVisible by remember { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    listOf(
                        NexaPurple.copy(alpha = 0.18f),
                        MaterialTheme.colorScheme.background,
                    ),
                    radius = 1200f,
                ),
            )
            .statusBarsPadding()
            .imePadding(),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(20.dp))
            NexaLogo()
            Spacer(Modifier.height(14.dp))
            Text(
                if (state.register) "Создайте пространство для общения" else "С возвращением",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                if (state.register) "Быстрая регистрация по электронной почте" else "Войдите по электронной почте",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(30.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                tonalElevation = 3.dp,
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(4.dp),
                    ) {
                        ModeTab("Вход", !state.register, Modifier.weight(1f)) { viewModel.setRegister(false) }
                        ModeTab("Регистрация", state.register, Modifier.weight(1f)) { viewModel.setRegister(true) }
                    }

                    OutlinedTextField(
                        value = state.email,
                        onValueChange = viewModel::setEmail,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Электронная почта") },
                        leadingIcon = { Icon(Icons.Rounded.AlternateEmail, null) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                        shape = RoundedCornerShape(16.dp),
                    )
                    OutlinedTextField(
                        value = state.password,
                        onValueChange = viewModel::setPassword,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Пароль") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Показать пароль")
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = if (state.register) ImeAction.Next else ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                        shape = RoundedCornerShape(16.dp),
                    )
                    AnimatedContent(state.register, label = "confirmPassword") { register ->
                        if (register) {
                            OutlinedTextField(
                                value = state.confirmPassword,
                                onValueChange = viewModel::setConfirmPassword,
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Повторите пароль") },
                                leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                                singleLine = true,
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = { viewModel.submit() }),
                                shape = RoundedCornerShape(16.dp),
                            )
                        } else Spacer(Modifier.height(0.dp))
                    }
                    ErrorBanner(state.error, viewModel::clearError)
                    if (!state.notice.isNullOrBlank()) {
                        Text(state.notice.orEmpty(), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium)
                    }
                    NexaPrimaryButton(
                        text = if (state.register) "Создать аккаунт" else "Войти",
                        onClick = viewModel::submit,
                        loading = state.loading,
                    )
                    if (!state.register) {
                        Text(
                            "Забыли пароль?",
                            modifier = Modifier.align(Alignment.CenterHorizontally).clickable(onClick = viewModel::resetPassword).padding(8.dp),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text(
                "Продолжая, вы соглашаетесь с правилами сервиса и политикой конфиденциальности.",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun ProfileSetupScreen(viewModel: AuthViewModel, email: String) {
    val state by viewModel.ui.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        NexaLogo(compact = true)
        Spacer(Modifier.height(10.dp))
        Text("Завершите профиль", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Username нужен для поиска. Имя будет видно в чатах.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Text(email, Modifier.padding(13.dp), style = MaterialTheme.typography.bodyMedium)
        }
        OutlinedTextField(
            value = state.username,
            onValueChange = viewModel::setUsername,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Username") },
            prefix = { Text("@") },
            leadingIcon = { Icon(Icons.Rounded.Badge, null) },
            supportingText = { Text("5–32 символа: A–Z, 0–9 и _") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
        )
        OutlinedTextField(
            value = state.firstName,
            onValueChange = viewModel::setFirstName,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Имя") },
            leadingIcon = { Icon(Icons.Rounded.Person, null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
        )
        OutlinedTextField(
            value = state.lastName,
            onValueChange = viewModel::setLastName,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Фамилия") },
            leadingIcon = { Icon(Icons.Rounded.Person, null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
        )
        OutlinedTextField(
            value = state.bio,
            onValueChange = viewModel::setBio,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("О себе") },
            minLines = 3,
            supportingText = { Text("${state.bio.length}/160") },
            shape = RoundedCornerShape(16.dp),
        )
        ErrorBanner(state.error, viewModel::clearError)
        NexaPrimaryButton("Сохранить и продолжить", viewModel::completeProfile, loading = state.loading)
    }
}

@Composable
private fun ModeTab(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) MaterialTheme.colorScheme.surface else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
