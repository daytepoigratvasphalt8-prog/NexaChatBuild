package com.nexachat.app.ui.theme

import androidx.compose.ui.graphics.Color

val NexaPurple = Color(0xFF7C5CFF)
val NexaPurpleLight = Color(0xFFA894FF)
val NexaCyan = Color(0xFF00D7FF)
val NexaPink = Color(0xFFFF4FD8)
val NexaGreen = Color(0xFF35E39A)
val NexaRed = Color(0xFFFF5D73)
val NexaAmber = Color(0xFFFFC857)

val DarkBackground = Color(0xFF080A12)
val DarkSurface = Color(0xFF10131F)
val DarkSurfaceHigh = Color(0xFF171B2A)
val DarkOutline = Color(0xFF30364A)
val DarkText = Color(0xFFF4F5FF)
val DarkMuted = Color(0xFF9BA3BE)

val LightBackground = Color(0xFFF7F7FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFEEEFFA)
val LightOutline = Color(0xFFD8DAE8)
val LightText = Color(0xFF141622)
val LightMuted = Color(0xFF666C82)
