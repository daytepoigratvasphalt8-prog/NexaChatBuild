package com.nexachat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.nexachat.app.ui.NexaChatRoot
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val container get() = (application as NexaChatApp).container

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NexaChatRoot(container = container) }
    }

    override fun onStart() {
        super.onStart()
        lifecycleScope.launch {
            val showOnline = container.settings.settings.first().showOnline
            runCatching { container.users.setPresence(online = true, showOnline = showOnline) }
        }
    }

    override fun onStop() {
        lifecycleScope.launch {
            val showOnline = container.settings.settings.first().showOnline
            runCatching { container.users.setPresence(online = false, showOnline = showOnline) }
        }
        super.onStop()
    }
}
