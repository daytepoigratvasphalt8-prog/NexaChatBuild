package com.nexachat.app.core.repository

import com.nexachat.app.core.model.SearchResult
import com.nexachat.app.core.model.UserProfile
import com.nexachat.app.core.network.FirebaseMapper
import com.nexachat.app.core.network.FirebaseRealtimeService
import com.nexachat.app.core.util.keysList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale

class UserRepository(
    private val database: FirebaseRealtimeService,
    private val sessions: SessionManager,
) {
    suspend fun get(uid: String): UserProfile? = withAuthRetry { token ->
        val ownUid = sessions.current().uid
        val path = if (uid == ownUid) "users/$uid" else "publicProfiles/$uid"
        database.getObject(path, token).takeIf { it.length() > 0 }?.let { FirebaseMapper.profile(uid, it) }
    }

    suspend fun update(profile: UserProfile): UserProfile = withAuthRetry { token ->
        val updated = profile.copy(updatedAt = System.currentTimeMillis())
        require(updated.uid == sessions.current().uid) { "Можно изменять только свой профиль" }
        database.patch("users/${profile.uid}", token, FirebaseMapper.profileJson(updated))
        // Keep profile editing compatible while publicProfiles is being rolled out.
        runCatching { database.patch("publicProfiles/${profile.uid}", token, FirebaseMapper.publicProfileJson(updated)) }
        updated
    }

    suspend fun claimUsername(uid: String, username: String): Boolean {
        require(uid == sessions.current().uid) { "Можно изменять только свой юзернейм" }
        val normalized = username.lowercase(Locale.ROOT)
        return withAuthRetry { token ->
            val claimed = database.compareAndSet("usernames/$normalized", token, transform = { current ->
                when {
                    current == "null" -> JSONObject.quote(uid)
                    current.trim('"') == uid -> JSONObject.quote(uid)
                    else -> null
                }
            })
            if (claimed) {
                val now = System.currentTimeMillis()
                val patch = JSONObject()
                    .put("username", username)
                    .put("usernameLower", normalized)
                    .put("updatedAt", now)
                database.patch("users/$uid", token, patch)
                runCatching { database.patch("publicProfiles/$uid", token, patch) }
            }
            claimed
        }
    }

    suspend fun search(query: String, limit: Int = 30): List<SearchResult> = withContext(Dispatchers.IO) {
        val normalized = query.trim().lowercase(Locale.ROOT)
        if (normalized.length < 2) return@withContext emptyList()
        withAuthRetry { token ->
            val byUsername = queryProfiles(token, "usernameLower", normalized, limit)
            val byName = queryProfiles(token, "displayNameLower", normalized, limit)
            (byUsername + byName)
                .distinctBy { it.profile.uid }
                .sortedWith(
                    compareBy<SearchResult> {
                        when {
                            it.profile.usernameLower.startsWith(normalized) -> 0
                            it.profile.displayName.lowercase(Locale.ROOT).startsWith(normalized) -> 1
                            else -> 2
                        }
                    }.thenBy { it.profile.displayName.lowercase(Locale.ROOT) },
                )
                .take(limit)
        }
    }

    private suspend fun queryProfiles(token: String, field: String, normalized: String, limit: Int): List<SearchResult> {
        val end = normalized + "\uf8ff"
        val result = database.getObject(
            "publicProfiles",
            token,
            mapOf(
                "orderBy" to "\"$field\"",
                "startAt" to "\"$normalized\"",
                "endAt" to "\"$end\"",
                "limitToFirst" to limit.toString(),
            ),
        )
        return result.keysList().mapNotNull { uid ->
            result.optJSONObject(uid)?.let { SearchResult(FirebaseMapper.profile(uid, it)) }
        }
    }

    suspend fun setPresence(online: Boolean, showOnline: Boolean) {
        val session = sessions.session.value ?: return
        withAuthRetry { token ->
            val now = System.currentTimeMillis()
            val presencePatch = JSONObject()
                .put("online", online && showOnline)
                .put("lastSeen", now)
                .put("updatedAt", now)
            database.patch("users/${session.uid}", token, presencePatch)
            runCatching { database.patch("publicProfiles/${session.uid}", token, presencePatch) }
            database.put(
                "presence/${session.uid}",
                token,
                JSONObject().put("online", online && showOnline).put("lastSeen", now),
            )
        }
    }

    private suspend fun <T> withAuthRetry(block: suspend (String) -> T): T = try {
        block(sessions.token())
    } catch (error: com.nexachat.app.core.network.NetworkException) {
        if (error.statusCode == 401) block(sessions.token(forceRefresh = true)) else throw error
    }
}
