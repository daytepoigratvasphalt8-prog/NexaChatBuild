package com.nexachat.app.ui.screens.settings

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.ColorLens
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.DataSaverOn
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Logout
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.BuildConfig
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var signOutDialog by remember { mutableStateOf(false) }
    var clearDialog by remember { mutableStateOf(false) }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        viewModel.setNotifications(granted)
    }

    Scaffold(topBar = { NexaTopBar("Настройки") }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
        ) {
            SectionTitle("Оформление")
            SettingsCard {
                ThemeRow(settings.themeMode, viewModel::setTheme)
                SettingSwitch(Icons.Rounded.ColorLens, "Динамические цвета", "Использовать цвета системы Android", settings.dynamicColors, viewModel::setDynamicColors)
                SettingSwitch(Icons.Rounded.Smartphone, "Компактный список", "Больше чатов помещается на экране", settings.compactChats, viewModel::setCompactChats)
            }

            SectionTitle("Доступность")
            SettingsCard {
                SettingSwitch(Icons.Rounded.AccessibilityNew, "Крупный текст", "Увеличить основные размеры шрифта", settings.largeText, viewModel::setLargeText)
                SettingSwitch(Icons.Rounded.Contrast, "Высокий контраст", "Усилить визуальное разделение элементов", settings.highContrast, viewModel::setHighContrast)
                SettingSwitch(Icons.Rounded.Vibration, "Вибрация при отправке", "Тактильное подтверждение действий", settings.hapticSend, viewModel::setHaptic)
            }

            SectionTitle("Приватность и данные")
            SettingsCard {
                SettingSwitch(Icons.Rounded.Public, "Показывать статус онлайн", "Разрешить другим видеть присутствие", settings.showOnline, viewModel::setShowOnline)
                SettingSwitch(Icons.Rounded.ReceiptLong, "Отчёты о прочтении", "Показывать двойную галочку", settings.readReceipts, viewModel::setReadReceipts)
                SettingSwitch(Icons.Rounded.DataSaverOn, "Экономия трафика", "Меньше фоновых загрузок", settings.dataSaver, viewModel::setDataSaver)
            }

            SectionTitle("Уведомления")
            SettingsCard {
                SettingSwitch(
                    Icons.Rounded.Notifications,
                    "Новые сообщения",
                    "Системные push-уведомления",
                    settings.notificationsEnabled,
                ) { enabled ->
                    if (enabled && Build.VERSION.SDK_INT >= 33) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else viewModel.setNotifications(enabled)
                }
                SettingSwitch(Icons.Rounded.Groups, "Значки групп", "Показывать тип и количество участников", settings.groupBadges, viewModel::setGroupBadges)
            }

            SectionTitle("Хранилище и аккаунт")
            SettingsCard {
                ActionRow(Icons.Rounded.CleaningServices, "Очистить локальный кэш", "Переписки останутся на сервере") { clearDialog = true }
                HorizontalDivider(Modifier.padding(start = 64.dp))
                ActionRow(Icons.Rounded.Logout, "Выйти из аккаунта", "Локальные данные будут удалены", destructive = true) { signOutDialog = true }
            }

            Text(
                "NexaChat ${BuildConfig.VERSION_NAME} • ${BuildConfig.FIREBASE_PROJECT_ID}",
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (signOutDialog) {
        AlertDialog(
            onDismissRequest = { signOutDialog = false },
            title = { Text("Выйти из аккаунта?") },
            text = { Text("Сессия и локальный кэш будут удалены с устройства.") },
            confirmButton = { TextButton(onClick = { signOutDialog = false; viewModel.signOut() }) { Text("Выйти", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { signOutDialog = false }) { Text("Отмена") } },
        )
    }
    if (clearDialog) {
        AlertDialog(
            onDismissRequest = { clearDialog = false },
            title = { Text("Очистить кэш?") },
            text = { Text("Сообщения заново загрузятся с сервера при открытии чатов.") },
            confirmButton = { TextButton(onClick = { clearDialog = false; viewModel.clearCache() }) { Text("Очистить") } },
            dismissButton = { TextButton(onClick = { clearDialog = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, Modifier.padding(start = 20.dp, top = 22.dp, bottom = 8.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    ) { Column { content() } }
}

@Composable
private fun ThemeRow(selected: ThemeMode, onSelect: (ThemeMode) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("Тема", fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            ThemeOption("Система", Icons.Rounded.Smartphone, ThemeMode.SYSTEM, selected, onSelect)
            ThemeOption("Светлая", Icons.Rounded.LightMode, ThemeMode.LIGHT, selected, onSelect)
            ThemeOption("Тёмная", Icons.Rounded.DarkMode, ThemeMode.DARK, selected, onSelect)
        }
    }
}

@Composable
private fun ThemeOption(label: String, icon: ImageVector, value: ThemeMode, selected: ThemeMode, onSelect: (ThemeMode) -> Unit) {
    Row(Modifier.clickable { onSelect(value) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected == value, onClick = { onSelect(value) })
        Icon(icon, null, Modifier.size(18.dp))
        Spacer(Modifier.size(5.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun SettingSwitch(icon: ImageVector, title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChecked(!checked) }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun ActionRow(icon: ImageVector, title: String, subtitle: String, destructive: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(24.dp), tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        Spacer(Modifier.size(14.dp))
        Column {
            Text(title, fontWeight = FontWeight.Medium, color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
