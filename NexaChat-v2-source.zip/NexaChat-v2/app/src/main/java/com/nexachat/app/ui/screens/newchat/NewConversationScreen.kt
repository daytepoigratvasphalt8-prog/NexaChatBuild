package com.nexachat.app.ui.screens.newchat

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.GroupAdd
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.SearchResult
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaPrimaryButton
import com.nexachat.app.ui.components.NexaTopBar
import com.nexachat.app.ui.viewmodel.NewChatViewModel

@Composable
fun NewConversationScreen(
    viewModel: NewChatViewModel,
    onBack: () -> Unit,
    onCreated: (String) -> Unit,
) {
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    LaunchedEffect(ui.created?.id) {
        ui.created?.let { chat ->
            viewModel.clearCreated()
            onCreated(chat.id)
        }
    }

    Scaffold(
        topBar = { NexaTopBar(if (ui.groupMode) "Новая группа" else "Новый диалог", onBack = onBack) },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ModeCard(
                    title = "Личный чат",
                    selected = !ui.groupMode,
                    icon = Icons.Rounded.PersonAdd,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.setGroupMode(false) },
                )
                ModeCard(
                    title = "Группа",
                    selected = ui.groupMode,
                    icon = Icons.Rounded.GroupAdd,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.setGroupMode(true) },
                )
            }

            if (ui.groupMode) {
                OutlinedTextField(
                    value = ui.groupTitle,
                    onValueChange = viewModel::setGroupTitle,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    label = { Text("Название группы") },
                    supportingText = { Text("${ui.groupTitle.length}/64") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                )
                if (ui.selected.isNotEmpty()) {
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                    ) {
                        items(ui.selected, key = { it.uid }) { profile ->
                            AssistChip(
                                onClick = { viewModel.toggle(profile) },
                                label = { Text(profile.displayName, maxLines = 1) },
                                leadingIcon = { Icon(Icons.Rounded.CheckCircle, null, Modifier.size(16.dp)) },
                            )
                        }
                    }
                }
            }

            OutlinedTextField(
                value = ui.query,
                onValueChange = viewModel::setQuery,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                placeholder = { Text("Username или имя") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = { if (ui.searching) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
            )
            ErrorBanner(ui.error, viewModel::clearError)

            when {
                ui.query.trim().length < 2 -> EmptyState(
                    title = "Найдите собеседника",
                    message = "Введите минимум два символа username или имени.",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Search,
                )
                !ui.searching && ui.results.isEmpty() -> EmptyState(
                    title = "Пользователь не найден",
                    message = "Проверьте написание username и попробуйте ещё раз.",
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Search,
                )
                else -> LazyColumn(Modifier.weight(1f)) {
                    items(ui.results, key = { it.profile.uid }) { result ->
                        UserResultRow(result, ui.selected.any { it.uid == result.profile.uid }) {
                            viewModel.toggle(result.profile)
                        }
                    }
                }
            }

            if (ui.groupMode) {
                NexaPrimaryButton(
                    text = "Создать группу (${ui.selected.size + 1})",
                    onClick = viewModel::createGroup,
                    modifier = Modifier.padding(16.dp),
                    enabled = ui.groupTitle.isNotBlank() && ui.selected.isNotEmpty(),
                    loading = ui.creating,
                    icon = Icons.Rounded.GroupAdd,
                )
            } else if (ui.creating) {
                Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

@Composable
private fun ModeCard(
    title: String,
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.size(8.dp))
            Text(title, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
        }
    }
}

@Composable
private fun UserResultRow(result: SearchResult, selected: Boolean, onClick: () -> Unit) {
    val profile = result.profile
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NexaAvatar(profile.displayName, online = profile.online)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(profile.displayName, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("@${profile.username}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (profile.statusText.isNotBlank()) Text(profile.statusText, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
        if (selected) Icon(Icons.Rounded.CheckCircle, "Выбран", tint = MaterialTheme.colorScheme.primary)
    }
}
