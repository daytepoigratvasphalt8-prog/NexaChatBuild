package com.nexachat.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.ThemeMode

private val DarkColors = darkColorScheme(
    primary = NexaPurpleLight,
    onPrimary = DarkBackground,
    secondary = NexaCyan,
    tertiary = NexaPink,
    background = DarkBackground,
    onBackground = DarkText,
    surface = DarkSurface,
    onSurface = DarkText,
    surfaceVariant = DarkSurfaceHigh,
    onSurfaceVariant = DarkMuted,
    outline = DarkOutline,
    error = NexaRed,
)

private val LightColors = lightColorScheme(
    primary = NexaPurple,
    onPrimary = LightSurface,
    secondary = ColorAliases.CyanDark,
    tertiary = ColorAliases.PinkDark,
    background = LightBackground,
    onBackground = LightText,
    surface = LightSurface,
    onSurface = LightText,
    surfaceVariant = LightSurfaceHigh,
    onSurfaceVariant = LightMuted,
    outline = LightOutline,
    error = ColorAliases.RedDark,
)

private object ColorAliases {
    val CyanDark = androidx.compose.ui.graphics.Color(0xFF007B91)
    val PinkDark = androidx.compose.ui.graphics.Color(0xFF9D1C83)
    val RedDark = androidx.compose.ui.graphics.Color(0xFFB3263B)
}

@Composable
fun NexaChatTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val context = LocalContext.current
    val baseColors = when {
        settings.dynamicColors && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        dark -> DarkColors
        else -> LightColors
    }
    val colors = if (settings.highContrast) {
        baseColors.copy(
            outline = baseColors.onSurface,
            outlineVariant = baseColors.onSurface.copy(alpha = 0.72f),
            surfaceVariant = if (dark) DarkSurfaceHigh else LightSurfaceHigh,
            onSurfaceVariant = baseColors.onSurface,
        )
    } else baseColors
    val scale = if (settings.largeText) 1.12f else 1f
    val typography = Typography(
        displaySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = (36 * scale).sp),
        headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = (30 * scale).sp),
        headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = (24 * scale).sp),
        titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = (20 * scale).sp),
        titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = (16 * scale).sp),
        bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = (16 * scale).sp),
        bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = (14 * scale).sp),
        labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = (14 * scale).sp),
        labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = (12 * scale).sp),
    )
    MaterialTheme(colorScheme = colors, typography = typography, content = content)
}
