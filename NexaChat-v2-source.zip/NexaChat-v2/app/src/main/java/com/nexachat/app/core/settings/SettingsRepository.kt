package com.nexachat.app.core.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "nexachat_settings")

class SettingsRepository(private val context: Context) {
    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { preferences ->
        AppSettings(
            themeMode = runCatching { ThemeMode.valueOf(preferences[THEME] ?: ThemeMode.SYSTEM.name) }.getOrDefault(ThemeMode.SYSTEM),
            dynamicColors = preferences[DYNAMIC_COLORS] ?: true,
            compactChats = preferences[COMPACT_CHATS] ?: false,
            largeText = preferences[LARGE_TEXT] ?: false,
            highContrast = preferences[HIGH_CONTRAST] ?: false,
            hapticSend = preferences[HAPTIC_SEND] ?: true,
            showOnline = preferences[SHOW_ONLINE] ?: true,
            readReceipts = preferences[READ_RECEIPTS] ?: true,
            dataSaver = preferences[DATA_SAVER] ?: false,
            notificationsEnabled = preferences[NOTIFICATIONS] ?: true,
            groupBadges = preferences[GROUP_BADGES] ?: true,
        )
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { preferences ->
            val current = AppSettings(
                themeMode = runCatching { ThemeMode.valueOf(preferences[THEME] ?: ThemeMode.SYSTEM.name) }.getOrDefault(ThemeMode.SYSTEM),
                dynamicColors = preferences[DYNAMIC_COLORS] ?: true,
                compactChats = preferences[COMPACT_CHATS] ?: false,
                largeText = preferences[LARGE_TEXT] ?: false,
                highContrast = preferences[HIGH_CONTRAST] ?: false,
                hapticSend = preferences[HAPTIC_SEND] ?: true,
                showOnline = preferences[SHOW_ONLINE] ?: true,
                readReceipts = preferences[READ_RECEIPTS] ?: true,
                dataSaver = preferences[DATA_SAVER] ?: false,
                notificationsEnabled = preferences[NOTIFICATIONS] ?: true,
                groupBadges = preferences[GROUP_BADGES] ?: true,
            )
            val updated = transform(current)
            preferences[THEME] = updated.themeMode.name
            preferences[DYNAMIC_COLORS] = updated.dynamicColors
            preferences[COMPACT_CHATS] = updated.compactChats
            preferences[LARGE_TEXT] = updated.largeText
            preferences[HIGH_CONTRAST] = updated.highContrast
            preferences[HAPTIC_SEND] = updated.hapticSend
            preferences[SHOW_ONLINE] = updated.showOnline
            preferences[READ_RECEIPTS] = updated.readReceipts
            preferences[DATA_SAVER] = updated.dataSaver
            preferences[NOTIFICATIONS] = updated.notificationsEnabled
            preferences[GROUP_BADGES] = updated.groupBadges
        }
    }

    private companion object {
        val THEME = stringPreferencesKey("theme")
        val DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        val COMPACT_CHATS = booleanPreferencesKey("compact_chats")
        val LARGE_TEXT = booleanPreferencesKey("large_text")
        val HIGH_CONTRAST = booleanPreferencesKey("high_contrast")
        val HAPTIC_SEND = booleanPreferencesKey("haptic_send")
        val SHOW_ONLINE = booleanPreferencesKey("show_online")
        val READ_RECEIPTS = booleanPreferencesKey("read_receipts")
        val DATA_SAVER = booleanPreferencesKey("data_saver")
        val NOTIFICATIONS = booleanPreferencesKey("notifications")
        val GROUP_BADGES = booleanPreferencesKey("group_badges")
    }
}
