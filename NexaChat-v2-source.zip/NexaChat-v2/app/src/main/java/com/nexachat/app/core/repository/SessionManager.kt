package com.nexachat.app.core.repository

import com.nexachat.app.core.model.Session
import com.nexachat.app.core.network.FirebaseAuthService
import com.nexachat.app.core.security.SecureSessionStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SessionManager(
    private val store: SecureSessionStore,
    private val authService: FirebaseAuthService,
) {
    private val mutex = Mutex()
    private val _session = MutableStateFlow(store.read())
    val session: StateFlow<Session?> = _session.asStateFlow()

    suspend fun save(session: Session) {
        mutex.withLock {
            store.write(session)
            _session.value = session
        }
    }

    suspend fun current(forceRefresh: Boolean = false): Session = mutex.withLock {
        val saved = _session.value ?: throw IllegalStateException("Требуется вход")
        if (!forceRefresh && saved.isValid()) return@withLock saved
        val refreshed = authService.refresh(saved.refreshToken, saved.email)
        store.write(refreshed)
        _session.value = refreshed
        refreshed
    }

    suspend fun token(forceRefresh: Boolean = false): String = current(forceRefresh).idToken

    suspend fun clear() {
        mutex.withLock {
            store.clear()
            _session.value = null
        }
    }
}
