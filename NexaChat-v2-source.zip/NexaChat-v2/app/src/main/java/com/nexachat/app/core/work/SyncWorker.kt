package com.nexachat.app.core.work

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nexachat.app.MainActivity
import com.nexachat.app.NexaChatApp
import com.nexachat.app.R
import kotlinx.coroutines.flow.first

class SyncWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as NexaChatApp).container
        if (container.sessions.session.value == null) return Result.success()
        return runCatching {
            val before = container.chats.chats.value.sumOf { it.unreadCount }
            container.chats.retryPendingMessages()
            container.chats.syncChats()
            val after = container.chats.chats.value.sumOf { it.unreadCount }
            val settings = container.settings.settings.first()
            if (settings.notificationsEnabled && after > before) notifyNewMessages(after - before)
            Result.success()
        }.getOrElse {
            if (runAttemptCount < 4) Result.retry() else Result.failure()
        }
    }

    private fun notifyNewMessages(count: Int) {
        val openApp = PendingIntent.getActivity(
            applicationContext,
            42,
            Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = Notification.Builder(applicationContext, NexaChatApp.CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_stat_nexa)
            .setContentTitle("NexaChat")
            .setContentText(if (count == 1) "Новое сообщение" else "Новых сообщений: $count")
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .build()
        applicationContext.getSystemService(NotificationManager::class.java).notify(1001, notification)
    }
}
