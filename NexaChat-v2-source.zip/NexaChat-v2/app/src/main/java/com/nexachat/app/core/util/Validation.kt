package com.nexachat.app.core.util

object Validation {
    private val emailRegex = Regex("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", RegexOption.IGNORE_CASE)
    private val usernameRegex = Regex("^[A-Za-z0-9_]{5,32}$")

    fun email(value: String): String? = when {
        value.isBlank() -> "Введите электронную почту"
        value.length > 254 -> "Почта слишком длинная"
        !emailRegex.matches(value.trim()) -> "Введите корректную почту"
        else -> null
    }

    fun password(value: String, strict: Boolean = false): String? = when {
        value.length < 6 -> "Минимум 6 символов"
        value.length > 128 -> "Пароль слишком длинный"
        strict && value.none(Char::isLetter) -> "Добавьте хотя бы одну букву"
        strict && value.none(Char::isDigit) -> "Добавьте хотя бы одну цифру"
        else -> null
    }

    fun username(value: String): String? = when {
        value.isBlank() -> "Введите username"
        !usernameRegex.matches(value) -> "5–32 символа: A–Z, 0–9 и _"
        value.startsWith('_') || value.endsWith('_') -> "Username не должен начинаться или заканчиваться с _"
        else -> null
    }

    fun displayName(firstName: String, lastName: String): String? = when {
        firstName.trim().length !in 1..48 -> "Имя: от 1 до 48 символов"
        lastName.trim().length > 48 -> "Фамилия: не больше 48 символов"
        else -> null
    }

    fun bio(value: String): String? = if (value.length > 160) "Описание: не больше 160 символов" else null
    fun message(value: String): String? = when {
        value.isBlank() -> "Сообщение пустое"
        value.length > 8_000 -> "Сообщение слишком длинное"
        else -> null
    }

    fun groupTitle(value: String): String? = when {
        value.trim().length < 3 -> "Название: минимум 3 символа"
        value.trim().length > 64 -> "Название: не больше 64 символов"
        else -> null
    }
}
