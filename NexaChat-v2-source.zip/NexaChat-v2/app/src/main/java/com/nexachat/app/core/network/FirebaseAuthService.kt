package com.nexachat.app.core.network

import com.nexachat.app.core.model.Session
import org.json.JSONObject
import java.net.URLEncoder

class FirebaseAuthService(
    private val apiKey: String,
    private val http: HttpEngine,
) {
    suspend fun signIn(email: String, password: String): Session = identityRequest(
        operation = "accounts:signInWithPassword",
        body = JSONObject()
            .put("email", email.trim())
            .put("password", password)
            .put("returnSecureToken", true),
    )

    suspend fun signUp(email: String, password: String): Session = identityRequest(
        operation = "accounts:signUp",
        body = JSONObject()
            .put("email", email.trim())
            .put("password", password)
            .put("returnSecureToken", true),
    )

    suspend fun refresh(refreshToken: String, email: String): Session {
        val body = "grant_type=refresh_token&refresh_token=${URLEncoder.encode(refreshToken, Charsets.UTF_8.name())}"
        return refreshForm(body, email)
    }

    private suspend fun refreshForm(body: String, email: String): Session {
        val response = formRequest("https://securetoken.googleapis.com/v1/token?key=$apiKey", body)
        ensureSuccess(response)
        return JSONObject(response.body).let {
            Session(
                uid = it.optString("user_id"),
                email = email,
                idToken = it.optString("id_token"),
                refreshToken = it.optString("refresh_token"),
                expiresAtEpochSeconds = System.currentTimeMillis() / 1000 + it.optString("expires_in", "3600").toLongOrNull().orDefault(3600),
            )
        }
    }

    private suspend fun formRequest(url: String, body: String): HttpResponse = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val connection = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 20_000
            doInput = true
            doOutput = true
            useCaches = false
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val bytes = body.toByteArray(Charsets.UTF_8)
            connection.setFixedLengthStreamingMode(bytes.size)
            connection.outputStream.use { it.write(bytes) }
            val code = connection.responseCode
            val stream = if (code >= 400) connection.errorStream else connection.inputStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            HttpResponse(code, text, connection.headerFields.filterKeys { it != null })
        } catch (error: Exception) {
            throw NetworkException("Ошибка сети", cause = error)
        } finally {
            connection.disconnect()
        }
    }

    suspend fun sendPasswordReset(email: String) {
        val response = http.request(
            "POST",
            "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$apiKey",
            JSONObject().put("requestType", "PASSWORD_RESET").put("email", email.trim()).toString(),
        )
        ensureSuccess(response)
    }

    suspend fun sendEmailVerification(idToken: String) {
        val response = http.request(
            "POST",
            "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$apiKey",
            JSONObject().put("requestType", "VERIFY_EMAIL").put("idToken", idToken).toString(),
        )
        ensureSuccess(response)
    }

    suspend fun accountInfo(idToken: String): JSONObject {
        val response = http.request(
            "POST",
            "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=$apiKey",
            JSONObject().put("idToken", idToken).toString(),
        )
        ensureSuccess(response)
        return JSONObject(response.body).optJSONArray("users")?.optJSONObject(0) ?: JSONObject()
    }

    private suspend fun identityRequest(operation: String, body: JSONObject): Session {
        val response = http.request(
            "POST",
            "https://identitytoolkit.googleapis.com/v1/$operation?key=$apiKey",
            body.toString(),
        )
        ensureSuccess(response)
        return JSONObject(response.body).let {
            Session(
                uid = it.optString("localId"),
                email = it.optString("email"),
                idToken = it.optString("idToken"),
                refreshToken = it.optString("refreshToken"),
                expiresAtEpochSeconds = System.currentTimeMillis() / 1000 + it.optString("expiresIn", "3600").toLongOrNull().orDefault(3600),
            )
        }
    }

    private fun ensureSuccess(response: HttpResponse) {
        if (response.isSuccessful) return
        val code = runCatching {
            JSONObject(response.body).optJSONObject("error")?.optString("message")
        }.getOrNull().orEmpty()
        throw NetworkException(readableError(code), response.code, response.body)
    }

    private fun readableError(code: String): String = when {
        code.contains("EMAIL_EXISTS") -> "Эта почта уже зарегистрирована"
        code.contains("EMAIL_NOT_FOUND") || code.contains("INVALID_PASSWORD") || code.contains("INVALID_LOGIN_CREDENTIALS") -> "Неверная почта или пароль"
        code.contains("WEAK_PASSWORD") -> "Пароль слишком простой"
        code.contains("TOO_MANY_ATTEMPTS") -> "Слишком много попыток. Попробуйте позже"
        code.contains("USER_DISABLED") -> "Аккаунт отключён"
        code.contains("API_KEY_INVALID") -> "Ошибка конфигурации приложения"
        else -> "Ошибка авторизации${if (code.isNotBlank()) ": $code" else ""}"
    }
}

private fun Long?.orDefault(default: Long): Long = this ?: default
