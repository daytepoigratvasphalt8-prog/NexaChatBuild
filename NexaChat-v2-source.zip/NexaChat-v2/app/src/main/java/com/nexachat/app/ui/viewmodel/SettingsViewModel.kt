package com.nexachat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexachat.app.core.model.AppSettings
import com.nexachat.app.core.model.ThemeMode
import com.nexachat.app.core.repository.AuthRepository
import com.nexachat.app.core.repository.ChatRepository
import com.nexachat.app.core.settings.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val auth: AuthRepository,
    private val chats: ChatRepository,
) : ViewModel() {
    val settings: StateFlow<AppSettings> = settingsRepository.settings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AppSettings(),
    )

    fun setTheme(value: ThemeMode) = update { it.copy(themeMode = value) }
    fun setDynamicColors(value: Boolean) = update { it.copy(dynamicColors = value) }
    fun setCompactChats(value: Boolean) = update { it.copy(compactChats = value) }
    fun setLargeText(value: Boolean) = update { it.copy(largeText = value) }
    fun setHighContrast(value: Boolean) = update { it.copy(highContrast = value) }
    fun setHaptic(value: Boolean) = update { it.copy(hapticSend = value) }
    fun setShowOnline(value: Boolean) = update { it.copy(showOnline = value) }
    fun setReadReceipts(value: Boolean) = update { it.copy(readReceipts = value) }
    fun setDataSaver(value: Boolean) = update { it.copy(dataSaver = value) }
    fun setNotifications(value: Boolean) = update { it.copy(notificationsEnabled = value) }
    fun setGroupBadges(value: Boolean) = update { it.copy(groupBadges = value) }

    fun clearCache() = chats.clearLocalData()
    fun signOut() = viewModelScope.launch {
        chats.clearLocalData(restart = false)
        auth.signOut()
    }

    private fun update(block: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepository.update(block) }
    }

    class Factory(
        private val settings: SettingsRepository,
        private val auth: AuthRepository,
        private val chats: ChatRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = SettingsViewModel(settings, auth, chats) as T
    }
}
