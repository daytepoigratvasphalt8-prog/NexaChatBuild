package com.nexachat.app.ui.screens.chats

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Unarchive
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexachat.app.core.model.ChatSummary
import com.nexachat.app.core.model.ChatType
import com.nexachat.app.core.util.TimeFormat
import com.nexachat.app.ui.components.EmptyState
import com.nexachat.app.ui.components.ErrorBanner
import com.nexachat.app.ui.components.NexaAvatar
import com.nexachat.app.ui.components.NexaLogo
import com.nexachat.app.ui.viewmodel.ChatFilter
import com.nexachat.app.ui.viewmodel.ChatsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsScreen(
    viewModel: ChatsViewModel,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    onOpenChat: (String) -> Unit,
    onNewChat: () -> Unit,
) {
    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val meta by viewModel.meta.collectAsStateWithLifecycle()
    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().padding(top = 10.dp, start = 16.dp, end = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NexaLogo(Modifier.weight(1f), compact = true)
                    IconButton(onClick = viewModel::refresh, enabled = !meta.refreshing) {
                        Icon(Icons.Rounded.Refresh, "Обновить")
                    }
                }
                OutlinedTextField(
                    value = meta.query,
                    onValueChange = viewModel::setQuery,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, end = 8.dp),
                    placeholder = { Text("Поиск чатов") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                )
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                ) {
                    FilterChip("Все", ChatFilter.ALL, meta.filter, viewModel::setFilter)
                    FilterChip("Личные", ChatFilter.DIRECT, meta.filter, viewModel::setFilter)
                    FilterChip("Группы", ChatFilter.GROUPS, meta.filter, viewModel::setFilter)
                    FilterChip("Архив", ChatFilter.ARCHIVED, meta.filter, viewModel::setFilter)
                }
                ErrorBanner(meta.error, viewModel::clearError)
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewChat, shape = RoundedCornerShape(18.dp)) {
                Icon(Icons.Rounded.AddComment, "Новый чат")
            }
        },
    ) { padding ->
        if (chats.isEmpty()) {
            EmptyState(
                title = if (meta.query.isBlank()) "Пока нет чатов" else "Ничего не найдено",
                message = if (meta.query.isBlank()) "Найдите человека по username или создайте группу." else "Попробуйте изменить запрос или фильтр.",
                modifier = Modifier.fillMaxSize().padding(padding),
                icon = if (meta.query.isBlank()) Icons.Rounded.ChatBubbleOutline else Icons.Rounded.Search,
                actionText = if (meta.query.isBlank()) "Начать общение" else null,
                onAction = if (meta.query.isBlank()) onNewChat else null,
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 96.dp),
            ) {
                items(chats, key = ChatSummary::id) { chat ->
                    ChatRow(
                        chat = chat,
                        currentUid = currentUid,
                        compact = compact,
                        showGroupBadges = showGroupBadges,
                        onClick = { onOpenChat(chat.id) },
                        onPin = { viewModel.togglePin(chat) },
                        onMute = { viewModel.toggleMute(chat) },
                        onArchive = { viewModel.toggleArchive(chat) },
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterChip(label: String, value: ChatFilter, selected: ChatFilter, onClick: (ChatFilter) -> Unit) {
    AssistChip(
        onClick = { onClick(value) },
        label = { Text(label, maxLines = 1) },
        leadingIcon = if (selected == value) ({ Icon(Icons.Rounded.PushPin, null, Modifier.size(14.dp)) }) else null,
    )
}

@Composable
private fun ChatRow(
    chat: ChatSummary,
    currentUid: String,
    compact: Boolean,
    showGroupBadges: Boolean,
    onClick: () -> Unit,
    onPin: () -> Unit,
    onMute: () -> Unit,
    onArchive: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val title = chat.titleFor(currentUid)
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = MaterialTheme.colorScheme.background,
    ) {
        Column {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = if (compact) 9.dp else 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NexaAvatar(title, size = if (compact) 44.dp else 52.dp)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(TimeFormat.message(chat.updatedAt), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (showGroupBadges && chat.type == ChatType.GROUP) {
                        Icon(Icons.Rounded.Group, null, Modifier.size(15.dp), tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.size(4.dp))
                    }
                    Text(
                        chat.lastMessage.ifBlank { "Начало переписки" },
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (chat.muted) Icon(Icons.Rounded.NotificationsOff, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (chat.unreadCount > 0) {
                        Spacer(Modifier.size(7.dp))
                        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primary) {
                            Text(chat.unreadCount.coerceAtMost(99).toString(), Modifier.padding(horizontal = 7.dp, vertical = 2.dp), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Меню") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (chat.pinned) "Открепить" else "Закрепить") },
                        leadingIcon = { Icon(Icons.Rounded.PushPin, null) },
                        onClick = { menu = false; onPin() },
                    )
                    DropdownMenuItem(
                        text = { Text(if (chat.muted) "Включить уведомления" else "Без звука") },
                        leadingIcon = { Icon(Icons.Rounded.NotificationsOff, null) },
                        onClick = { menu = false; onMute() },
                    )
                    DropdownMenuItem(
                        text = { Text(if (chat.archived) "Вернуть из архива" else "В архив") },
                        leadingIcon = { Icon(if (chat.archived) Icons.Rounded.Unarchive else Icons.Rounded.Archive, null) },
                        onClick = { menu = false; onArchive() },
                    )
                }
            }
        }
        HorizontalDivider(Modifier.padding(start = if (compact) 72.dp else 80.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
        }
    }
}
