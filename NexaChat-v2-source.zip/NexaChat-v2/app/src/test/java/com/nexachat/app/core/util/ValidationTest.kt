package com.nexachat.app.core.util

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ValidationTest {
    @Test
    fun validEmailPasses() {
        assertNull(Validation.email("user@example.com"))
    }

    @Test
    fun malformedEmailFails() {
        assertNotNull(Validation.email("not-an-email"))
    }

    @Test
    fun usernameRulesRejectUnsafeCharacters() {
        assertNotNull(Validation.username("bad name"))
        assertNotNull(Validation.username("ab"))
        assertNull(Validation.username("nexa_user_17"))
    }

    @Test
    fun strictPasswordRequiresStrength() {
        assertNotNull(Validation.password("password", strict = true))
        assertNull(Validation.password("NexaChat_2026!", strict = true))
    }

    @Test
    fun messageLengthIsBounded() {
        assertNotNull(Validation.message(""))
        assertNull(Validation.message("Привет!"))
        assertNotNull(Validation.message("a".repeat(8_001)))
    }
}
