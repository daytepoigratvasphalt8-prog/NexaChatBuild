package com.nexachat.app.core.model

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelsTest {
    @Test
    fun profileBuildsReadableDisplayNameAndInitials() {
        val profile = UserProfile(uid = "1", firstName = "Noah", lastName = "Flores")
        assertEquals("Noah Flores", profile.displayName)
        assertEquals("NF", profile.initials)
    }

    @Test
    fun directChatUsesOtherMembersName() {
        val chat = ChatSummary(
            id = "direct",
            type = ChatType.DIRECT,
            memberIds = setOf("me", "other"),
            memberNames = mapOf("me" to "Me", "other" to "Alex"),
        )
        assertEquals("Alex", chat.titleFor("me"))
    }

    @Test
    fun sessionValidityIncludesRefreshSafetyWindow() {
        val now = 1_000L
        assertTrue(Session("u", "e", "token", "refresh", now + 100).isValid(now))
        assertFalse(Session("u", "e", "token", "refresh", now + 50).isValid(now))
    }
}
